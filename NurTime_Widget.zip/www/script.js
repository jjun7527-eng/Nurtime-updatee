// ===== Konfigurasi =====
const SCHOOL = 0;
const NOTIFY_GRACE_MS = 5 * 60 * 1000; // toleransi jika tab sempat tertunda
const KAABA = { lat: 21.4225, lng: 39.8262 };

// Ikon SVG (sprite ada di index.html)
const ic = (name, extra = "") =>
  `<svg class="ic ${extra}" aria-hidden="true"><use href="#i-${name}"/></svg>`;

const prayerNames = [
  { key: "Fajr", name: "Subuh", icon: "sunrise" },
  { key: "Dhuhr", name: "Dzuhur", icon: "sun" },
  { key: "Asr", name: "Ashar", icon: "sun-cloud" },
  { key: "Maghrib", name: "Maghrib", icon: "sunset" },
  { key: "Isha", name: "Isya", icon: "moon" }
];

const CITIES = [
  ["Ambon", "Maluku", -3.6954, 128.1814, "Asia/Jayapura"],
  ["Balikpapan", "Kalimantan Timur", -1.2379, 116.8529, "Asia/Makassar"],
  ["Banda Aceh", "Aceh", 5.5483, 95.3238, "Asia/Jakarta"],
  ["Bandar Lampung", "Lampung", -5.4294, 105.2610, "Asia/Jakarta"],
  ["Bandung", "Jawa Barat", -6.9175, 107.6191, "Asia/Jakarta"],
  ["Banjarmasin", "Kalimantan Selatan", -3.3194, 114.5908, "Asia/Makassar"],
  ["Batam", "Kepulauan Riau", 1.0456, 104.0305, "Asia/Jakarta"],
  ["Bengkulu", "Bengkulu", -3.7956, 102.2592, "Asia/Jakarta"],
  ["Bogor", "Jawa Barat", -6.5950, 106.8166, "Asia/Jakarta"],
  ["Denpasar", "Bali", -8.6705, 115.2126, "Asia/Makassar"],
  ["Gorontalo", "Gorontalo", 0.5435, 123.0568, "Asia/Makassar"],
  ["Jakarta", "DKI Jakarta", -6.2088, 106.8456, "Asia/Jakarta"],
  ["Jambi", "Jambi", -1.6101, 103.6131, "Asia/Jakarta"],
  ["Jayapura", "Papua", -2.5337, 140.7181, "Asia/Jayapura"],
  ["Kendari", "Sulawesi Tenggara", -3.9985, 122.5130, "Asia/Makassar"],
  ["Kupang", "Nusa Tenggara Timur", -10.1772, 123.6070, "Asia/Makassar"],
  ["Makassar", "Sulawesi Selatan", -5.1477, 119.4327, "Asia/Makassar"],
  ["Malang", "Jawa Timur", -7.9666, 112.6326, "Asia/Jakarta"],
  ["Manado", "Sulawesi Utara", 1.4748, 124.8421, "Asia/Makassar"],
  ["Manokwari", "Papua Barat", -0.8615, 134.0620, "Asia/Jayapura"],
  ["Mataram", "Nusa Tenggara Barat", -8.5833, 116.1167, "Asia/Makassar"],
  ["Medan", "Sumatera Utara", 3.5952, 98.6722, "Asia/Jakarta"],
  ["Padang", "Sumatera Barat", -0.9471, 100.4172, "Asia/Jakarta"],
  ["Palangka Raya", "Kalimantan Tengah", -2.2161, 113.9135, "Asia/Jakarta"],
  ["Palembang", "Sumatera Selatan", -2.9761, 104.7754, "Asia/Jakarta"],
  ["Palu", "Sulawesi Tengah", -0.8917, 119.8707, "Asia/Makassar"],
  ["Pangkal Pinang", "Kepulauan Bangka Belitung", -2.1316, 106.1169, "Asia/Jakarta"],
  ["Pekanbaru", "Riau", 0.5071, 101.4478, "Asia/Jakarta"],
  ["Pontianak", "Kalimantan Barat", -0.0263, 109.3425, "Asia/Jakarta"],
  ["Samarinda", "Kalimantan Timur", -0.5022, 117.1536, "Asia/Makassar"],
  ["Semarang", "Jawa Tengah", -6.9667, 110.4167, "Asia/Jakarta"],
  ["Serang", "Banten", -6.1200, 106.1500, "Asia/Jakarta"],
  ["Sorong", "Papua Barat Daya", -0.8762, 131.2558, "Asia/Jayapura"],
  ["Surabaya", "Jawa Timur", -7.2575, 112.7521, "Asia/Jakarta"],
  ["Tanjung Pinang", "Kepulauan Riau", 0.9186, 104.4586, "Asia/Jakarta"],
  ["Tarakan", "Kalimantan Utara", 3.3000, 117.6333, "Asia/Makassar"],
  ["Ternate", "Maluku Utara", 0.7833, 127.3667, "Asia/Jayapura"],
  ["Yogyakarta", "DI Yogyakarta", -7.7956, 110.3695, "Asia/Jakarta"]
];

const DEFAULT_LOCATION = {
  name: "Palembang, Sumatera Selatan",
  lat: -2.9761,
  lng: 104.7754,
  tz: "Asia/Jakarta"
};

const TZ_FALLBACK_OFFSET = {
  "Asia/Jakarta": "+07:00",
  "Asia/Makassar": "+08:00",
  "Asia/Jayapura": "+09:00"
};

let todayPrayers = [];
let tomorrowPrayers = [];
let currentHijri = "";
let todayImsak = "";
let todaySunrise = "";
let currentDateKey = "";
let countdownInterval = null;
let isLoading = false;
let loadToken = 0;
let lastLoadAttempt = 0;

// ===== Utilitas =====
function storageGet(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw === null ? fallback : JSON.parse(raw);
  } catch (e) {
    return fallback;
  }
}

function storageSet(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {}
}

function escapeHtml(text) {
  return String(text).replace(/[&<>"']/g, c => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[c]));
}

let toastTimer = null;

function showToast(message) {
  let toast = document.getElementById("toast");
  if (!toast) {
    toast = document.createElement("div");
    toast.id = "toast";
    toast.className = "toast";
    document.body.appendChild(toast);
  }
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 3500);
}

// ===== Lokasi =====
const LOCATION_KEY = "nurtime_location";
const HOME_KEY = "nurtime_home";

function loadLocation() {
  const saved = storageGet(LOCATION_KEY, null);
  if (saved && typeof saved.lat === "number" && typeof saved.lng === "number" && saved.tz) {
    return { ...DEFAULT_LOCATION, ...saved };
  }
  return { ...DEFAULT_LOCATION };
}

let userLocation = loadLocation();
let homeLocation = storageGet(HOME_KEY, null);
let musafirMode = false;

function shortLocationName() {
  return userLocation.name.split(",")[0];
}

function inIndonesia(lat, lng) {
  return lat >= -11.5 && lat <= 6.5 && lng >= 94.5 && lng <= 141.5;
}

const METHOD_NAMES = { 20: "KEMENAG Indonesia", 3: "Muslim World League", 4: "Umm al-Qura Makkah", 5: "Egyptian General Authority", 2: "ISNA (Amerika Utara)", 1: "Karachi" };
function currentSchool() { return Number(settings.school) === 1 ? 1 : 0; }
function adjustSig() { const a = settings.adjust; return [a.Fajr, a.Dhuhr, a.Asr, a.Maghrib, a.Isha].join("_") + "s" + currentSchool(); }
function shiftTime(str, mins) {
  const m = String(str || "").match(/(\d{1,2}):(\d{2})/);
  if (!m || !mins) return str;
  let t = (Number(m[1]) * 60 + Number(m[2]) + Number(mins)) % 1440;
  if (t < 0) t += 1440;
  return String(Math.floor(t / 60)).padStart(2, "0") + ":" + String(t % 60).padStart(2, "0");
}
function adjustTimings(t) {
  if (!t) return t;
  const a = settings.adjust, out = { ...t };
  ["Fajr", "Dhuhr", "Asr", "Maghrib", "Isha"].forEach(k => { if (out[k]) out[k] = shiftTime(out[k], a[k]); });
  if (out.Imsak) out.Imsak = shiftTime(out.Imsak, a.Fajr);
  return out;
}
function currentMethod() {
  if (typeof settings !== "undefined" && settings.method && settings.method !== "auto") return Number(settings.method);
  return inIndonesia(userLocation.lat, userLocation.lng) ? 20 : null;
}

function guessTimezone(lat, lng) {
  if (inIndonesia(lat, lng)) {
    if (lng < 114.3) return "Asia/Jakarta";
    if (lng < 126.5) return "Asia/Makassar";
    return "Asia/Jayapura";
  }
  try {
    return Intl.DateTimeFormat().resolvedOptions().timeZone || "Asia/Jakarta";
  } catch (e) {
    return "Asia/Jakarta";
  }
}

function tzOffset(date) {
  try {
    const value = new Intl.DateTimeFormat("en-US", {
      timeZone: userLocation.tz,
      timeZoneName: "longOffset"
    }).formatToParts(date).find(p => p.type === "timeZoneName").value;
    const m = value.match(/GMT([+-])(\d{1,2})(?::?(\d{2}))?/);
    return m ? `${m[1]}${m[2].padStart(2, "0")}:${m[3] || "00"}` : "+00:00";
  } catch (e) {
    return TZ_FALLBACK_OFFSET[userLocation.tz] || "+07:00";
  }
}

function tzLabel() {
  const labels = { "Asia/Jakarta": "WIB", "Asia/Makassar": "WITA", "Asia/Jayapura": "WIT" };
  return labels[userLocation.tz] || "waktu setempat";
}

function toRad(deg) { return deg * Math.PI / 180; }

function qiblaBearing(lat, lng) {
  const p1 = toRad(lat);
  const p2 = toRad(KAABA.lat);
  const dl = toRad(KAABA.lng - lng);
  const y = Math.sin(dl);
  const x = Math.cos(p1) * Math.tan(p2) - Math.sin(p1) * Math.cos(dl);
  return (Math.atan2(y, x) * 180 / Math.PI + 360) % 360;
}

function distanceKm(lat1, lng1, lat2, lng2) {
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  return 6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function updateLocationUI() {
  const name = document.getElementById("locationName");
  const label = document.getElementById("locationLabel");
  if (name) name.textContent = userLocation.name;
  if (label) label.textContent = shortLocationName() + " hari ini";
}

function updateMusafirStatus() {
  if (!homeLocation || !userLocation) return;
  const dist = Math.round(distanceKm(userLocation.lat, userLocation.lng, homeLocation.lat, homeLocation.lng));
  musafirMode = dist > 80;
  const badge = document.getElementById("musafirBadge");
  if (badge) {
    badge.classList.toggle("show", musafirMode);
    if (musafirMode) badge.innerHTML = `${ic("pin")} Musafir • ${dist} km dari rumah`;
  }
  const panel = document.getElementById("musafirPanel");
  if (panel) renderMusafirPanel();
}

function setHomeToCurrent() {
  setHomeLocation(userLocation.lat, userLocation.lng, userLocation.name);
  if (document.getElementById("settingsBody")) renderSettings();
}

function setHomeLocation(lat, lng, name) {
  homeLocation = { lat, lng, name };
  storageSet(HOME_KEY, homeLocation);
  updateMusafirStatus();
  showToast('Rumah ditetapkan: ' + name);
}

function setLocation(loc) {
  userLocation = loc;
  storageSet(LOCATION_KEY, loc);
  updateLocationUI();
  todayPrayers = [];
  tomorrowPrayers = [];
  currentDateKey = "";
  loadPrayerTimes(true);
  applyRamadanMode();
  updateMusafirStatus();
  showToast("Lokasi diubah ke " + shortLocationName());
}

function selectCity(index) {
  const c = CITIES[index];
  setLocation({ name: `${c[0]}, ${c[1]}`, lat: c[2], lng: c[3], tz: c[4] });
  closeFeature();
}

function renderCityList(filter) {
  const list = document.getElementById("cityList");
  if (!list) return;
  const q = String(filter || "").trim().toLowerCase();
  let html = "";
  CITIES.forEach((c, i) => {
    if (q && !(c[0] + " " + c[1]).toLowerCase().includes(q)) return;
    html += `<button class="city-item" onclick="selectCity(${i})"><span>${escapeHtml(c[0])}<small>${escapeHtml(c[1])}</small></span></button>`;
  });
  list.innerHTML = html || "<p class='setting-note'>Kota tidak ditemukan.</p>";
}

async function reverseGeocode(lat, lng) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 6000);
  try {
    const url = "https://api.bigdatacloud.net/data/reverse-geocode-client" + `?latitude=${lat}&longitude=${lng}&localityLanguage=id`;
    const response = await fetch(url, { signal: controller.signal });
    if (!response.ok) throw new Error("gagal");
    const data = await response.json();
    const place = data.city || data.locality;
    const region = data.principalSubdivision;
    if (place && region) return `${place}, ${region}`;
    if (place || region) return place || region;
  } catch (e) {}
  finally { clearTimeout(timer); }
  let nearest = null, best = Infinity;
  CITIES.forEach(c => {
    const d = distanceKm(lat, lng, c[2], c[3]);
    if (d < best) { best = d; nearest = c; }
  });
  if (nearest && best < 50) return `${nearest[0]}, ${nearest[1]}`;
  return `Lokasi GPS (${lat.toFixed(2)}, ${lng.toFixed(2)})`;
}

function useGPS() {
  const status = document.getElementById("gpsStatus");
  if (!navigator.geolocation) {
    if (status) status.textContent = "Browser ini tidak mendukung GPS.";
    return;
  }
  if (status) status.textContent = "Mencari lokasi kamu...";
  navigator.geolocation.getCurrentPosition(
    async position => {
      const lat = position.coords.latitude;
      const lng = position.coords.longitude;
      if (status) status.textContent = "Lokasi ditemukan, mencari nama tempat...";
      const name = await reverseGeocode(lat, lng);
      setLocation({ name, lat, lng, tz: guessTimezone(lat, lng), gps: true });
      closeFeature();
    },
    error => {
      const messages = {
        1: "Izin lokasi ditolak. Izinkan akses lokasi di pengaturan browser.",
        2: "Lokasi tidak tersedia. Coba pilih kota secara manual.",
        3: "Waktu pencarian habis. Coba lagi atau pilih kota manual."
      };
      if (status) status.textContent = messages[error.code] || "Gagal mendapatkan lokasi.";
    },
    { enableHighAccuracy: false, timeout: 15000, maximumAge: 600000 }
  );
}

// ===== Tanggal (mengikuti zona waktu lokasi) =====
function tzParts(date) {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: userLocation.tz,
    year: "numeric", month: "2-digit", day: "2-digit"
  }).formatToParts(date);
  const get = type => parts.find(p => p.type === type).value;
  return { y: get("year"), m: get("month"), d: get("day") };
}

function getDateKey(date) {
  const p = tzParts(date);
  return `${p.d}-${p.m}-${p.y}`;
}

function getLocalDateKey(date) {
  const p = tzParts(date);
  return `${p.y}-${p.m}-${p.d}`;
}

function parsePrayerDate(time, date) {
  const match = String(time).match(/(\d{1,2}):(\d{2})/);
  if (!match) throw new Error("Format waktu sholat tidak valid.");
  const p = tzParts(date);
  const hh = match[1].padStart(2, "0");
  let offset = tzOffset(date);
  let candidate = new Date(`${p.y}-${p.m}-${p.d}T${hh}:${match[2]}:00${offset}`);
  const offsetAtPrayer = tzOffset(candidate);
  if (offsetAtPrayer !== offset) {
    candidate = new Date(`${p.y}-${p.m}-${p.d}T${hh}:${match[2]}:00${offsetAtPrayer}`);
  }
  return candidate;
}

// ===== Jadwal sholat =====
async function fetchPrayerTimesOnline(date) {
  const method = currentMethod();
  const url = `https://api.aladhan.com/v1/timings/${getDateKey(date)}` +
    `?latitude=${userLocation.lat}&longitude=${userLocation.lng}` +
    (method ? `&method=${method}` : "") + `&school=${currentSchool()}` +
    `&timezonestring=${encodeURIComponent(userLocation.tz)}`;
  
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 8000);
  try {
    const response = await fetch(url, { signal: controller.signal });
    clearTimeout(timeoutId);
    if (!response.ok) throw new Error("Gagal mengambil jadwal sholat.");
    const result = await response.json();
    if (result.code !== 200 || !result.data) throw new Error("Data jadwal tidak tersedia.");
    return { ...result.data, timings: adjustTimings(result.data.timings) };
  } catch (error) {
    clearTimeout(timeoutId);
    throw error;
  }
}

async function prayerTimesFromCalendar(date) {
  try {
    const p = tzParts(date);
    const raw = await fetchMonthRaw(Number(p.y), Number(p.m));
    const item = raw.find(i => i.date.gregorian.date === `${p.d}-${p.m}-${p.y}`);
    return item ? { timings: item.timings, date: item.date } : null;
  } catch (error) { return null; }
}

async function fetchPrayerTimes(date) {
  try { return await fetchPrayerTimesOnline(date); }
  catch (error) {
    const data = await prayerTimesFromCalendar(date);
    if (data) return data;
    throw error;
  }
}

function prefetchMonths() {
  const p = tzParts(new Date());
  let y = Number(p.y); let m = Number(p.m);
  fetchMonthRaw(y, m).catch(() => {});
  m++;
  if (m > 12) { m = 1; y++; }
  fetchMonthRaw(y, m).catch(() => {});
}

let lastSunnahMinute = 0;

function startTicker() {
  if (countdownInterval) clearInterval(countdownInterval);
  countdownInterval = setInterval(() => {
    updateCountdown();
    updateAppBadge();
    checkNotifications();
    checkAdzan();
    checkFastReminders();
    checkSunnahReminders();
    const minuteTick = Math.floor(Date.now() / 60000);
    if (minuteTick !== lastSunnahMinute) { lastSunnahMinute = minuteTick; renderSunnahTimes(); }
    if (getLocalDateKey(new Date()) !== currentDateKey && Date.now() - lastLoadAttempt > 30000) {
      loadPrayerTimes();
    }
  }, 1000);
}

async function loadPrayerTimes(force = false) {
  if (isLoading && !force) return;
  const token = ++loadToken;
  isLoading = true;
  lastLoadAttempt = Date.now();
  const now = new Date();

  try {
    document.getElementById("nextPrayer").textContent = "Mengambil jadwal...";
    const tomorrow = new Date(now.getTime() + 24 * 60 * 60 * 1000);
    const [todayData, tomorrowData] = await Promise.all([
      fetchPrayerTimes(now),
      fetchPrayerTimes(tomorrow)
    ]);
    if (token !== loadToken) return;

    todayPrayers = prayerNames.map(p => ({ ...p, time: todayData.timings[p.key] }));
    tomorrowPrayers = prayerNames.map(p => ({ ...p, time: tomorrowData.timings[p.key] }));
    todayImsak = todayData.timings.Imsak || "";
    todaySunrise = todayData.timings.Sunrise || "";
    const hijri = todayData.date.hijri;
    currentHijri = `${hijri.day} ${hijri.month.en} ${hijri.year} H`;
    currentDateKey = getLocalDateKey(now);

    updateDate();
    renderPrayerList();
    renderSunnahTimes();
    updateTrackerSummary();
    updateIslamicInfo();
    updateCountdown();
    updateAppBadge();
    checkNotifications();
    checkAdzan();
    checkFastReminders();
    applyRamadanMode();
    checkSunnahFasting();
    prefetchMonths();

    startTicker();
    scheduleNativeSoon();
  } catch (error) {
    if (token !== loadToken) return;
    console.error(error);
    try {
      const tomorrowDate = new Date(now.getTime() + 24 * 60 * 60 * 1000);
      const [fallback, fallbackTomorrow] = await Promise.all([
        prayerTimesFromCalendar(now),
        prayerTimesFromCalendar(tomorrowDate)
      ]);
      if (fallback && token === loadToken) {
        todayPrayers = prayerNames.map(p => ({ ...p, time: fallback.timings[p.key] }));
        tomorrowPrayers = fallbackTomorrow
          ? prayerNames.map(p => ({ ...p, time: fallbackTomorrow.timings[p.key] }))
          : [];
        todayImsak = fallback.timings.Imsak || "";
        todaySunrise = fallback.timings.Sunrise || "";
        const hj = fallback.date && fallback.date.hijri;
        if (hj) currentHijri = `${hj.day} ${hj.month.en} ${hj.year} H`;
        currentDateKey = getLocalDateKey(now);
        updateDate(); renderPrayerList(); renderSunnahTimes(); updateTrackerSummary(); updateIslamicInfo();
        updateCountdown(); updateAppBadge(); checkNotifications(); checkAdzan();
        checkFastReminders(); applyRamadanMode(); checkSunnahFasting(); prefetchMonths();
        startTicker();
        scheduleNativeSoon();
        return;
      }
    } catch (e) {}

    document.getElementById("nextPrayer").textContent = "Jadwal belum tersedia";
    document.getElementById("countdown").textContent = "--:--:--";
    document.getElementById("prayerList").innerHTML = "<p style='padding:15px;color:#c66'>Tidak bisa mengambil jadwal. Mencoba lagi otomatis, atau periksa internet lalu muat ulang.</p>";
    setTimeout(loadPrayerTimes, 30000);
  } finally {
    if (token === loadToken) isLoading = false;
  }
}

function updateDate() {
  const now = new Date();
  const gregorian = new Intl.DateTimeFormat(settings.lang === "en" ? "en-GB" : "id-ID", {
    weekday: "long", day: "numeric", month: "long", year: "numeric", timeZone: userLocation.tz
  }).format(now);
  document.getElementById("today").textContent = gregorian + (currentHijri ? " • " + currentHijri : "");
}

function renderPrayerList() {
  const container = document.getElementById("prayerList");
  const day = tracker[getLocalDateKey(new Date())] || {};
  container.innerHTML = "";
  todayPrayers.forEach(prayer => {
    const row = document.createElement("div");
    row.className = "prayer-row";
    row.innerHTML = `<span>${ic(prayer.icon)} ${prayer.name}</span><strong>${formatTime(prayer.time)}${day[prayer.key] ? " " + ic("check", "tick") : ""}</strong>`;
    container.appendChild(row);
  });
  const method = currentMethod();
  document.querySelector(".disclaimer").textContent = (method ? "Metode " + (METHOD_NAMES[method] || "khusus") : "Metode perhitungan otomatis sesuai lokasi") + ` • Waktu ${tzLabel()} • Periksa kesesuaian dengan jadwal masjid setempat.`;
}

function formatTime(time) {
  const match = String(time).match(/(\d{1,2}):(\d{2})/);
  if (!match) return "--:--";
  if (typeof settings !== "undefined" && settings.timeFormat === "12") {
    const h = Number(match[1]);
    return `${h % 12 || 12}:${match[2]} ${h < 12 ? "AM" : "PM"}`;
  }
  return `${match[1].padStart(2, "0")}:${match[2]}`;
}

let npStripKey = "";

function updateCountdown() {
  if (!todayPrayers.length) return;
  const now = new Date();
  let nextPrayer = null;
  let nextIndex = -1;
  for (let i = 0; i < todayPrayers.length; i++) {
    const prayer = todayPrayers[i];
    const prayerDate = parsePrayerDate(prayer.time, now);
    if (prayerDate > now) { nextPrayer = { ...prayer, date: prayerDate }; nextIndex = i; break; }
  }
  const tomorrow = new Date(now.getTime() + 24 * 60 * 60 * 1000);
  if (!nextPrayer && tomorrowPrayers.length) {
    const prayer = tomorrowPrayers[0];
    nextPrayer = { ...prayer, date: parsePrayerDate(prayer.time, tomorrow) };
    nextIndex = todayPrayers.length; // semua sholat hari ini sudah lewat
  }
  if (!nextPrayer) return;

  const nameEl = document.getElementById("nextPrayer");
  nameEl.innerHTML = `${escapeHtml(nextPrayer.name)} <span class="np-clock">${formatTime(nextPrayer.time)} ${tzLabel()}</span>`;
  const difference = Math.max(0, nextPrayer.date.getTime() - now.getTime());
  const hours = Math.floor(difference / 3600000);
  const minutes = Math.floor((difference % 3600000) / 60000);
  const seconds = Math.floor((difference % 60000) / 1000);
  document.getElementById("countdown").textContent = [hours, minutes, seconds].map(v => String(v).padStart(2, "0")).join(":");

  // Waktu sholat sebelumnya, untuk bilah progres
  let prevDate;
  if (nextIndex > 0) {
    prevDate = parsePrayerDate(todayPrayers[nextIndex - 1].time, now);
  } else {
    const yesterday = new Date(now.getTime() - 24 * 60 * 60 * 1000);
    prevDate = parsePrayerDate(todayPrayers[todayPrayers.length - 1].time, yesterday);
  }
  const span = nextPrayer.date.getTime() - prevDate.getTime();
  const pct = span > 0 ? Math.min(100, Math.max(0, ((now.getTime() - prevDate.getTime()) / span) * 100)) : 0;
  const bar = document.getElementById("npBar");
  if (bar) bar.style.width = pct.toFixed(1) + "%";

  const hint = document.getElementById("nextPrayerHint");
  if (hint) {
    const sinceMin = Math.floor((now.getTime() - prevDate.getTime()) / 60000);
    const prevName = nextIndex > 0 ? todayPrayers[nextIndex - 1].name : "Isya";
    hint.textContent = sinceMin >= 0 && sinceMin < 600 ? `${prevName} sudah masuk ${sinceMin < 60 ? sinceMin + " menit" : Math.floor(sinceMin / 60) + " jam"} lalu` : "Hitung mundur menuju waktu sholat";
  }

  // Strip lima waktu: hanya digambar ulang saat sholat berikutnya atau jadwal berubah
  const strip = document.getElementById("npStrip");
  if (strip) {
    const key = nextIndex + "|" + todayPrayers.map(p => p.time).join(",");
    if (key !== npStripKey) {
      npStripKey = key;
      strip.innerHTML = todayPrayers.map((p, i) => {
        const cls = i === nextIndex ? "next" : i < nextIndex ? "past" : "";
        return `<div class="np-item ${cls}">${ic(p.icon)}<span>${p.name}</span><strong>${formatTime(p.time)}</strong></div>`;
      }).join("");
    }
  }
}

// ===== Badging API (Icon App) =====
function updateAppBadge() {
  if (!("setAppBadge" in navigator) || !todayPrayers.length) return;
  const now = new Date();
  let next = null;
  for (const p of todayPrayers) {
    const t = parsePrayerDate(p.time, now);
    if (t > now) { next = t; break; }
  }
  if (!next) { if (navigator.clearAppBadge) navigator.clearAppBadge().catch(() => {}); return; }
  const mins = Math.max(1, Math.round((next.getTime() - now.getTime()) / 60000));
  navigator.setAppBadge(mins).catch(() => {});
}

// ===== Tracker sholat =====
const TRACKER_KEY = "nurtime_tracker";
let tracker = storageGet(TRACKER_KEY, {});

function todayKey() { return getLocalDateKey(new Date()); }
function addDays(key, n) {
  const [y, m, d] = key.split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, d + n)).toISOString().slice(0, 10);
}

function dayCount(key) {
  const day = tracker[key] || {};
  return prayerNames.filter(p => day[p.key]).length;
}

function isComplete(key) { return dayCount(key) === prayerNames.length; }

function currentStreak() {
  let key = todayKey();
  if (!isComplete(key)) key = addDays(key, -1);
  let streak = 0;
  while (isComplete(key)) { streak++; key = addDays(key, -1); }
  return streak;
}

function bestStreak() {
  const keys = Object.keys(tracker).filter(isComplete).sort();
  let best = 0, run = 0, prev = null;
  keys.forEach(k => {
    run = prev && addDays(prev, 1) === k ? run + 1 : 1;
    best = Math.max(best, run);
    prev = k;
  });
  return best;
}

function updateTrackerSummary() {
  const count = dayCount(todayKey());
  const total = prayerNames.length;
  const countEl = document.getElementById("trackerCount");
  const streakEl = document.getElementById("trackerStreak");
  const barEl = document.getElementById("trackerBar");
  if (countEl) countEl.textContent = `${count} / ${total} sholat`;
  if (streakEl) streakEl.innerHTML = `${ic("flame", "fill")} ${currentStreak()} hari`;
  if (barEl) barEl.style.width = `${(count / total) * 100}%`;
}

function togglePrayerDone(key) {
  const now = new Date();
  const prayer = todayPrayers.find(p => p.key === key);
  if (prayer && parsePrayerDate(prayer.time, now) > now) {
    showToast(`Waktu ${prayer.name} belum masuk.`);
    return;
  }
  const dayKey = todayKey();
  if (!tracker[dayKey]) tracker[dayKey] = {};
  tracker[dayKey][key] = !tracker[dayKey][key];
  if (!dayCount(dayKey)) delete tracker[dayKey];
  storageSet(TRACKER_KEY, tracker);
  renderTracker();
  updateTrackerSummary();
  if (todayPrayers.length) renderPrayerList();
}

function renderTracker() {
  const body = document.getElementById("trackerBody");
  if (!body) return;
  const dayKey = todayKey();
  const day = tracker[dayKey] || {};
  const count = dayCount(dayKey);

  const rows = prayerNames.map(p => {
    const info = todayPrayers.find(t => t.key === p.key);
    const done = !!day[p.key];
    return `<button class="check-row ${done ? "done" : ""}" onclick="togglePrayerDone('${p.key}')"><span>${ic(p.icon)} ${p.name}</span><span class="check-time">${info ? formatTime(info.time) : "--:--"}</span><span class="check-mark">${done ? ic("check") : ""}</span></button>`;
  }).join("");

  let history = "";
  for (let i = 6; i >= 0; i--) {
    const key = addDays(dayKey, -i);
    const n = dayCount(key);
    const label = new Date(key + "T00:00:00Z").toLocaleDateString("id-ID", { weekday: "short", timeZone: "UTC" });
    history += `<div class="hist-cell ${n === prayerNames.length ? "full" : ""} ${i === 0 ? "today" : ""}"><small>${label}</small><strong>${n}</strong></div>`;
  }

  body.innerHTML = `
    <div class="tracker-stats">
      <div><strong>${count}/${prayerNames.length}</strong><small>Hari ini</small></div>
      <div><strong>${ic("flame", "fill")} ${currentStreak()}</strong><small>Streak</small></div>
      <div><strong>${ic("trophy")} ${bestStreak()}</strong><small>Rekor</small></div>
    </div>
    ${rows}
    <h4>7 hari terakhir</h4>
    <div class="hist-row">${history}</div>
    <p class="setting-note">Streak dihitung dari hari berturut-turut saat kelima sholat tercentang. Data tersimpan di perangkat ini.</p>
    <div id="heatmapBody" style="margin-top:24px"></div>
  `;
  
  renderHeatmap30();
}

// ===== Heatmap 30 Hari =====
function renderHeatmap30() {
  const body = document.getElementById("heatmapBody");
  if (!body) return;
  const today = todayKey();
  const cells = [];
  const stats = { Fajr: 0, Dhuhr: 0, Asr: 0, Maghrib: 0, Isha: 0 };
  let totalDays = 0;

  for (let i = 29; i >= 0; i--) {
    const key = addDays(today, -i);
    const day = tracker[key] || {};
    const count = prayerNames.filter(p => day[p.key]).length;
    prayerNames.forEach(p => { if (day[p.key]) stats[p.key]++; });
    if (count > 0) totalDays++;
    const d = keyToUtc(key);
    const level = count === 0 ? 0 : count <= 2 ? 1 : count <= 4 ? 2 : 3;
    cells.push(`<div class="heat-cell lvl-${level}" style="--n:${29 - i}" title="${shortDateLabel(key)} • ${count}/5"><span>${d.getUTCDate()}</span></div>`);
  }

  const consistency = Math.round((totalDays / 30) * 100);
  const prayerBars = prayerNames.map(p => {
    const pct = Math.round((stats[p.key] / 30) * 100);
    return `<div class="heat-bar-row"><span>${p.name}</span><div class="heat-bar"><div style="width:${pct}%"></div></div><strong>${pct}%</strong></div>`;
  }).join("");

  body.innerHTML = `
    <div class="heat-summary"><strong>${consistency}%</strong><small>konsistensi 30 hari terakhir</small></div>
    <h4>30 hari terakhir</h4>
    <div class="heat-grid">${cells.join('')}</div>
    <h4>Per sholat</h4>
    ${prayerBars}
  `;
}

// ===== Tema =====
const mediaDark = window.matchMedia ? window.matchMedia("(prefers-color-scheme: dark)") : null;

function resolvedTheme() {
  if (settings.theme === "dark") return "dark";
  if (settings.theme === "light") return "light";
  return mediaDark && mediaDark.matches ? "dark" : "light";
}

function applyTheme() {
  const theme = resolvedTheme();
  document.documentElement.setAttribute("data-theme", theme);
  const button = document.getElementById("themeBtn");
  if (button) button.innerHTML = ic(theme === "dark" ? "sun" : "moon");
}

function setTheme(value) {
  const root = document.documentElement;
  root.classList.add("theme-anim");
  setTimeout(() => root.classList.remove("theme-anim"), 500);
  settings.theme = value;
  saveSettings();
  applyTheme();
}

function toggleTheme() {
  setTheme(resolvedTheme() === "dark" ? "light" : "dark");
  renderSettings();
}

// ===== Notifikasi & Setting =====
const SETTINGS_KEY = "nurtime_settings";
const NOTIFIED_KEY = "nurtime_notified";

const defaultSettings = {
  enabled: false,
  lead: 0,
  theme: "auto",
  hijriAdjust: 0,
  method: "auto",
  school: 0,
  timeFormat: "24",
  lang: "id",
  showMasjidBtn: true,
  adjust: { Fajr: 0, Dhuhr: 0, Asr: 0, Maghrib: 0, Isha: 0 },
  fastRemind: { sahur: false, sahurLead: 30, buka: false, sunnah: false },
  sunnahRemind: { dhuha: false, tahajud: false, jumat: false },
  prayers: { Fajr: true, Dhuhr: true, Asr: true, Maghrib: true, Isha: true },
  adzan: {
    enabled: false,
    volume: 1,
    fileName: "",
    prayers: { Fajr: true, Dhuhr: true, Asr: true, Maghrib: true, Isha: true }
  }
};

let settings = loadSettings();
let notified = new Set(storageGet(NOTIFIED_KEY, []));

function loadSettings() {
  const saved = storageGet(SETTINGS_KEY, {});
  return {
    ...defaultSettings,
    ...saved,
    prayers: { ...defaultSettings.prayers, ...(saved.prayers || {}) },
    adjust: { ...defaultSettings.adjust, ...(saved.adjust || {}) },
    fastRemind: { ...defaultSettings.fastRemind, ...(saved.fastRemind || {}) },
    sunnahRemind: { ...defaultSettings.sunnahRemind, ...(saved.sunnahRemind || {}) },
    adzan: {
      ...defaultSettings.adzan,
      ...(saved.adzan || {}),
      prayers: { ...defaultSettings.adzan.prayers, ...((saved.adzan && saved.adzan.prayers) || {}) }
    }
  };
}

function saveSettings() {
  storageSet(SETTINGS_KEY, settings);
  updateBellState();
  scheduleNativeSoon();
}

function notifSupported() { return !!(window.NurNative && NurNative.isNative) || "Notification" in window; }
function notifPermission() {
  if (window.NurNative && NurNative.isNative) return NurNative.permission;
  return "Notification" in window ? Notification.permission : "unsupported";
}

function updateBellState() {
  const bell = document.querySelector(".notification-btn");
  if (!bell) return;
  bell.classList.toggle("on", settings.enabled && notifPermission() === "granted");
}

async function registerServiceWorker() {
  if (window.NurNative && NurNative.isNative) return;
  if (!("serviceWorker" in navigator)) return;
  const secure = location.protocol === "https:" || location.hostname === "localhost" || location.hostname === "127.0.0.1";
  if (!secure) return;
  try {
    await navigator.serviceWorker.register("sw.js");
    navigator.serviceWorker.ready.then(() => {
      swReady = true;
      if (document.getElementById("settingsBody")) renderSettings();
    });
  } catch (e) { console.warn("Service worker gagal didaftarkan:", e); }
}

async function sendNotification(title, body, tag) {
  if (notifPermission() !== "granted") return;
  if (window.NurNative && NurNative.isNative) { NurNative.notifyNow(title, body); return; }
  const options = { body, tag, lang: "id", vibrate: [200, 100, 200], icon: "icon-192.png", badge: "icon-192.png" };
  try {
    const reg = "serviceWorker" in navigator ? await navigator.serviceWorker.getRegistration() : null;
    if (reg) { await reg.showNotification(title, options); return; }
  } catch (e) {}
  try { new Notification(title, options); } catch (e) {}
}

async function requestNotification() {
  if (window.NurNative && NurNative.isNative) {
    const result = await NurNative.requestPermission();
    if (result === "granted") {
      settings.enabled = true;
      saveSettings();
      showToast("Notifikasi diaktifkan.");
    } else {
      showToast("Izin notifikasi ditolak. Aktifkan lewat Pengaturan > Aplikasi > NurTime > Notifikasi.");
    }
    updateBellState();
    renderSettings();
    if (document.getElementById("notifAdzanBody")) renderNotifAdzanPage();
    scheduleNativeSoon();
    return;
  }
  if (!notifSupported()) { showToast("Browser ini tidak mendukung notifikasi."); return; }
  if (Notification.permission === "denied") { showToast("Notifikasi diblokir. Aktifkan lewat pengaturan situs di browser."); return; }
  if (Notification.permission === "granted") { showFeature("Notifikasi & Adzan"); return; }
  const permission = await new Promise(resolve => {
    const result = Notification.requestPermission(resolve);
    if (result && typeof result.then === "function") result.then(resolve);
  });
  if (permission === "granted") {
    settings.enabled = true;
    saveSettings();
    await registerServiceWorker();
    sendNotification("NurTime aktif", "Kamu akan diingatkan saat waktu sholat tiba.", "nurtime-welcome");
    showToast("Notifikasi diaktifkan.");
  } else {
    showToast("Izin notifikasi tidak diberikan.");
  }
  renderSettings();
  if (document.getElementById("notifAdzanBody")) renderNotifAdzanPage();
}

function checkNotifications() {
  if (window.NurNative && NurNative.isNative) return;
  if (!settings.enabled || notifPermission() !== "granted" || !todayPrayers.length) return;
  const now = new Date();
  const todayKey = getLocalDateKey(now);
  if (currentDateKey && todayKey !== currentDateKey) {
    const keep = [...notified].filter(v => v.startsWith(todayKey));
    if (keep.length !== notified.size) { notified = new Set(keep); storageSet(NOTIFIED_KEY, keep); }
  }
  const leads = settings.lead > 0 ? [settings.lead, 0] : [0];
  todayPrayers.forEach(prayer => {
    if (!settings.prayers[prayer.key]) return;
    const prayerDate = parsePrayerDate(prayer.time, now);
    leads.forEach(lead => {
      const target = prayerDate.getTime() - lead * 60000;
      const diff = now.getTime() - target;
      if (diff < 0 || diff >= NOTIFY_GRACE_MS) return;
      const id = `${todayKey}_${prayer.key}_${lead}`;
      if (notified.has(id)) return;
      notified.add(id);
      const keep = [...notified].filter(v => v.startsWith(todayKey));
      notified = new Set(keep);
      storageSet(NOTIFIED_KEY, keep);
      if (lead > 0) {
        sendNotification(`${lead} menit lagi ${prayer.name}`, `Waktu ${prayer.name} pukul ${formatTime(prayer.time)} ${tzLabel()}. Bersiaplah.`, id);
        playNotificationSound();
      } else {
        sendNotification(`Waktunya sholat ${prayer.name}`, `Sekarang pukul ${formatTime(prayer.time)} ${tzLabel()} untuk wilayah ${shortLocationName()}.`, id);
        playNotificationSound();
      }
    });
  });
}

function setNotifEnabled(value) { settings.enabled = value; saveSettings(); }
function setLead(value) { settings.lead = Number(value) || 0; saveSettings(); }
function setPrayerNotif(key, value) { settings.prayers[key] = value; saveSettings(); }
function sendTestNotification() {
  if (notifPermission() !== "granted") { showToast("Aktifkan izin notifikasi dulu."); return; }
  sendNotification("Tes NurTime", "Kalau kamu melihat ini, notifikasi berfungsi.", "nurtime-test");
}

// ===== Render Pengaturan & Notifikasi =====
let settingsView = "hub";
let settingsQuery = "";
window.notifOnly = null;
window.addEventListener("load", () => applyMasjidBtn());

const SETTINGS_SUB = {
  notif:  { title: "Notifikasi sholat",      icon: "bell",     kw: "notifikasi pengingat sholat izin" },
  adzan:  { title: "Suara adzan",            icon: "volume",   kw: "adzan suara volume file audio" },
  fast:   { title: "Pengingat puasa",        icon: "crescent", kw: "puasa sahur berbuka imsak ramadan" },
  sunnah: { title: "Sholat sunnah dan Jumat", icon: "sun",     kw: "dhuha tahajud jumat kahfi sunnah" },
  waktu:  { title: "Perhitungan waktu sholat", icon: "compass", kw: "metode mazhab ashar koreksi ihtiyat menit kemenag hanafi" },
  bahasa: { title: "Bahasa",               icon: "globe",    kw: "bahasa language inggris english indonesia" },
  tampilan: { title: "Tampilan",             icon: "palette",  kw: "tema gelap terang otomatis warna" },
  rumah:  { title: "Rumah dan musafir",      icon: "home",     kw: "rumah musafir lokasi safar" },
  backup: { title: "Cadangan dan impor",     icon: "reset",    kw: "cadangan backup export import pulihkan data" },
  app:    { title: "Tentang aplikasi",       icon: "info",     kw: "aplikasi pasang instal offline versi" },
  donate: { title: "Salurkan kebaikan",      icon: "hands",    kw: "donasi zakat infak sedekah baznas" }
};
const SETTINGS_KW_EN = { notif: "notification reminder prayer", adzan: "adhan azan sound volume", fast: "fasting suhoor iftar", sunnah: "sunnah friday dhuha tahajud", tampilan: "appearance theme dark light time format", waktu: "calculation method asr correction", rumah: "home traveler location", backup: "backup restore reset import export", app: "about app version developer social update", donate: "donate charity zakat" };
const SETTINGS_GROUPS = [["notif", "adzan", "fast", "sunnah"], ["tampilan", "bahasa", "waktu", "rumah"], ["backup", "app", "donate"]];

function reloadTimes() { try { loadPrayerTimes(true); } catch (e) {} }
function refreshTimeViews() { try { renderPrayerList(); npStripKey = ""; updateCountdown(); renderSunnahTimes(); updateIslamicInfo(); } catch (e) {} }
function setCalcMethod(v) { settings.method = v; saveSettings(); reloadTimes(); showToast("Metode perhitungan diperbarui."); }
function setSchool(v) { settings.school = Number(v) === 1 ? 1 : 0; saveSettings(); reloadTimes(); showToast("Mazhab Ashar diperbarui."); }
function setPrayerAdjust(key, v) { settings.adjust[key] = Number(v) || 0; saveSettings(); reloadTimes(); }
function resetPrayerAdjust() { settings.adjust = { ...defaultSettings.adjust }; saveSettings(); reloadTimes(); renderSettings(); showToast("Koreksi waktu disetel ulang."); }
function setTimeFormat(v) { settings.timeFormat = v === "12" ? "12" : "24"; saveSettings(); refreshTimeViews(); }
function applyMasjidBtn() { const b = document.querySelector(".masjid-btn"); if (b) b.style.display = settings.showMasjidBtn === false ? "none" : ""; }
function setShowMasjidBtn(v) { settings.showMasjidBtn = !!v; saveSettings(); applyMasjidBtn(); }
function resetAllSettings() {
  if (!confirm(trText("Setel ulang semua pengaturan ke bawaan? Data tracker dan bookmark tidak dihapus."))) return;
  const keepLang = settings.lang;
  settings = JSON.parse(JSON.stringify(defaultSettings));
  settings.lang = keepLang;
  saveSettings(); applyTheme(); applyMasjidBtn(); reloadTimes(); renderSettings();
  showToast("Pengaturan disetel ulang.");
}


// ===== Tentang aplikasi =====
const APP_VERSION = "2.8.0";
const UPDATE_URL = ""; // isi dengan alamat halaman unduh NurTime supaya "Periksa pembaruan" membukanya
const DEV_NAME = "KYY.DEV";
// Tambah sosmed: salin satu baris di bawah, ganti isinya, hapus tanda // di depannya.
// icon: "send" (pesawat kertas) atau "link" (tautan umum)
const DEV_SOCIALS = [
  { name: "TikTok", handle: "@rkyy233", url: "https://www.tiktok.com/@rkyy233?_r=1&_t=ZS-9BQNwRYY3YT", icon: "link" },
  // { name: "Telegram",  handle: "@usernamekamu", url: "https://t.me/usernamekamu", icon: "send" },
  // { name: "TikTok",    handle: "@usernamekamu", url: "https://www.tiktok.com/@usernamekamu", icon: "link" },
  // { name: "Instagram", handle: "@usernamekamu", url: "https://www.instagram.com/usernamekamu", icon: "link" },
];

function openQris() {
  let ov = document.getElementById("qrisOverlay");
  if (!ov) {
    ov = document.createElement("div");
    ov.id = "qrisOverlay";
    ov.onclick = closeQris;
    ov.innerHTML = `<img src="qris-card.png" alt="QRIS"><p>Ketuk untuk menutup</p>`;
    document.body.appendChild(ov);
  }
  ov.classList.add("show");
}
function closeQris() { const ov = document.getElementById("qrisOverlay"); if (ov) ov.classList.remove("show"); }

function checkUpdate() {
  if (UPDATE_URL) window.open(UPDATE_URL, "_blank");
  else showToast("Alamat pembaruan belum diatur.");
}

function aboutPageHtml() {
  const native = window.NurNative && NurNative.isNative;
  const socials = DEV_SOCIALS.length ? `
    <p class="ab-label">Media sosial</p>
    <div class="sh-card">${DEV_SOCIALS.map(x => `<a class="sh-row" href="${escapeHtml(x.url)}" target="_blank" rel="noopener noreferrer"><span class="sh-ic">${ic(x.icon || "link")}</span><span class="sh-txt">${escapeHtml(x.name)}</span><span class="ab-handle">${escapeHtml(x.handle || "")}</span></a>`).join("")}</div>` : "";
  return `
    <div class="sh-card ab-app"><img class="ab-logo" src="icon-192.png" alt=""><div class="ab-appinfo"><b>NurTime</b><small>${APP_VERSION} · ${native ? "Android" : "Web"}</small></div></div>
    <div class="sh-card"><button class="sh-row" onclick="checkUpdate()"><span class="sh-ic">${ic("reset")}</span><span class="sh-txt">Periksa pembaruan</span><span class="sh-chev">${ic("chevron")}</span></button></div>
    <div class="ab-dev">
      <img class="ab-dev-cover" src="dev.jpg" alt="">
      <div class="ab-dev-fade"></div>
      <div class="ab-dev-info"><b>${escapeHtml(DEV_NAME)}</b><small>Pengembang</small></div>
      <img class="ab-dev-av" src="dev-avatar.jpg" alt="">
    </div>
    ${socials}
    <p class="ab-label">Dukung developer</p>
    <button class="ab-support" onclick="openQris()">${ic("heart", "fill")}<span>Traktir kopi</span></button>
    <p class="ab-label">Informasi aplikasi</p>
    <div class="sh-card sh-pad">${pwaSettingsHtml()}</div>`;
}

// ===== Bahasa =====
function setLang(code) {
  settings.lang = code === "en" ? "en" : "id";
  saveSettings();
  showToast(settings.lang === "en" ? "Language changed to English." : "Bahasa diubah ke Indonesia.");
  setTimeout(() => location.reload(), 450);
}
function langPageHtml() {
  const row = (code, label) => `<button class="sh-row lang-row" onclick="setLang('${code}')"><span class="sh-txt">${label}</span>${(settings.lang || "id") === code ? `<span class="sh-chev lang-check">${ic("check")}</span>` : ""}</button>`;
  return row("id", "Bahasa Indonesia") + row("en", "English") +
    `<p class="setting-note">Terjemahan mencakup menu, pengaturan, dan tampilan utama. Isi doa, notifikasi terjadwal, dan sebagian halaman fitur masih berbahasa Indonesia.</p>`;
}

function openSettingsPage(view) {
  settingsView = view;
  settingsQuery = "";
  renderSettings();
  const page = document.getElementById("featurePage");
  if (page) page.scrollTop = 0;
}

function featureBack() {
  const page = document.getElementById("featurePage");
  if (page && page.classList.contains("settings-mode") && settingsView !== "hub") { openSettingsPage("hub"); return; }
  closeFeature();
}

function settingsRowHtml(id) {
  const p = SETTINGS_SUB[id];
  return `<button class="sh-row" onclick="openSettingsPage('${id}')"><span class="sh-ic">${ic(p.icon)}</span><span class="sh-txt">${p.title}</span><span class="sh-chev">${ic("chevron")}</span></button>`;
}

function settingsHubListHtml() {
  const q = settingsQuery.trim().toLowerCase();
  const match = (text) => !q || text.toLowerCase().includes(q);
  let html = "";
  const locText = "lokasi gps kota " + userLocation.name;
  if (match(locText)) {
    html += `<div class="sh-card"><button class="sh-row sh-top" onclick="showFeature('Lokasi')"><span class="sh-ic">${ic("pin")}</span><span class="sh-txt"><b>${escapeHtml(userLocation.name)}</b><small>Lokasi jadwal sholat. Ketuk untuk ubah atau pakai GPS</small></span><span class="sh-chev">${ic("chevron")}</span></button></div>`;
  }
  SETTINGS_GROUPS.forEach(group => {
    const ids = group.filter(id => match(SETTINGS_SUB[id].title + " " + SETTINGS_SUB[id].kw + " " + (SETTINGS_KW_EN[id] || "")));
    if (ids.length) html += `<div class="sh-card">${ids.map(settingsRowHtml).join("")}</div>`;
  });
  return html || `<p class="sh-empty">Pengaturan tidak ditemukan</p>`;
}

function filterSettings(value) {
  settingsQuery = value || "";
  const list = document.getElementById("settingsList");
  if (list) list.innerHTML = settingsHubListHtml();
}

function settingsSubHtml(view) {
  if (view === "tampilan") {
    const opts = [["auto", "Otomatis"], ["light", "Terang"], ["dark", "Gelap"]].map(([v, label]) => `<option value="${v}" ${settings.theme === v ? "selected" : ""}>${label}</option>`).join("");
    const fmt = [["24", "24 jam (04:35)"], ["12", "12 jam (4:35 AM)"]].map(([v, l]) => `<option value="${v}" ${settings.timeFormat === v ? "selected" : ""}>${l}</option>`).join("");
    return `<label class="setting-row"><span>Tema aplikasi</span><select onchange="setTheme(this.value)">${opts}</select></label>
      <label class="setting-row"><span>Format jam</span><select onchange="setTimeFormat(this.value)">${fmt}</select></label>
      <label class="setting-row"><span>Tombol Mode Masjid</span><input type="checkbox" ${settings.showMasjidBtn ? "checked" : ""} onchange="setShowMasjidBtn(this.checked)"></label>`;
  }
  if (view === "waktu") {
    const methods = [["auto", "Otomatis (Kemenag di Indonesia)"], ["20", "KEMENAG Indonesia"], ["3", "Muslim World League"], ["4", "Umm al-Qura Makkah"], ["5", "Egyptian General Authority"], ["2", "ISNA (Amerika Utara)"], ["1", "Karachi"]].map(([v, l]) => `<option value="${v}" ${String(settings.method) === v ? "selected" : ""}>${l}</option>`).join("");
    const schools = [[0, "Syafi'i, Maliki, Hanbali"], [1, "Hanafi"]].map(([v, l]) => `<option value="${v}" ${currentSchool() === v ? "selected" : ""}>${l}</option>`).join("");
    const mins = [-5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
    const rows = prayerNames.map(p => `<label class="setting-row"><span>${ic(p.icon)} ${p.name}</span><select onchange="setPrayerAdjust('${p.key}', this.value)">${mins.map(v => `<option value="${v}" ${(Number(settings.adjust[p.key]) || 0) === v ? "selected" : ""}>${v > 0 ? "+" + v : v} menit</option>`).join("")}</select></label>`).join("");
    return `<label class="setting-row"><span>Metode perhitungan</span><select onchange="setCalcMethod(this.value)">${methods}</select></label>
      <label class="setting-row"><span>Mazhab waktu Ashar</span><select onchange="setSchool(this.value)">${schools}</select></label>
      <h4>Koreksi waktu (ihtiyat)</h4>${rows}
      <p class="setting-note">Koreksi ikut berlaku pada hitung mundur, notifikasi, dan adzan. Imsak mengikuti koreksi Subuh.</p>
      <button onclick="resetPrayerAdjust()">Setel ulang koreksi</button>`;
  }
  if (view === "rumah") {
    return `
      <div class="setting-row"><span>${ic("pin")} ${escapeHtml(userLocation.name)}</span><button class="small-btn" onclick="showFeature('Lokasi')">Ubah Lokasi</button></div>
      <div class="setting-row"><span>Rumah (untuk Musafir)</span><button class="small-btn" onclick="setHomeToCurrent()">${homeLocation ? escapeHtml(homeLocation.name) : "Tetapkan Rumah"}</button></div>`;
  }
  if (view === "backup") {
    return `
      <button onclick="resetAllSettings()">Setel ulang semua pengaturan</button>
      <div class="setting-row"><span>Cadangkan data ke file</span><button class="small-btn" onclick="exportData()">Export</button></div>
      <div class="setting-row"><span>Pulihkan data dari file</span><button class="small-btn" onclick="document.getElementById('importFile').click()">Import</button></div>
      <input type="file" id="importFile" accept=".json" hidden onchange="importData(this)">`;
  }
  if (view === "bahasa") return langPageHtml();
  if (view === "donate") return donateSettingsHtml();
  return `<div id="notifAdzanBody"></div>`;
}

function renderSettings() {
  const body = document.getElementById("settingsBody");
  if (!body) return;
  const title = document.getElementById("featureTitle");
  if (settingsView !== "hub" && !SETTINGS_SUB[settingsView]) settingsView = "hub";

  if (settingsView === "hub") {
    if (title) title.textContent = "Pengaturan";
    window.notifOnly = null;
    // jangan bangun ulang kolom cari kalau sedang diketik
    if (!document.getElementById("settingsSearch")) {
      body.innerHTML = `
        <div class="sh-search">${ic("search")}<input id="settingsSearch" type="search" placeholder="Cari pengaturan..." value="${escapeHtml(settingsQuery)}" oninput="filterSettings(this.value)"></div>
        <div id="settingsList">${settingsHubListHtml()}</div>`;
    } else {
      document.getElementById("settingsList").innerHTML = settingsHubListHtml();
    }
    return;
  }

  if (title) title.textContent = SETTINGS_SUB[settingsView].title;
  const isNotif = ["notif", "adzan", "fast", "sunnah"].includes(settingsView);
  window.notifOnly = isNotif ? settingsView : null;
  if (settingsView === "app") { body.innerHTML = aboutPageHtml(); return; }
  body.innerHTML = `<div class="sh-card sh-pad">${settingsSubHtml(settingsView)}</div>`;
  if (isNotif) renderNotifAdzanPage();
}

function renderNotifAdzanPage() {
  const body = document.getElementById("notifAdzanBody");
  if (!body) return;
  
  const permission = notifPermission();
  let notifHtml = "";

  if (permission === "unsupported") {
    notifHtml = "<p>Browser ini tidak mendukung notifikasi.</p>";
  } else if (permission === "denied") {
    notifHtml = "<p>Notifikasi diblokir oleh browser. Buka pengaturan situs (ikon gembok di address bar), izinkan notifikasi, lalu muat ulang halaman.</p>";
  } else if (permission === "default") {
    notifHtml = "<p>Aktifkan notifikasi agar NurTime mengingatkan waktu sholat.</p><button onclick=\"requestNotification()\">" + ic("bell") + " Aktifkan Notifikasi</button>";
  } else {
    const leadOptions = [[0, "Tepat waktu saja"], [5, "5 menit sebelumnya + tepat waktu"], [10, "10 menit sebelumnya + tepat waktu"], [15, "15 menit sebelumnya + tepat waktu"]].map(([v, label]) => `<option value="${v}" ${settings.lead === v ? "selected" : ""}>${label}</option>`).join("");
    const prayerRows = prayerNames.map(p => `<label class="setting-row"><span>${ic(p.icon)} ${p.name}</span><input type="checkbox" ${settings.prayers[p.key] ? "checked" : ""} onchange="setPrayerNotif('${p.key}', this.checked)"></label>`).join("");
    notifHtml = `
      <label class="setting-row"><span>Notifikasi waktu sholat</span><input type="checkbox" ${settings.enabled ? "checked" : ""} onchange="setNotifEnabled(this.checked)"></label>
      <label class="setting-row"><span>Pengingat</span><select onchange="setLead(this.value)">${leadOptions}</select></label>
      <h4>Sholat yang diingatkan</h4>${prayerRows}
      <button onclick="sendTestNotification()">Kirim Notifikasi Percobaan</button>
      <p class="setting-note">Notifikasi muncul selama NurTime masih terbuka di browser.</p>
    `;
  }

  const only = window.notifOnly;
  if (only) {
    const parts = { notif: notifHtml, adzan: adzanSettingsHtml(), fast: fastSettingsHtml(), sunnah: sunnahSettingsHtml() };
    body.innerHTML = parts[only] || "";
    return;
  }
  body.innerHTML = `
    <h4>Notifikasi Waktu Sholat</h4>
    ${notifHtml}
    
    <div style="margin-top: 24px;">
      ${adzanSettingsHtml()}
    </div>
    
    <div style="margin-top: 24px;">
      ${fastSettingsHtml()}
    </div>

    <div style="margin-top: 24px;">
      ${sunnahSettingsHtml()}
    </div>
  `;
}

// ===== Doa Harian & Bookmark =====
const DOA = [
  {
    icon: "utensils", category: "Makan & Minum",
    items: [
      { title: "Sebelum makan", arab: "اللَّهُمَّ بَارِكْ لَنَا فِيمَا رَزَقْتَنَا وَقِنَا عَذَابَ النَّارِ", latin: "Allahumma baarik lanaa fiimaa razaqtanaa wa qinaa 'adzaaban naar.", arti: "Ya Allah, berkahilah rezeki yang Engkau berikan kepada kami dan peliharalah kami dari siksa api neraka." },
      { title: "Sesudah makan", arab: "الْحَمْدُ لِلَّهِ الَّذِي أَطْعَمَنَا وَسَقَانَا وَجَعَلَنَا مِنَ الْمُسْلِمِينَ", latin: "Alhamdulillaahilladzii ath'amanaa wa saqaanaa wa ja'alanaa minal muslimiin.", arti: "Segala puji bagi Allah yang telah memberi kami makan dan minum serta menjadikan kami termasuk orang-orang muslim." }
    ]
  },
  {
    icon: "moon", category: "Tidur & Bangun",
    items: [
      { title: "Sebelum tidur", arab: "بِاسْمِكَ اللَّهُمَّ أَحْيَا وَبِاسْمِكَ أَمُوتُ", latin: "Bismikallaahumma ahyaa wa bismika amuut.", arti: "Dengan menyebut nama-Mu ya Allah, aku hidup dan aku mati." },
      { title: "Bangun tidur", arab: "الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ", latin: "Alhamdulillaahil ladzii ahyaanaa ba'da maa amaatanaa wa ilaihin nusyuur.", arti: "Segala puji bagi Allah yang telah menghidupkan kami setelah mematikan kami, dan kepada-Nya kami dikembalikan." }
    ]
  },
  {
    icon: "home", category: "Aktivitas Harian",
    items: [
      { title: "Masuk kamar mandi", arab: "اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْخُبُثِ وَالْخَبَائِثِ", latin: "Allahumma innii a'uudzu bika minal khubutsi wal khabaa-its.", arti: "Ya Allah, aku berlindung kepada-Mu dari setan laki-laki dan setan perempuan." },
      { title: "Keluar kamar mandi", arab: "غُفْرَانَكَ", latin: "Ghufraanaka.", arti: "Aku memohon ampunan-Mu." },
      { title: "Masuk rumah", arab: "بِسْمِ اللَّهِ وَلَجْنَا وَبِسْمِ اللَّهِ خَرَجْنَا وَعَلَى اللَّهِ رَبِّنَا تَوَكَّلْنَا", latin: "Bismillaahi walajnaa wa bismillaahi kharajnaa wa 'alallaahi rabbinaa tawakkalnaa.", arti: "Dengan nama Allah kami masuk, dengan nama Allah kami keluar, dan kepada Allah Tuhan kami bertawakal." },
      { title: "Keluar rumah", arab: "بِسْمِ اللَّهِ تَوَكَّلْتُ عَلَى اللَّهِ لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ", latin: "Bismillaahi tawakkaltu 'alallaah, laa haula wa laa quwwata illaa billaah.", arti: "Dengan nama Allah, aku bertawakal kepada Allah. Tiada daya dan kekuatan kecuali dengan pertolongan Allah." },
      { title: "Naik kendaraan", arab: "سُبْحَانَ الَّذِي سَخَّرَ لَنَا هَذَا وَمَا كُنَّا لَهُ مُقْرِنِينَ وَإِنَّا إِلَى رَبِّنَا لَمُنْقَلِبُونَ", latin: "Subhaanalladzii sakhkhara lanaa haadzaa wa maa kunnaa lahu muqriniin, wa innaa ilaa rabbinaa lamunqalibuun.", arti: "Maha Suci Allah yang telah menundukkan kendaraan ini bagi kami padahal kami tidak mampu menguasainya, dan sesungguhnya kami akan kembali kepada Tuhan kami." }
    ]
  },
  {
    icon: "mosque", category: "Ibadah & Permohonan",
    items: [
      { title: "Sesudah adzan", arab: "اللَّهُمَّ رَبَّ هَذِهِ الدَّعْوَةِ التَّامَّةِ وَالصَّلَاةِ الْقَائِمَةِ آتِ مُحَمَّدًا الْوَسِيلَةَ وَالْفَضِيلَةَ وَابْعَثْهُ مَقَامًا مَحْمُودًا الَّذِي وَعَدْتَهُ", latin: "Allahumma rabba haadzihid da'watit taammah, wash shalaatil qaa-imah, aati Muhammadanil wasiilata wal fadhiilah, wab'atshu maqaamam mahmuudanil ladzii wa'adtah.", arti: "Ya Allah, Tuhan pemilik panggilan yang sempurna ini dan shalat yang akan didirikan, berilah Nabi Muhammad wasilah dan keutamaan, dan bangkitkanlah beliau pada kedudukan terpuji yang telah Engkau janjikan." },
      { title: "Doa kebaikan dunia dan akhirat", arab: "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ", latin: "Rabbanaa aatinaa fid-dunyaa hasanah wa fil-aakhirati hasanah wa qinaa 'adzaaban naar.", arti: "Ya Tuhan kami, berilah kami kebaikan di dunia dan kebaikan di akhirat, dan lindungilah kami dari azab neraka. (QS. Al-Baqarah: 201)" },
      { title: "Untuk kedua orang tua", arab: "رَبِّ اغْفِرْ لِي وَلِوَالِدَيَّ وَارْحَمْهُمَا كَمَا رَبَّيَانِي صَغِيرًا", latin: "Rabbighfir lii wa liwaalidayya warhamhumaa kamaa rabbayaanii shaghiiraa.", arti: "Ya Tuhanku, ampunilah aku dan kedua orang tuaku, dan sayangilah mereka sebagaimana mereka menyayangiku di waktu kecil." },
      { title: "Memohon tambahan ilmu", arab: "رَبِّ زِدْنِي عِلْمًا وَارْزُقْنِي فَهْمًا", latin: "Rabbi zidnii 'ilmaa warzuqnii fahmaa.", arti: "Ya Tuhanku, tambahkanlah ilmu kepadaku dan berilah aku rezeki pemahaman." }
    ]
  }
];

function renderDoa() {
  return DOA.map(group => `
    <h4>${ic(group.icon)} ${group.category}</h4>
    ${group.items.map(item => `
      <details class="doa">
        <summary>${item.title}</summary>
        <p class="arab">${item.arab}</p>
        <p class="latin">${item.latin}</p>
        <p class="arti">${item.arti}</p>
      </details>
    `).join("")}
  `).join("");
}

const BOOKMARK_KEY = "nurtime_bookmarks";
let bookmarks = storageGet(BOOKMARK_KEY, []);

function isBookmarked(surahNo, ayatNo) {
  return bookmarks.some(b => b.s === surahNo && b.a === ayatNo);
}

function toggleBookmark(surah, ayat, button) {
  if (isBookmarked(surah.nomor, ayat.nomorAyat)) {
    bookmarks = bookmarks.filter(b => !(b.s === surah.nomor && b.a === ayat.nomorAyat));
    showToast("Bookmark dihapus.");
  } else {
    bookmarks.push({ s: surah.nomor, n: surah.namaLatin, a: ayat.nomorAyat, ar: ayat.teksArab, id: ayat.teksIndonesia });
    showToast("Ayat disimpan ke bookmark.");
  }
  storageSet(BOOKMARK_KEY, bookmarks);
  const saved = isBookmarked(surah.nomor, ayat.nomorAyat);
  if (button) {
    button.innerHTML = ic("bookmark", saved ? "fill" : "") + (saved ? " Tersimpan" : " Simpan");
    button.classList.toggle("saved", saved);
  }
}

function renderBookmarks() {
  const body = document.getElementById("bookmarkBody");
  if (!body) return;
  if (!bookmarks.length) {
    body.innerHTML = "<p>Belum ada ayat tersimpan. Buka sebuah surah lalu tekan tombol Simpan pada ayat yang ingin kamu tandai.</p>";
    return;
  }
  const sorted = [...bookmarks].sort((x, y) => x.s - y.s || x.a - y.a);
  body.innerHTML = sorted.map(b => `
    <div class="ayat-block">
      <strong>${escapeHtml(b.n)} : ${b.a}</strong>
      <p class="arab-small">${escapeHtml(b.ar)}</p>
      <p>${escapeHtml(b.id)}</p>
      <button onclick="loadSurah(${b.s}, ${b.a})">Buka</button>
      <button class="danger" onclick="removeBookmark(${b.s}, ${b.a})">Hapus</button>
    </div>
  `).join("");
}

function removeBookmark(s, a) {
  bookmarks = bookmarks.filter(b => !(b.s === s && b.a === a));
  storageSet(BOOKMARK_KEY, bookmarks);
  renderBookmarks();
}

// ===== Navigasi Fitur =====
const TAB_BY_FEATURE = { 
  "Al-Qur’an": 1, 
  "Ayat Tersimpan": 1, 
  "Dzikir": 2, 
  "Doa Harian": 2, 
  "Pengaturan": 3,
  "Notifikasi & Adzan": 3
};

function setActiveTab(index) {
  document.querySelectorAll(".bottom-nav button").forEach((btn, i) => {
    btn.classList.toggle("active", i === index);
  });
}

function showTab(name, button) {
  if (name === "Beranda") { closeFeature(); window.scrollTo(0, 0); return; }
  showFeature(name);
}

function showFeature(name) {
  const page = document.getElementById("featurePage");
  const title = document.getElementById("featureTitle");
  const content = document.getElementById("featureContent");

  title.textContent = name;
  window.notifOnly = null;
  page.classList.toggle("settings-mode", name === "Pengaturan");
  clearTimeout(featureCloseTimer);
  page.classList.remove("closing");
  page.classList.remove("hidden");
  page.scrollTop = 0;
  setActiveTab(TAB_BY_FEATURE[name] ?? 0);

  if (name === "Dzikir") {
    renderTasbihPage(content);
  } else if (name === "Doa Harian") {
    content.innerHTML = `<h3>${ic("hands")} Doa Harian</h3><p>Ketuk judul doa untuk membuka bacaannya.</p>${renderDoa()}`;
  } else if (name === "Al-Qur’an") {
    content.innerHTML = `
      <h3>${ic("book")} Al-Qur'an</h3>
      <p>Pilih surah untuk mulai membaca.</p>
      <button onclick="showFeature('Ayat Tersimpan')">${ic("bookmark")} Ayat Tersimpan (${bookmarks.length})</button>
      <div class="surah-search-wrap"><span>${ic("search")}</span><input id="surahSearch" type="search" placeholder="Cari nama atau nomor surah..." oninput="filterSurahList(this.value)"></div>
      <div id="surahList" class="surah-list"></div>
    `;
    loadSurahList();
  } else if (name === "Ayat Tersimpan") {
    content.innerHTML = `<button onclick="showFeature('Al-Qur’an')">${ic("arrow-left")} Al-Qur'an</button><h3>${ic("bookmark")} Ayat Tersimpan</h3><div id="bookmarkBody"></div>`;
    renderBookmarks();
  } else if (name === "Arah Kiblat") {
    const bearing = qiblaBearing(userLocation.lat, userLocation.lng);
    content.innerHTML = `
      <h3>${ic("compass")} Kompas Kiblat</h3>
      <p>Lokasi: ${escapeHtml(userLocation.name)}</p>
      <div class="qibla-compass">
        <div class="compass-ring">
          <span class="north">U</span><span class="east">T</span><span class="south">S</span><span class="west">B</span>
          <div id="qiblaNeedle" class="qibla-needle" style="transform: rotate(${bearing.toFixed(2)}deg)">
            <svg class="needle-svg" viewBox="0 0 40 150" aria-hidden="true"><path d="M20 4L34 70H6z" fill="#e6c879"/><path d="M20 146L10 78h20z" fill="#ffffff" opacity=".85"/></svg>
          </div>
          <div class="compass-center">${ic("crescent")}</div>
        </div>
      </div>
      <div class="qibla-result">
        <h2>${bearing.toFixed(2).replace(".", ",")}°</h2>
        <p>Arah kiblat dari ${escapeHtml(shortLocationName())} (dari utara, searah jarum jam)</p>
        <p id="compassStatus">Sensor belum diaktifkan</p>
      </div>
      <button onclick="startQiblaCompass()">Aktifkan Kompas</button>
    `;
  } else if (name === "Kalender Hijriah") {
    renderCalendarPage(content);
  } else if (name === "Puasa") {
    renderFastPage(content);
  } else if (name === "Tracker Sholat") {
    content.innerHTML = `<h3>${ic("check-circle")} Tracker Sholat</h3><p>Ketuk sholat yang sudah kamu kerjakan hari ini.</p><div id="trackerBody"></div>`;
    renderTracker();
  } else if (name === "Lokasi") {
    content.innerHTML = `
      <h3>${ic("pin")} Lokasi</h3>
      <p>Saat ini: <strong>${escapeHtml(userLocation.name)}</strong> (${tzLabel()})</p>
      <button onclick="useGPS()">${ic("locate")} Gunakan Lokasi GPS</button>
      <p id="gpsStatus" class="setting-note"></p>
      <div class="setting-row" style="margin-top:12px">
        <span>Rumah: ${homeLocation ? escapeHtml(homeLocation.name) : "Belum ditetapkan"}</span>
        <button class="small-btn" onclick="setHomeLocation(userLocation.lat, userLocation.lng, userLocation.name)">Tetapkan Rumah</button>
      </div>
      <h4>Atau pilih kota</h4>
      <input class="city-search" id="citySearch" placeholder="Cari kota..." oninput="renderCityList(this.value)">
      <div id="cityList"></div>
    `;
    renderCityList("");
  } else if (name === "Notifikasi & Adzan") {
    content.innerHTML = `
      <h3>${ic("bell")} Notifikasi & Adzan</h3>
      <div id="notifAdzanBody"></div>
    `;
    renderNotifAdzanPage();
  } else if (name === "Pengaturan") {
    settingsView = "hub"; settingsQuery = "";
    content.innerHTML = `<div id="settingsBody"></div>`;
    renderSettings();
  } else if (name === "Asmaul Husna") {
  content.innerHTML = `
    <h3>${ic("sparkle")} Asmaul Husna</h3>
    <p>99 Nama Allah yang Indah. Ketuk kartu untuk melihat artinya.</p>
    ${renderAsmaulHusna()}
  `;
} else if (name === "Pengaturan") {
  }
}

let featureCloseTimer = null;

function closeFeature() {
  const page = document.getElementById("featurePage");
  setActiveTab(0);
  if (page.classList.contains("hidden")) return;
  const reduce = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;
  if (reduce) { page.classList.add("hidden"); return; }
  page.classList.add("closing");
  clearTimeout(featureCloseTimer);
  featureCloseTimer = setTimeout(() => {
    page.classList.add("hidden");
    page.classList.remove("closing");
  }, 230);
}

// ===== Al-Qur'an =====
let allSurahs = [];

async function loadSurahList() {
  const list = document.getElementById("surahList");
  if (!list) return;
  list.textContent = "Memuat daftar surah...";
  try {
    const response = await fetch("https://equran.id/api/v2/surat");
    if (!response.ok) throw new Error("Gagal memuat");
    const result = await response.json();
    allSurahs = result.data || [];
    renderSurahList(allSurahs);
  } catch (error) { list.textContent = "Gagal memuat surah. Periksa internet."; }
}

function renderSurahList(items) {
  const list = document.getElementById("surahList");
  if (!list) return;
  list.innerHTML = "";
  if (!items.length) { list.innerHTML = '<div class="surah-empty">Surah tidak ditemukan</div>'; return; }
  items.forEach(surah => {
    const card = document.createElement("button");
    card.className = "surah-card";
    card.innerHTML = `<span class="surah-card-no">${surah.nomor}</span><span class="surah-card-main"><b>${escapeHtml(surah.namaLatin)}</b><small>${escapeHtml(surah.arti || '')} • ${surah.jumlahAyat || ''} ayat</small></span><span class="surah-card-arab">${escapeHtml(surah.nama)}</span>`;
    card.onclick = () => loadSurah(surah.nomor);
    list.appendChild(card);
  });
}

function filterSurahList(query) {
  const q = (query || '').trim().toLowerCase();
  renderSurahList(allSurahs.filter(s => String(s.nomor).includes(q) || s.namaLatin.toLowerCase().includes(q) || (s.arti || '').toLowerCase().includes(q)));
}

async function loadSurah(number, scrollToAyat) {
  const content = document.getElementById("featureContent");
  document.getElementById("featurePage").classList.remove("hidden");
  setActiveTab(1);
  content.innerHTML = '<div class="quran-loading">' + ic('book') + '<br><span>Menyiapkan bacaan...</span></div>';

  try {
    const response = await fetch(`https://equran.id/api/v2/surat/${number}`);
    if (!response.ok) throw new Error("Gagal");
    const result = await response.json();
    const surah = result.data;
    const totalAyat = surah.jumlahAyat || surah.ayat.length;

    content.innerHTML = `
      <div class="surah-reader">
        <div class="reader-topbar">
          <button class="reader-back" onclick="showFeature('Al-Qur’an')">${ic("arrow-left")} <span>Daftar Surah</span></button>
          <button class="reader-bookmark" onclick="showFeature('Ayat Tersimpan')">${ic("bookmark")}</button>
        </div>
        <div class="surah-hero">
          <div class="surah-ornament">${ic("crescent")}</div>
          <div class="surah-number">SURAH ${surah.nomor}</div>
          <h2>${escapeHtml(surah.namaLatin)}</h2>
          <div class="surah-arabic-title">${escapeHtml(surah.nama)}</div>
          <p>${escapeHtml(surah.arti)}</p>
          <div class="surah-meta"><span>${escapeHtml(surah.tempatTurun || 'Al-Qur’an')}</span><i></i><span>${totalAyat} Ayat</span></div>
        </div>
        <div class="reader-controls">
          <div class="reader-control-label">Tampilan bacaan</div>
          <button class="font-control" onclick="changeQuranFont(-2)" aria-label="Perkecil tulisan">A−</button>
          <span id="fontSizeLabel">Normal</span>
          <button class="font-control" onclick="changeQuranFont(2)" aria-label="Perbesar tulisan">A+</button>
          <button id="translationToggle" class="translation-toggle active" onclick="toggleTranslation()">Terjemahan</button>
          <button id="focusToggle" class="reader-extra-btn" onclick="toggleFocusMode()">${ic("eye")} Mode fokus</button>
          <button id="surahAudioBtn" class="audio-toggle" onclick="toggleSurahAudio()">▶ Murottal</button>
          <button id="memorizeToggle" class="reader-extra-btn" onclick="toggleMemorization()">${ic("eye")} Mode hafalan</button>
          <button id="tajwidToggle" class="reader-extra-btn" onclick="toggleTajwidGuide()">${ic("sparkle")} Panduan tajwid</button>
        </div>
        <div id="ayatReader" class="ayat-reader"></div>
      </div>
    `;

    window.currentSurahAudio = (surah.audioFull && (surah.audioFull['01'] || surah.audioFull['02'] || Object.values(surah.audioFull)[0])) || (surah.ayat[0] && surah.ayat[0].audio && (ayatAudioUrl(surah.ayat[0])));
    window.currentAudioElement = null;

    const reader = document.getElementById('ayatReader');
    surah.ayat.forEach(ayat => {
      const block = document.createElement("article");
      block.className = "ayat-block premium-ayat";
      block.id = `ayat-${ayat.nomorAyat}`;
      const top = document.createElement('div');
      top.className = 'ayat-top';
      top.innerHTML = `<span class="ayat-number">${ayat.nomorAyat}</span>`;
      const arab = document.createElement("p");
      arab.className = "arab-ayat";
      arab.textContent = ayat.teksArab;
      const translation = document.createElement("p");
      translation.className = 'ayat-translation';
      translation.textContent = ayat.teksIndonesia;
      const actions = document.createElement('div');
      actions.className = 'ayat-actions';
      
      const save = document.createElement("button");
      const saved = isBookmarked(surah.nomor, ayat.nomorAyat);
      save.className = "bookmark-btn" + (saved ? " saved" : "");
      save.innerHTML = ic("bookmark", saved ? "fill" : "") + (saved ? " Tersimpan" : " Simpan ayat");
      save.onclick = () => toggleBookmark(surah, ayat, save);
      actions.appendChild(save);

      const shareBtn = document.createElement("button");
      shareBtn.className = "share-btn";
      shareBtn.innerHTML = ic("share") + " Bagikan";
      shareBtn.onclick = () => shareAyat(surah.namaLatin, ayat.nomorAyat, ayat.teksArab, ayat.teksIndonesia);
      actions.appendChild(shareBtn);

      const playAyat = document.createElement('button');
      playAyat.className = 'ayat-audio-btn';
      playAyat.textContent = '▶ Ulang 3x';
      const audioUrl = ayatAudioUrl(ayat);
      playAyat.disabled = !audioUrl;
      playAyat.onclick = () => playAyatRepeated(audioUrl, playAyat, 3);
      actions.appendChild(playAyat);

      const tafsir = document.createElement('button');
      tafsir.className = 'tafsir-btn';
      tafsir.innerHTML = ic('book') + ' Tafsir';
      tafsir.onclick = () => showAyatTafsir(surah.nomor, ayat.nomorAyat, block, tafsir);
      actions.appendChild(tafsir);
      
      block.append(top, arab, translation, actions);
      reader.appendChild(block);
    });

    window.quranFontSize = 28;
    window.quranTranslationVisible = true;
    window.focusMode = false;

    if (scrollToAyat) {
      const target = document.getElementById(`ayat-${scrollToAyat}`);
      if (target) {
        target.classList.add("highlight");
        setTimeout(() => target.scrollIntoView({ behavior: 'smooth', block: "center" }), 100);
      }
    }
  } catch (error) {
    content.innerHTML = '<div class="quran-error">' + ic('book') + '<h3>Surah belum bisa dimuat</h3><p>Periksa koneksi internet lalu coba lagi.</p><button onclick="showFeature(\'Al-Qur’an\')">Kembali ke daftar surah</button></div>';
  }
}

function ayatAudioUrl(ayat) {
  if (!ayat || !ayat.audio) return null;
  return ayat.audio['01'] || ayat.audio['02'] || Object.values(ayat.audio)[0] || null;
}

function toggleSurahAudio() {
  const btn = document.getElementById('surahAudioBtn');
  if (!window.currentSurahAudio) { if (btn) btn.textContent = 'Audio tidak tersedia'; return; }
  if (window.currentAudioElement && !window.currentAudioElement.paused) {
    window.currentAudioElement.pause(); if (btn) btn.textContent = '▶ Murottal'; return;
  }
  if (!window.currentAudioElement) {
    window.currentAudioElement = new Audio(window.currentSurahAudio);
    window.currentAudioElement.addEventListener('ended', () => { if (btn) btn.textContent = '▶ Murottal'; });
    window.currentAudioElement.addEventListener('error', () => { if (btn) btn.textContent = 'Audio gagal dimuat'; });
  }
  window.currentAudioElement.play().then(() => { if (btn) btn.innerHTML = ic('stop') + ' Jeda Murottal'; }).catch(() => { if (btn) btn.textContent = 'Audio gagal diputar'; });
}

function changeQuranFont(change) {
  window.quranFontSize = Math.max(22, Math.min(40, (window.quranFontSize || 28) + change));
  document.querySelectorAll('.premium-ayat .arab-ayat').forEach(el => el.style.fontSize = window.quranFontSize + 'px');
  const label = document.getElementById('fontSizeLabel');
  if (label) label.textContent = window.quranFontSize === 28 ? 'Normal' : window.quranFontSize > 28 ? 'Besar' : 'Kecil';
}

function applyReaderView() {
  const reader = document.getElementById('ayatReader');
  if (reader) reader.classList.toggle('focus-mode', !!window.focusMode);
  document.querySelectorAll('.ayat-translation').forEach(el =>
    el.classList.toggle('translation-hidden', !window.quranTranslationVisible || !!window.focusMode));
}

function toggleTranslation() {
  window.quranTranslationVisible = !window.quranTranslationVisible;
  applyReaderView();
  const button = document.getElementById('translationToggle');
  if (button) {
    button.classList.toggle('active', window.quranTranslationVisible);
    button.textContent = window.quranTranslationVisible ? 'Terjemahan' : 'Terjemahan mati';
  }
}

function toggleFocusMode() {
  window.focusMode = !window.focusMode;
  applyReaderView();
  const btn = document.getElementById('focusToggle');
  if (btn) {
    btn.classList.toggle('active', window.focusMode);
    btn.innerHTML = ic('eye') + (window.focusMode ? ' Keluar fokus' : ' Mode fokus');
  }
  if (window.focusMode) {
    const reader = document.getElementById('ayatReader');
    if (reader) reader.scrollIntoView({ behavior: 'smooth', block: 'start' });
    showToast('Mode fokus: hanya teks Arab yang ditampilkan.');
  } else {
    showToast('Mode normal kembali.');
  }
}

window.memorizationMode = false;
window.tajwidGuideVisible = false;
window.ayatRepeatAudio = null;

function toggleMemorization() {
  window.memorizationMode = !window.memorizationMode;
  document.querySelectorAll('.premium-ayat .arab-ayat').forEach(el => el.classList.toggle('memorize-hidden', window.memorizationMode));
  const btn = document.getElementById('memorizeToggle');
  if (btn) btn.innerHTML = window.memorizationMode ? ic('eye') + ' Tampilkan ayat' : ic('eye') + ' Mode hafalan';
  showToast(window.memorizationMode ? 'Teks Arab disembunyikan. Coba hafalkan ayatnya!' : 'Teks Arab ditampilkan kembali.');
}

function toggleTajwidGuide() {
  window.tajwidGuideVisible = !window.tajwidGuideVisible;
  let panel = document.getElementById('tajwidGuidePanel');
  if (!panel) {
    panel = document.createElement('section');
    panel.id = 'tajwidGuidePanel';
    panel.className = 'tajwid-guide-panel';
    document.querySelector('.surah-reader')?.insertBefore(panel, document.getElementById('ayatReader'));
  }
  panel.innerHTML = window.tajwidGuideVisible ? `<h3>${ic("sparkle")} Panduan warna tajwid</h3>
    <p>Gunakan panduan ini saat belajar. Penandaan warna otomatis pada teks ayat belum diaktifkan karena harus memakai data tajwid terverifikasi agar tidak salah menandai bacaan.</p>
    <div class="tajwid-legend"><span><i class="tajwid-dot ikhfa"></i> Ikhfa</span><span><i class="tajwid-dot idgham"></i> Idgham</span><span><i class="tajwid-dot iqlab"></i> Iqlab</span><span><i class="tajwid-dot mad"></i> Mad</span></div>` : '';
  panel.classList.toggle('hidden', !window.tajwidGuideVisible);
  const btn = document.getElementById('tajwidToggle');
  if (btn) btn.innerHTML = window.tajwidGuideVisible ? 'Tutup panduan tajwid' : ic('sparkle') + ' Panduan tajwid';
}

function playAyatRepeated(url, button, repeatCount=3) {
  if (!url) return;
  if (window.ayatRepeatAudio) { window.ayatRepeatAudio.pause(); window.ayatRepeatAudio = null; }
  const audio = new Audio(url);
  window.ayatRepeatAudio = audio;
  let played = 0;
  button.disabled = true;
  button.textContent = 'Memutar…';
  audio.addEventListener('ended', () => {
    played++;
    if (played < repeatCount) audio.play().catch(() => finish());
    else finish();
  });
  audio.addEventListener('error', finish);
  function finish() {
    button.disabled = false;
    button.textContent = '▶ Ulang 3x';
    if (window.ayatRepeatAudio === audio) window.ayatRepeatAudio = null;
  }
  audio.play().catch(() => { finish(); showToast('Audio ayat gagal diputar. Periksa koneksi internet.'); });
}

async function showAyatTafsir(surahNo, ayatNo, block, button) {
  let panel = block.querySelector('.tafsir-panel');
  if (panel) { panel.remove(); button.innerHTML = ic('book') + ' Tafsir'; return; }
  panel = document.createElement('div');
  panel.className = 'tafsir-panel';
  panel.textContent = 'Memuat tafsir…';
  block.appendChild(panel);
  button.textContent = 'Tutup tafsir';
  try {
    const response = await fetch(`https://equran.id/api/v2/tafsir/${surahNo}`);
    if (!response.ok) throw new Error('Tafsir tidak tersedia');
    const result = await response.json();
    const items = result.data?.tafsir || [];
    const item = items.find(x => Number(x.ayat) === Number(ayatNo));
    panel.textContent = item?.teks || 'Tafsir untuk ayat ini belum tersedia dari sumber data.';
    const source = document.createElement('small');
    source.textContent = 'Sumber: data tafsir dari API equran.id';
    panel.appendChild(source);
  } catch (e) {
    panel.textContent = 'Tafsir belum bisa dimuat. Periksa koneksi internet lalu coba lagi.';
  }
}

function updateNurTimeMiniDashboard() {
  const target = document.getElementById('nurtimeDailyAyah');
  if (!target) return;
  const ayat = [
    ['QS. Al-Baqarah: 286', 'Allah tidak membebani seseorang melainkan sesuai dengan kesanggupannya.'],
    ['QS. Ar-Ra’d: 28', 'Hanya dengan mengingat Allah hati menjadi tenteram.'],
    ['QS. Al-Insyirah: 5', 'Sesungguhnya bersama kesulitan ada kemudahan.']
  ];
  const day = Math.floor(Date.now() / 86400000) % ayat.length;
  target.innerHTML = `<strong>${ayat[day][0]}</strong><p>${ayat[day][1]}</p>`;
}

// ===== Kalender Hijriah & Puasa =====
const HIJRI_MONTHS = ["Muharram", "Safar", "Rabiul Awal", "Rabiul Akhir", "Jumadil Awal", "Jumadil Akhir", "Rajab", "Syaban", "Ramadan", "Syawal", "Dzulkaidah", "Dzulhijjah"];
const MONTH_ID = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];
const MONTH_SHORT = ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des"];
const DAY_SHORT = ["Min", "Sen", "Sel", "Rab", "Kam", "Jum", "Sab"];
const DAY_LONG = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];

const HARI_BESAR = [
  { m: 1, d: 1, name: "Tahun Baru Islam" }, { m: 1, d: 10, name: "Hari Asyura" },
  { m: 3, d: 12, name: "Maulid Nabi Muhammad" }, { m: 7, d: 27, name: "Isra Mi'raj" },
  { m: 8, d: 15, name: "Nisfu Syaban" }, { m: 9, d: 1, name: "Awal Ramadan" },
  { m: 9, d: 17, name: "Nuzulul Qur'an" }, { m: 10, d: 1, name: "Idul Fitri" },
  { m: 12, d: 9, name: "Hari Arafah" }, { m: 12, d: 10, name: "Idul Adha" },
  { m: 12, d: 11, d2: 13, name: "Hari Tasyrik" }
];

const HIJRI_FMT = new Intl.DateTimeFormat("en-u-ca-islamic-umalqura-nu-latn", {
  day: "numeric", month: "numeric", year: "numeric", timeZone: "UTC"
});

let calView = { y: 2026, m: 0 };
let calSel = null;

function keyToUtc(key) {
  const [y, m, d] = key.split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, d, 12));
}

function pad2(n) { return String(n).padStart(2, "0"); }

function hijriOfKey(key) {
  const t = keyToUtc(key).getTime() + (Number(settings.hijriAdjust) || 0) * 86400000;
  const parts = HIJRI_FMT.formatToParts(new Date(t));
  const get = type => Number(parts.find(p => p.type === type).value);
  return { d: get("day"), m: get("month"), y: get("year") };
}

function hijriLabel(h) { return `${h.d} ${HIJRI_MONTHS[h.m - 1]} ${h.y} H`; }
function dayOfWeek(key) { return keyToUtc(key).getUTCDay(); }
function longDateLabel(key) { const d = keyToUtc(key); return `${DAY_LONG[d.getUTCDay()]}, ${d.getUTCDate()} ${MONTH_ID[d.getUTCMonth()]} ${d.getUTCFullYear()}`; }
function shortDateLabel(key) { const d = keyToUtc(key); return `${DAY_SHORT[d.getUTCDay()]}, ${d.getUTCDate()} ${MONTH_SHORT[d.getUTCMonth()]}`; }

function eventsFor(h) {
  return HARI_BESAR.filter(e => e.m === h.m && (e.d2 ? h.d >= e.d && h.d <= e.d2 : e.d === h.d));
}

function fastInfo(key, h) {
  if (h.m === 10 && h.d === 1) return { kind: "haram", text: "Hari Idul Fitri: tidak boleh berpuasa" };
  if (h.m === 12 && h.d === 10) return { kind: "haram", text: "Hari Idul Adha: tidak boleh berpuasa" };
  if (h.m === 12 && h.d >= 11 && h.d <= 13) return { kind: "haram", text: "Hari Tasyrik: tidak boleh berpuasa" };
  if (h.m === 9) return { kind: "wajib", text: "Puasa Ramadan (wajib)" };
  const dow = dayOfWeek(key);
  const list = [];
  if (h.m === 12 && h.d === 9) list.push("Puasa Arafah");
  if (h.m === 1 && h.d === 9) list.push("Puasa Tasua");
  if (h.m === 1 && h.d === 10) list.push("Puasa Asyura");
  if (h.d >= 13 && h.d <= 15) list.push("Ayyamul Bidh");
  if (h.m === 10 && h.d >= 2) list.push("Puasa 6 hari Syawal");
  if (dow === 1) list.push("Puasa Senin");
  if (dow === 4) list.push("Puasa Kamis");
  return list.length ? { kind: "sunnah", text: "Puasa sunnah: " + list.join(", ") } : { kind: "none", text: "" };
}

let nextHariBesarCache = { key: "", result: null };
function nextHariBesar() {
  const start = todayKey();
  if (nextHariBesarCache.key === start) return nextHariBesarCache.result;
  let result = null;
  for (let i = 0; i < 400; i++) {
    const key = addDays(start, i);
    const ev = eventsFor(hijriOfKey(key));
    if (ev.length) { result = { key, i, ev: ev[0] }; break; }
  }
  nextHariBesarCache = { key: start, result };
  return result;
}

function isRamadanMode() {
  try { return hijriOfKey(todayKey()).m === 9; } catch (e) { return false; }
}

function applyRamadanMode() {
  const on = isRamadanMode() && todayPrayers.length > 0;
  document.documentElement.setAttribute("data-ramadan", on ? "on" : "off");
  const banner = document.getElementById("ramadanBanner");
  if (banner) {
    banner.classList.toggle("show", on);
    if (on) renderRamadanBanner();
  }
}

function renderRamadanBanner() {
  if (!isRamadanMode() || !todayPrayers.length) return;
  const key = todayKey();
  const h = hijriOfKey(key);
  const dayEl = document.getElementById("ramadanDay");
  if (dayEl) dayEl.textContent = `Hari ke-${h.d} Ramadan ${h.y} H`;
  const imsakEl = document.getElementById("ramadanImsak");
  if (imsakEl && todayImsak) imsakEl.textContent = formatTime(todayImsak);
  const maghrib = todayPrayers.find(p => p.key === "Maghrib");
  const bukaEl = document.getElementById("ramadanBuka");
  if (bukaEl && maghrib) bukaEl.textContent = formatTime(maghrib.time);
  const countEl = document.getElementById("ramadanCount");
  if (countEl) {
    let lastDay = 30;
    for (let d = 1; d <= 30; d++) {
      const probe = addDays(key, (30 - h.d) + d);
      if (hijriOfKey(probe).m !== 9) { lastDay = d - 1; break; }
    }
    countEl.textContent = `${Math.max(0, lastDay - h.d)} hari`;
  }
}

function updateIslamicInfo() {
  const el = document.getElementById("islamicInfo");
  if (!el) return;
  const key = todayKey();
  const h = hijriOfKey(key);
  const fi = fastInfo(key, h);
  const next = nextHariBesar();
  let nextText = "";
  if (next) nextText = next.i === 0 ? `Hari ini: ${next.ev.name}` : `${next.ev.name}, ${next.i} hari lagi`;
  el.innerHTML = `<div class="info-top">${ic("crescent")} <strong>${hijriLabel(h)}</strong></div>` + (nextText ? `<p>${ic("calendar")} ${escapeHtml(nextText)}</p>` : "") + (fi.text ? `<p>${ic("moon")} ${escapeHtml(fi.text)}</p>` : "");
}

// (Kalender & Puasa UI tetap seperti aslinya, disingkat karena panjang)
function renderCalendarPage(content) {
  const key = todayKey();
  const [y, m] = key.split("-").map(Number);
  calView = { y, m: m - 1 };
  calSel = key;
  content.innerHTML = `<h3>${ic("crescent")} Kalender Hijriah</h3><div id="calBody"></div>`;
  renderHijriCalendar();
}

function calShift(n) { let m = calView.m + n; let y = calView.y; while (m < 0) { m += 12; y--; } while (m > 11) { m -= 12; y++; } calView = { y, m }; calSel = null; renderHijriCalendar(); }
function calGoToday() { const key = todayKey(); const [y, m] = key.split("-").map(Number); calView = { y, m: m - 1 }; calSel = key; renderHijriCalendar(); }
function selectCalDay(key) { calSel = key; renderHijriCalendar(); }
function setHijriAdjust(value) { settings.hijriAdjust = Number(value) || 0; saveSettings(); nextHariBesarCache = { key: "", result: null }; renderHijriCalendar(); updateIslamicInfo(); applyRamadanMode(); }

function calDetailHtml(key) {
  const h = hijriOfKey(key); const ev = eventsFor(h); const fi = fastInfo(key, h); const marked = fasting.days[key];
  let html = `<div class="cal-detail"><strong>${longDateLabel(key)}</strong><div>${hijriLabel(h)}</div>`;
  ev.forEach(e => { html += `<p class="cal-ev">${ic("sparkle")} ${escapeHtml(e.name)}</p>`; });
  if (fi.text) html += `<p class="cal-fast ${fi.kind}">${ic("moon")} ${escapeHtml(fi.text)}</p>`;
  if (key <= todayKey()) html += marked ? `<button class="small-btn" onclick="toggleFast('${key}')">Batalkan tanda puasa (${FAST_TYPES[marked]})</button>` : `<button class="small-btn" onclick="toggleFast('${key}')">Tandai sudah berpuasa</button>`;
  return html + "</div>";
}

function renderHijriCalendar() {
  const body = document.getElementById("calBody"); if (!body) return;
  const { y, m } = calView; const dim = new Date(Date.UTC(y, m + 1, 0)).getUTCDate(); const lead = new Date(Date.UTC(y, m, 1, 12)).getUTCDay(); const keyOf = d => `${y}-${pad2(m + 1)}-${pad2(d)}`; const tKey = todayKey();
  const h1 = hijriOfKey(keyOf(1)); const h2 = hijriOfKey(keyOf(dim)); let hijriRange;
  if (h1.y !== h2.y) hijriRange = `${HIJRI_MONTHS[h1.m - 1]} ${h1.y} - ${HIJRI_MONTHS[h2.m - 1]} ${h2.y} H`;
  else if (h1.m !== h2.m) hijriRange = `${HIJRI_MONTHS[h1.m - 1]} - ${HIJRI_MONTHS[h2.m - 1]} ${h1.y} H`;
  else hijriRange = `${HIJRI_MONTHS[h1.m - 1]} ${h1.y} H`;
  let cells = ""; for (let i = 0; i < lead; i++) cells += `<span class="cal-blank"></span>`;
  const monthEvents = []; const ayyam = {};
  for (let d = 1; d <= dim; d++) {
    const key = keyOf(d); const h = hijriOfKey(key); const ev = eventsFor(h); ev.forEach(e => monthEvents.push({ key, h, e }));
    if (h.d >= 13 && h.d <= 15 && h.m !== 9 && fastInfo(key, h).kind !== "haram") (ayyam[h.m] = ayyam[h.m] || []).push(key);
    const cls = ["cal-cell", key === tKey ? "today" : "", key === calSel ? "sel" : "", ev.length ? "ev" : "", fasting.days[key] ? "fasted" : ""].filter(Boolean).join(" ");
    const small = h.d === 1 ? `1 ${HIJRI_MONTHS[h.m - 1].slice(0, 3)}` : h.d;
    cells += `<button class="${cls}" onclick="selectCalDay('${key}')"><b>${d}</b><small>${small}</small></button>`;
  }
  const eventList = monthEvents.length ? monthEvents.map(({ key, h, e }) => `<li><span>${shortDateLabel(key)}</span><em>${escapeHtml(e.name)}</em><small>${h.d} ${HIJRI_MONTHS[h.m - 1]}</small></li>`).join("") : `<li class="cal-empty">Tidak ada hari besar bulan ini.</li>`;
  const ayyamList = Object.values(ayyam).map(keys => { const first = keyToUtc(keys[0]); const last = keyToUtc(keys[keys.length - 1]); const text = keys.length === 1 || first.getUTCDate() === last.getUTCDate() ? `${first.getUTCDate()} ${MONTH_SHORT[first.getUTCMonth()]}` : `${first.getUTCDate()}-${last.getUTCDate()} ${MONTH_SHORT[last.getUTCMonth()]}`; return `<li><span>Ayyamul Bidh</span><em>${text}</em></li>`; }).join("");
  const adjustOptions = [-2, -1, 0, 1, 2].map(v => `<option value="${v}" ${(Number(settings.hijriAdjust) || 0) === v ? "selected" : ""}>${v > 0 ? "+" + v : v} hari</option>`).join("");
  body.innerHTML = `
    <div class="cal-nav"><button class="cal-nav-btn" onclick="calShift(-1)">${ic("arrow-left")}</button><div class="cal-title"><strong>${MONTH_ID[m]} ${y}</strong><small>${hijriRange}</small></div><button class="cal-nav-btn" onclick="calShift(1)">${ic("arrow-right")}</button></div>
    <div class="cal-grid">${DAY_SHORT.map(n => `<span class="cal-dow">${n}</span>`).join("")}${cells}</div>
    <button class="small-btn cal-today-btn" onclick="calGoToday()">Hari ini</button>
    ${calSel ? calDetailHtml(calSel) : ""}
    <h4>Hari besar bulan ini</h4><ul class="cal-list">${eventList}${ayyamList}</ul>
    <label class="setting-row"><span>Koreksi tanggal Hijriah</span><select onchange="setHijriAdjust(this.value)">${adjustOptions}</select></label>
    <p class="setting-note">Tanggal dihitung dengan kalender Umm al-Qura, bisa berbeda satu hari dari ketetapan pemerintah (sidang isbat).</p>
  `;
}

const FAST_KEY = "nurtime_fasting";
const FAST_TYPES = { ramadan: "Ramadan", sunnah: "Sunnah", qadha: "Qadha", nazar: "Nazar" };
function loadFasting() { const saved = storageGet(FAST_KEY, {}); return { days: saved && typeof saved.days === "object" && saved.days ? saved.days : {}, owed: Math.max(0, Number(saved && saved.owed) || 0) }; }
let fasting = loadFasting(); let fastTab = "tracker"; let imsakMode = "ramadan"; let imsakToken = 0;
function saveFasting() { storageSet(FAST_KEY, fasting); }
function defaultFastType(key) { return hijriOfKey(key).m === 9 ? "ramadan" : "sunnah"; }
function fastStreak() { let key = todayKey(); if (!fasting.days[key]) key = addDays(key, -1); let n = 0; while (fasting.days[key]) { n++; key = addDays(key, -1); } return n; }
function toggleFast(key, type) {
  if (key > todayKey()) { showToast("Belum bisa menandai hari yang belum terjadi."); return; }
  if (fasting.days[key]) delete fasting.days[key];
  else {
    if (fastInfo(key, hijriOfKey(key)).kind === "haram") { showToast("Pada hari ini tidak boleh berpuasa."); return; }
    fasting.days[key] = FAST_TYPES[type] ? type : defaultFastType(key);
  }
  saveFasting(); refreshFastViews();
}
function toggleFastToday() { const select = document.getElementById("fastType"); toggleFast(todayKey(), select ? select.value : undefined); }
function changeOwed(n) { fasting.owed = Math.max(0, fasting.owed + n); saveFasting(); renderFastTab(); }
function refreshFastViews() { if (document.getElementById("calBody")) renderHijriCalendar(); if (document.getElementById("fastBody") && fastTab === "tracker") renderFastTracker(); }
function renderFastPage(content) { content.innerHTML = `<h3>${ic("moon")} Puasa</h3><div class="seg"><button class="seg-btn" id="fastTabTracker" onclick="setFastTab('tracker')">Tracker</button><button class="seg-btn" id="fastTabImsak" onclick="setFastTab('imsak')">Imsakiyah</button></div><div id="fastBody"></div>`; renderFastTab(); }
function setFastTab(tab) { fastTab = tab; renderFastTab(); }
function renderFastTab() {
  const a = document.getElementById("fastTabTracker"); const b = document.getElementById("fastTabImsak");
  if (a) a.classList.toggle("active", fastTab === "tracker"); if (b) b.classList.toggle("active", fastTab === "imsak");
  if (fastTab === "tracker") { imsakToken++; renderFastTracker(); } else renderImsakiyah();
}

function renderFastTracker() {
  const body = document.getElementById("fastBody"); if (!body) return;
  const key = todayKey(); const h = hijriOfKey(key); const fi = fastInfo(key, h); const marked = fasting.days[key]; const maghrib = todayPrayers.find(p => p.key === "Maghrib");
  const times = todayImsak && maghrib ? `Imsak ${formatTime(todayImsak)} &middot; Berbuka ${formatTime(maghrib.time)} ${tzLabel()}` : "Jadwal imsak belum dimuat";
  const all = Object.values(fasting.days); const monthCount = Object.keys(fasting.days).filter(k => k.startsWith(key.slice(0, 7))).length; const ramadanCount = all.filter(t => t === "ramadan").length; const paid = all.filter(t => t === "qadha").length; const remaining = Math.max(0, fasting.owed - paid);
  const typeOptions = Object.entries(FAST_TYPES).map(([v, label]) => `<option value="${v}" ${v === defaultFastType(key) ? "selected" : ""}>${label}</option>`).join("");
  let history = "";
  for (let i = 13; i >= 0; i--) {
    const k = addDays(key, -i); const d = keyToUtc(k);
    history += `<button class="fast-chip ${fasting.days[k] ? "done" : ""}" onclick="toggleFast('${k}')"><small>${DAY_SHORT[d.getUTCDay()]}</small><b>${d.getUTCDate()}</b></button>`;
  }
  body.innerHTML = `
    <div class="fast-today"><strong>${hijriLabel(h)}</strong><div class="fast-times">${times}</div>${fi.text ? `<p class="cal-fast ${fi.kind}">${ic("moon")} ${escapeHtml(fi.text)}</p>` : ""}${marked ? `<p>Hari ini tercatat: puasa ${FAST_TYPES[marked]}.</p>` : `<label class="setting-row"><span>Jenis puasa</span><select id="fastType">${typeOptions}</select></label>`}<button onclick="toggleFastToday()">${marked ? "Batalkan tanda puasa hari ini" : "Saya berpuasa hari ini"}</button></div>
    <div class="fast-stats"><div><strong>${monthCount}</strong><small>Bulan ini</small></div><div><strong>${all.length}</strong><small>Total</small></div><div><strong>${fastStreak()}</strong><small>Beruntun</small></div><div><strong>${ramadanCount}</strong><small>Ramadan</small></div></div>
    <h4>14 hari terakhir</h4><div class="fast-history">${history}</div><p class="setting-note">Ketuk tanggal untuk menandai atau membatalkan.</p>
    <h4>Utang puasa (qadha)</h4><div class="setting-row"><span>Jumlah utang</span><span class="owed-ctrl"><button class="small-btn" onclick="changeOwed(-1)">-</button><strong>${fasting.owed}</strong><button class="small-btn" onclick="changeOwed(1)">+</button></span></div><p class="setting-note">Sudah diganti: ${paid} hari &middot; Sisa: ${remaining} hari.</p>
  `;
}

const monthRawCache = {};
let lastCacheLocationKey = "";
function clearMonthCacheIfLocationChanged() {
  const locKey = `${userLocation.lat},${userLocation.lng},${currentMethod() || 0}`;
  if (lastCacheLocationKey && lastCacheLocationKey !== locKey) Object.keys(monthRawCache).forEach(k => delete monthRawCache[k]);
  lastCacheLocationKey = locKey;
}

async function fetchMonthRaw(y, m) {
  clearMonthCacheIfLocationChanged();
  const method = currentMethod(); const id = `${userLocation.lat},${userLocation.lng},${method || 0},${adjustSig()},${y}-${m}`;
  if (monthRawCache[id]) return monthRawCache[id];
  const url = `https://api.aladhan.com/v1/calendar/${y}/${m}?latitude=${userLocation.lat}&longitude=${userLocation.lng}` + (method ? `&method=${method}` : "") + `&school=${currentSchool()}&timezonestring=${encodeURIComponent(userLocation.tz)}`;
  const response = await fetch(url); if (!response.ok) throw new Error("Gagal mengambil jadwal.");
  const result = await response.json(); if (result.code !== 200 || !Array.isArray(result.data)) throw new Error("Data tidak tersedia.");
  const adjusted = result.data.map(i => ({ ...i, timings: adjustTimings(i.timings) })); monthRawCache[id] = adjusted; return adjusted;
}

async function fetchMonthCalendar(y, m) {
  const raw = await fetchMonthRaw(y, m); const map = {};
  raw.forEach(item => { const [dd, mm, yy] = item.date.gregorian.date.split("-"); map[`${yy}-${mm}-${dd}`] = item.timings; });
  return map;
}

function imsakRange(mode) {
  const start = todayKey(); const keys = [];
  if (mode === "30") { for (let i = 0; i < 30; i++) keys.push(addDays(start, i)); return { keys, title: "30 hari ke depan" }; }
  let first = null; const now = hijriOfKey(start);
  if (now.m === 9) first = addDays(start, -(now.d - 1));
  else { for (let i = 0; i < 400; i++) { const k = addDays(start, i); const h = hijriOfKey(k); if (h.m === 9 && h.d === 1) { first = k; break; } } }
  if (!first) return null;
  for (let i = 0; i < 31; i++) { const k = addDays(first, i); if (hijriOfKey(k).m !== 9) break; keys.push(k); }
  return { keys, title: `Ramadan ${hijriOfKey(first).y} H` };
}

function setImsakMode(value) { imsakMode = value === "30" ? "30" : "ramadan"; renderImsakiyah(); }

async function renderImsakiyah() {
  const body = document.getElementById("fastBody"); if (!body) return;
  const token = ++imsakToken;
  body.innerHTML = `<label class="setting-row"><span>Tampilkan</span><select onchange="setImsakMode(this.value)"><option value="ramadan" ${imsakMode === "ramadan" ? "selected" : ""}>Ramadan</option><option value="30" ${imsakMode === "30" ? "selected" : ""}>30 hari ke depan</option></select></label><div id="imsakTable"><p>Memuat jadwal...</p></div>`;
  const box = document.getElementById("imsakTable"); const range = imsakRange(imsakMode);
  if (!range || !range.keys.length) { box.innerHTML = "<p>Ramadan berikutnya belum ditemukan.</p>"; return; }
  try {
    const months = [...new Set(range.keys.map(k => k.slice(0, 7)))];
    const maps = await Promise.all(months.map(ym => { const [y, m] = ym.split("-").map(Number); return fetchMonthCalendar(y, m); }));
    if (token !== imsakToken || fastTab !== "imsak") return;
    const merged = Object.assign({}, ...maps); const today = todayKey(); const ramadan = imsakMode === "ramadan";
    const rows = range.keys.map(k => {
      const t = merged[k]; const h = hijriOfKey(k); const first = ramadan ? h.d : `${h.d}/${h.m}`;
      return `<tr class="${k === today ? "today" : ""}"><td>${first}</td><td>${shortDateLabel(k)}</td><td>${t ? formatTime(t.Imsak) : "--:--"}</td><td>${t ? formatTime(t.Fajr) : "--:--"}</td><td>${t ? formatTime(t.Maghrib) : "--:--"}</td></tr>`;
    }).join("");
    const firstDay = keyToUtc(range.keys[0]); const lastDay = keyToUtc(range.keys[range.keys.length - 1]);
    const span = `${firstDay.getUTCDate()} ${MONTH_SHORT[firstDay.getUTCMonth()]} - ${lastDay.getUTCDate()} ${MONTH_SHORT[lastDay.getUTCMonth()]} ${lastDay.getUTCFullYear()}`;
    box.innerHTML = `<p><strong>${range.title}</strong> &middot; ${span}</p><p class="setting-note">${escapeHtml(shortLocationName())} (${tzLabel()})</p><div class="table-scroll"><table class="imsak-table"><thead><tr><th>${ramadan ? "Ramadan" : "Hijriah"}</th><th>Tanggal</th><th>Imsak</th><th>Subuh</th><th>Berbuka</th></tr></thead><tbody>${rows}</tbody></table></div>`;
  } catch (error) {
    if (token !== imsakToken || fastTab !== "imsak") return;
    box.innerHTML = `<p style="color:#c66">Jadwal belum bisa dimuat. Periksa internet lalu coba lagi.</p><button onclick="renderImsakiyah()">Coba lagi</button>`;
  }
}

// ===== Suara Adzan & Subtitle =====
const ADZAN_GRACE_MS = 2 * 60 * 1000;
const ADZAN_DB = "nurtime_audio"; const ADZAN_STORE = "files"; const ADZAN_ID = "custom_adzan";
const SILENT_WAV = "data:audio/wav;base64,UklGRnQAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YVAAAACAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgA==";
const adzanAudio = new Audio(); adzanAudio.preload = "auto";
let adzanBlobUrl = null; let adzanPlaying = false; let audioUnlocked = false; let audioCtx = null; let chimeNodes = []; let chimeTimer = null;
let adzanSubtitleTimer = null; let adzanSubtitleIndex = 0;
const ADZAN_TEXT = [
  { ar: "Allahu Akbar, Allahu Akbar", id: "Allah Maha Besar" },
  { ar: "Allahu Akbar, Allahu Akbar", id: "Allah Maha Besar" },
  { ar: "Asyhadu allaa ilaaha illallah", id: "Aku bersaksi tiada Tuhan selain Allah" },
  { ar: "Asyhadu allaa ilaaha illallah", id: "Aku bersaksi tiada Tuhan selain Allah" },
  { ar: "Asyhadu anna Muhammadar Rasulullah", id: "Aku bersaksi Muhammad adalah Rasul Allah" },
  { ar: "Asyhadu anna Muhammadar Rasulullah", id: "Aku bersaksi Muhammad adalah Rasul Allah" },
  { ar: "Hayya 'alash shalaah", id: "Mari sholat" },
  { ar: "Hayya 'alash shalaah", id: "Mari sholat" },
  { ar: "Hayya 'alal falaah", id: "Mari menuju keberuntungan" },
  { ar: "Hayya 'alal falaah", id: "Mari menuju keberuntungan" },
  { ar: "Allahu Akbar, Allahu Akbar", id: "Allah Maha Besar" },
  { ar: "Allahu Akbar, Allahu Akbar", id: "Allah Maha Besar" },
  { ar: "Laa ilaaha illallah", id: "Tiada Tuhan selain Allah" }
];

function idbOpen() { return new Promise((resolve, reject) => { if (!window.indexedDB) { reject(new Error("IndexedDB tidak tersedia")); return; } const req = indexedDB.open(ADZAN_DB, 1); req.onupgradeneeded = () => req.result.createObjectStore(ADZAN_STORE); req.onsuccess = () => resolve(req.result); req.onerror = () => reject(req.error); }); }
async function idbRun(mode, action) { const db = await idbOpen(); return new Promise((resolve, reject) => { const tx = db.transaction(ADZAN_STORE, mode); const req = action(tx.objectStore(ADZAN_STORE)); tx.oncomplete = () => resolve(req ? req.result : undefined); tx.onerror = () => reject(tx.error); tx.onabort = () => reject(tx.error); }); }
async function initAdzanFile() { try { const blob = await idbRun("readonly", store => store.get(ADZAN_ID)); if (blob) { adzanBlobUrl = URL.createObjectURL(blob); if (document.getElementById("notifAdzanBody") || document.getElementById("settingsBody")) { renderSettings(); if (document.getElementById("notifAdzanBody")) renderNotifAdzanPage(); } } } catch (error) {} }
async function onAdzanFile(input) {
  const file = input.files && input.files[0]; input.value = ""; if (!file) return;
  const looksAudio = file.type.startsWith("audio/") || /\.(mp3|m4a|aac|ogg|wav)$/i.test(file.name);
  if (!looksAudio) { showToast("Pilih file audio (mp3, m4a, ogg, atau wav)."); return; }
  if (file.size > 15 * 1024 * 1024) { showToast("File terlalu besar. Maksimal 15 MB."); return; }
  try { await idbRun("readwrite", store => store.put(file, ADZAN_ID)); if (adzanBlobUrl) URL.revokeObjectURL(adzanBlobUrl); adzanBlobUrl = URL.createObjectURL(file); settings.adzan.fileName = file.name; saveSettings(); showToast("Suara adzan disimpan di perangkat ini."); renderSettings(); if (document.getElementById("notifAdzanBody")) renderNotifAdzanPage(); } catch (error) { showToast("File gagal disimpan. Penyimpanan browser mungkin penuh atau diblokir."); }
}
async function removeAdzanFile() { try { await idbRun("readwrite", store => store.delete(ADZAN_ID)); } catch (error) {} if (adzanBlobUrl) URL.revokeObjectURL(adzanBlobUrl); adzanBlobUrl = null; settings.adzan.fileName = ""; saveSettings(); renderSettings(); if (document.getElementById("notifAdzanBody")) renderNotifAdzanPage(); }

function unlockAudio() {
  if (audioUnlocked || adzanPlaying) return;
  audioUnlocked = true;
  try { const AC = window.AudioContext || window.webkitAudioContext; if (AC) { audioCtx = audioCtx || new AC(); if (audioCtx.resume) audioCtx.resume(); } } catch (error) { audioUnlocked = false; return; }
  try {
    adzanAudio.muted = true; adzanAudio.src = SILENT_WAV;
    const p = adzanAudio.play();
    if (p && p.then) { p.then(() => { adzanAudio.pause(); adzanAudio.muted = false; }).catch(() => { adzanAudio.muted = false; audioUnlocked = false; }); } else { adzanAudio.pause(); adzanAudio.muted = false; }
  } catch (error) { adzanAudio.muted = false; audioUnlocked = false; }
}
["pointerdown", "keydown", "touchstart"].forEach(name => document.addEventListener(name, unlockAudio, { passive: true }));

function showAdzanBar(label) {
  let bar = document.getElementById("adzanBar");
  if (!bar) { bar = document.createElement("div"); bar.id = "adzanBar"; bar.className = "adzan-bar"; document.body.appendChild(bar); }
  bar.innerHTML = `<div class="adzan-header"><span>${ic("volume")} Adzan ${escapeHtml(label)}</span><button onclick="stopAdzan()">${ic("stop")} Hentikan</button></div><div class="adzan-subtitle show" id="adzanSubtitle"></div>`;
  bar.classList.add("show");
  adzanSubtitleIndex = 0; rotateAdzanSubtitle();
}

function rotateAdzanSubtitle() {
  clearTimeout(adzanSubtitleTimer);
  const el = document.getElementById("adzanSubtitle"); if (!el) return;
  const line = ADZAN_TEXT[adzanSubtitleIndex % ADZAN_TEXT.length];
  el.innerHTML = `<div class="adzan-arab">${line.ar}</div><small>${line.id}</small>`;
  adzanSubtitleIndex++; adzanSubtitleTimer = setTimeout(rotateAdzanSubtitle, 6000);
}

function hideAdzanBar() { const bar = document.getElementById("adzanBar"); if (bar) bar.classList.remove("show"); clearTimeout(adzanSubtitleTimer); adzanSubtitleTimer = null; }
function stopAdzan(keepBar) { try { adzanAudio.pause(); adzanAudio.currentTime = 0; } catch (error) {} chimeNodes.forEach(node => { try { node.stop(); } catch (error) {} }); chimeNodes = []; if (chimeTimer) clearTimeout(chimeTimer); chimeTimer = null; adzanPlaying = false; if (keepBar !== true) hideAdzanBar(); }
adzanAudio.addEventListener("ended", () => { adzanPlaying = false; hideAdzanBar(); });

function playChime() {
  try {
    const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return false;
    audioCtx = audioCtx || new AC(); if (audioCtx.state === "suspended") audioCtx.resume();
    const start = audioCtx.currentTime + 0.05; const peak = 0.25 * Math.min(1, Math.max(0.05, settings.adzan.volume));
    [523.25, 659.25, 783.99, 1046.5].forEach((freq, i) => {
      const osc = audioCtx.createOscillator(); const gain = audioCtx.createGain(); const t = start + i * 0.7;
      osc.type = "sine"; osc.frequency.value = freq;
      gain.gain.setValueAtTime(0.0001, t); gain.gain.exponentialRampToValueAtTime(peak, t + 0.05); gain.gain.exponentialRampToValueAtTime(0.0001, t + 1.6);
      osc.connect(gain); gain.connect(audioCtx.destination); osc.start(t); osc.stop(t + 1.7); chimeNodes.push(osc);
    });
    chimeTimer = setTimeout(() => { adzanPlaying = false; hideAdzanBar(); }, 4300);
    return true;
  } catch (error) { return false; }
}

async function playAdzan(prayerKey) {
  stopAdzan(true);
  const prayer = prayerNames.find(p => p.key === prayerKey); const label = prayer ? prayer.name : "";
  adzanAudio.muted = false; adzanAudio.loop = false; adzanAudio.volume = Math.min(1, Math.max(0, settings.adzan.volume));
  const sources = []; if (adzanBlobUrl) sources.push(adzanBlobUrl); sources.push("adzan.mp3");
  for (const src of sources) {
    try { adzanAudio.src = src; await adzanAudio.play(); adzanPlaying = true; showAdzanBar(label); return "file"; }
    catch (error) { if (error && error.name === "NotAllowedError") { showToast("Browser memblokir suara. Ketuk layar sekali, lalu coba lagi."); return false; } }
  }
  if (playChime()) { adzanPlaying = true; showAdzanBar(label); return "chime"; }
  return false;
}

function checkAdzan() {
  if (window.NurNative && NurNative.isNative) return;
  if (!settings.adzan.enabled || !todayPrayers.length) return;
  const now = new Date();
  todayPrayers.forEach(async prayer => {
    if (!settings.adzan.prayers[prayer.key]) return;
    const diff = now.getTime() - parsePrayerDate(prayer.time, now).getTime();
    if (diff < 0 || diff >= ADZAN_GRACE_MS) return;
    const todayKey = getLocalDateKey(now);
    const id = `${todayKey}_${prayer.key}_adzan`;
    if (notified.has(id)) return;
    notified.add(id);
    const keep = [...notified].filter(v => v.startsWith(todayKey));
    notified = new Set(keep); storageSet(NOTIFIED_KEY, keep);
    const result = await playAdzan(prayer.key);
    if (!result) { notified.delete(id); const rollback = [...notified].filter(v => v.startsWith(todayKey)); notified = new Set(rollback); storageSet(NOTIFIED_KEY, rollback); }
  });
}

function setAdzanEnabled(value) { settings.adzan.enabled = value; saveSettings(); if (value) { unlockAudio(); showToast("Adzan aktif. Biarkan NurTime tetap terbuka agar suaranya terdengar."); } }
function setAdzanPrayer(key, value) { settings.adzan.prayers[key] = value; saveSettings(); }
function setAdzanVolume(value) { settings.adzan.volume = Math.min(1, Math.max(0.1, Number(value) || 1)); adzanAudio.volume = settings.adzan.volume; saveSettings(); }
async function testAdzan() { unlockAudio(); const result = await playAdzan("Dhuhr"); if (result === "chime") showToast("File adzan belum ada, jadi diputar nada singkat. Pilih file adzan di bawah."); }

function adzanSettingsHtml() {
  const prayerRows = prayerNames.map(p => `<label class="setting-row"><span>${ic(p.icon)} ${p.name}</span><input type="checkbox" ${settings.adzan.prayers[p.key] ? "checked" : ""} onchange="setAdzanPrayer('${p.key}', this.checked)"></label>`).join("");
  const fileName = settings.adzan.fileName && adzanBlobUrl ? escapeHtml(settings.adzan.fileName) : "Belum ada file adzan";
  return `
    <h4>Suara Adzan</h4>
    <label class="setting-row"><span>Putar adzan saat waktu sholat</span><input type="checkbox" ${settings.adzan.enabled ? "checked" : ""} onchange="setAdzanEnabled(this.checked)"></label>
    <label class="setting-row"><span>Volume</span><input type="range" min="0.1" max="1" step="0.1" value="${settings.adzan.volume}" oninput="setAdzanVolume(this.value)"></label>
    ${prayerRows}
    <div class="setting-row"><span>${fileName}</span><button class="small-btn" onclick="document.getElementById('adzanFile').click()">Pilih file</button></div>
    <input type="file" id="adzanFile" accept="audio/*" hidden onchange="onAdzanFile(this)">
    ${adzanBlobUrl ? `<button class="small-btn danger" onclick="removeAdzanFile()">Hapus file adzan</button>` : ""}
    <button onclick="testAdzan()">Tes Suara Adzan</button>
  `;
}

// ===== Pengingat Puasa =====
function fastReminderDue(kind, forKey) {
  const key = forKey || todayKey(); const info = fastInfo(key, hijriOfKey(key));
  if (info.kind === "haram") return false;
  if (info.kind === "wajib") return true;
  if (kind === "buka" && fasting.days[key]) return true;
  return info.kind === "sunnah" && settings.fastRemind.sunnah;
}
function fireFastReminder(kind, title, body) {
  const id = `${currentDateKey}_fast_${kind}`; if (notified.has(id)) return;
  notified.add(id); const keep = [...notified].filter(v => v.startsWith(currentDateKey)); notified = new Set(keep); storageSet(NOTIFIED_KEY, keep);
  sendNotification(title, body, id);
}
function checkFastReminders() {
  if (window.NurNative && NurNative.isNative) return;
  const r = settings.fastRemind; if ((!r.sahur && !r.buka) || notifPermission() !== "granted" || !todayPrayers.length) return;
  const now = new Date();
  if (r.sahur && todayImsak && fastReminderDue("sahur")) {
    const target = parsePrayerDate(todayImsak, now).getTime() - r.sahurLead * 60000; const diff = now.getTime() - target;
    if (diff >= 0 && diff < NOTIFY_GRACE_MS) fireFastReminder("sahur", "Waktunya sahur", `Imsak pukul ${formatTime(todayImsak)} ${tzLabel()}, sekitar ${r.sahurLead} menit lagi.`);
  }
  const maghrib = todayPrayers.find(p => p.key === "Maghrib");
  if (r.buka && maghrib && fastReminderDue("buka")) {
    const diff = now.getTime() - parsePrayerDate(maghrib.time, now).getTime();
    if (diff >= 0 && diff < NOTIFY_GRACE_MS) fireFastReminder("buka", "Waktunya berbuka", `Maghrib pukul ${formatTime(maghrib.time)} ${tzLabel()}. Selamat berbuka.`);
  }
}
function setFastRemind(field, value) { settings.fastRemind[field] = field === "sahurLead" ? Number(value) || 30 : value; saveSettings(); if (value === true && notifPermission() !== "granted") showToast("Aktifkan izin notifikasi dulu di bagian Notifikasi."); }

function fastSettingsHtml() {
  const r = settings.fastRemind; const leads = [15, 30, 45, 60].map(v => `<option value="${v}" ${r.sahurLead === v ? "selected" : ""}>${v} menit sebelum imsak</option>`).join("");
  return `
    <h4>Pengingat Puasa</h4>
    <label class="setting-row"><span>Ingatkan sahur</span><input type="checkbox" ${r.sahur ? "checked" : ""} onchange="setFastRemind('sahur', this.checked)"></label>
    <label class="setting-row"><span>Waktu sahur</span><select onchange="setFastRemind('sahurLead', this.value)">${leads}</select></label>
    <label class="setting-row"><span>Ingatkan berbuka</span><input type="checkbox" ${r.buka ? "checked" : ""} onchange="setFastRemind('buka', this.checked)"></label>
    <label class="setting-row"><span>Termasuk hari puasa sunnah</span><input type="checkbox" ${r.sunnah ? "checked" : ""} onchange="setFastRemind('sunnah', this.checked)"></label>
  `;
}


// ===== Sholat Sunnah: Dhuha, Tahajud, pengingat Jumat =====
const DAY_MS = 24 * 60 * 60 * 1000;

function clockIn(date) {
  return new Intl.DateTimeFormat("en-GB", { timeZone: userLocation.tz, hour: "2-digit", minute: "2-digit", hour12: false }).format(date);
}

function sunnahWindows(now) {
  if (!todayPrayers.length || !todaySunrise) return null;
  const get = key => todayPrayers.find(p => p.key === key);
  const fajrP = get("Fajr"), dhuhrP = get("Dhuhr"), maghribP = get("Maghrib");
  if (!fajrP || !dhuhrP || !maghribP) return null;

  const fajr = parsePrayerDate(fajrP.time, now);
  const dhuhr = parsePrayerDate(dhuhrP.time, now);
  const maghrib = parsePrayerDate(maghribP.time, now);
  const sunrise = parsePrayerDate(todaySunrise, now);

  // Dhuha: 15 menit setelah terbit sampai 10 menit sebelum Dzuhur
  const dhuhaStart = new Date(sunrise.getTime() + 15 * 60000);
  const dhuhaEnd = new Date(dhuhr.getTime() - 10 * 60000);

  // Tahajud: sepertiga malam terakhir (Maghrib sampai Subuh)
  let nightStart, nightEnd;
  if (now < fajr) {
    nightStart = new Date(maghrib.getTime() - DAY_MS);
    nightEnd = fajr;
  } else {
    nightStart = maghrib;
    nightEnd = tomorrowPrayers.length
      ? parsePrayerDate(tomorrowPrayers[0].time, new Date(now.getTime() + DAY_MS))
      : new Date(fajr.getTime() + DAY_MS);
  }
  const tahajudStart = new Date(nightEnd.getTime() - (nightEnd.getTime() - nightStart.getTime()) / 3);
  return { dhuhaStart, dhuhaEnd, tahajudStart, tahajudEnd: nightEnd };
}

function sunnahStatus(start, end) {
  const t = Date.now();
  if (t >= start.getTime() && t < end.getTime()) return { text: "Sedang berlangsung", cls: "on" };
  if (t < start.getTime()) return { text: "Belum masuk", cls: "" };
  return { text: "Sudah lewat", cls: "past" };
}

function renderSunnahTimes() {
  const el = document.getElementById("sunnahTimes");
  if (!el) return;
  const w = sunnahWindows(new Date());
  if (!w) { el.innerHTML = ""; return; }
  const items = [
    { name: "Dhuha", icon: "sun", start: w.dhuhaStart, end: w.dhuhaEnd, note: "2 sampai 12 rakaat" },
    { name: "Tahajud", icon: "moon", start: w.tahajudStart, end: w.tahajudEnd, note: "Sepertiga malam terakhir" }
  ];
  el.innerHTML = `
    <div class="section-heading"><div><h2>Sholat Sunnah</h2><p>Dhuha dan Tahajud hari ini</p></div></div>
    <div class="sunnah-times">
      ${items.map(i => {
        const st = sunnahStatus(i.start, i.end);
        return `<div class="sunnah-card ${st.cls}">
          <span class="sc-ic">${ic(i.icon)}</span>
          <div class="sc-main"><strong>${i.name}</strong><small>${clockIn(i.start)} - ${clockIn(i.end)} ${tzLabel()}</small><small>${i.note}</small></div>
          <em>${st.text}</em>
        </div>`;
      }).join("")}
    </div>
    <p class="disclaimer">Dhuha dihitung 15 menit setelah terbit hingga menjelang Dzuhur. Tahajud dihitung dari sepertiga malam terakhir antara Maghrib dan Subuh.</p>`;
}

function fireSunnahOnce(id, title, body) {
  if (notified.has(id)) return;
  notified.add(id);
  storageSet(NOTIFIED_KEY, [...notified]);
  sendNotification(title, body, id);
  playNotificationSound();
}

function checkSunnahReminders() {
  if (window.NurNative && NurNative.isNative) return;
  const r = settings.sunnahRemind;
  if (!r || (!r.dhuha && !r.tahajud && !r.jumat) || notifPermission() !== "granted") return;
  const now = new Date();
  const w = sunnahWindows(now);
  if (!w) return;
  const due = date => { const d = now.getTime() - date.getTime(); return d >= 0 && d < NOTIFY_GRACE_MS; };

  if (r.dhuha && due(w.dhuhaStart)) {
    fireSunnahOnce(`${getLocalDateKey(w.dhuhaStart)}_dhuha_sunnah`, "Waktu Dhuha telah masuk", `Sholat Dhuha bisa dikerjakan sampai pukul ${clockIn(w.dhuhaEnd)} ${tzLabel()}.`);
  }
  if (r.tahajud && due(w.tahajudStart)) {
    fireSunnahOnce(`${getLocalDateKey(w.tahajudStart)}_tahajud_sunnah`, "Sepertiga malam terakhir", `Waktu terbaik untuk Tahajud dan berdoa, hingga Subuh pukul ${clockIn(w.tahajudEnd)} ${tzLabel()}.`);
  }
  if (r.jumat) {
    const day = new Intl.DateTimeFormat("en-US", { timeZone: userLocation.tz, weekday: "short" }).format(now);
    if (day === "Fri" && due(w.dhuhaStart)) {
      fireSunnahOnce(`${getLocalDateKey(now)}_jumat_sunnah`, "Jumat berkah", "Jangan lupa membaca Surah Al-Kahfi dan memperbanyak sholawat hari ini.");
    }
  }
}

function setSunnahRemind(field, value) {
  settings.sunnahRemind[field] = value;
  saveSettings();
  if (value === true && notifPermission() !== "granted") showToast("Aktifkan izin notifikasi dulu di bagian Notifikasi.");
}

function sunnahSettingsHtml() {
  const r = settings.sunnahRemind;
  return `
    <h4>Sholat Sunnah dan Jumat</h4>
    <label class="setting-row"><span>${ic("sun")} Pengingat Dhuha</span><input type="checkbox" ${r.dhuha ? "checked" : ""} onchange="setSunnahRemind('dhuha', this.checked)"></label>
    <label class="setting-row"><span>${ic("moon")} Pengingat Tahajud</span><input type="checkbox" ${r.tahajud ? "checked" : ""} onchange="setSunnahRemind('tahajud', this.checked)"></label>
    <label class="setting-row"><span>${ic("book")} Pengingat Al-Kahfi hari Jumat</span><input type="checkbox" ${r.jumat ? "checked" : ""} onchange="setSunnahRemind('jumat', this.checked)"></label>
    <p class="setting-note">Notifikasi muncul selama NurTime masih terbuka di browser.</p>
  `;
}

// ===== Donasi & PWA =====
function donateSettingsHtml() {
  const links = [
    { name: "Dompet Dhuafa", url: "https://www.dompetdhuafa.org/", desc: "Zakat, infak, sedekah, wakaf" },
    { name: "Rumah Zakat", url: "https://www.rumahzakat.org/", desc: "Pemberdayaan masyarakat" },
    { name: "BAZNAS", url: "https://baznas.go.id/", desc: "Badan Amil Zakat Nasional" }
  ];
  return `
    <h4>${ic("hands")} Salurkan Kebaikan</h4>
    <p class="setting-note">NurTime tidak berafiliasi dengan lembaga mana pun. Daftar ini disediakan sebagai referensi.</p>
    <div class="donate-list">
      ${links.map(l => `<a href="${l.url}" target="_blank" rel="noopener noreferrer" class="donate-card"><div><strong>${l.name}</strong><small>${l.desc}</small></div><span>→</span></a>`).join("")}
    </div>
  `;
}

let swReady = false; let deferredInstall = null;
function isStandalone() { return (window.matchMedia && matchMedia("(display-mode: standalone)").matches) || navigator.standalone === true; }
window.addEventListener("beforeinstallprompt", event => { event.preventDefault(); deferredInstall = event; if (document.getElementById("settingsBody")) renderSettings(); });
window.addEventListener("appinstalled", () => { deferredInstall = null; showToast("NurTime sudah terpasang."); if (document.getElementById("settingsBody")) renderSettings(); });
window.addEventListener("offline", () => showToast("Kamu sedang offline. Data yang pernah dibuka tetap tersedia."));
window.addEventListener("online", () => showToast("Kembali online."));
async function installApp() { if (!deferredInstall) return; deferredInstall.prompt(); try { await deferredInstall.userChoice; } catch (error) {} deferredInstall = null; renderSettings(); }

function pwaSettingsHtml() {
  if (window.NurNative && NurNative.isNative) return `<h4>Aplikasi</h4><p>NurTime terpasang sebagai aplikasi Android. Notifikasi dijadwalkan oleh sistem, jadi tetap berbunyi walau aplikasi ditutup.</p><button onclick="addHomeWidget()">Pasang widget di layar utama</button><p class="setting-note">Widget menampilkan sholat berikutnya dengan hitung mundur dan lima waktu hari ini.</p>`;
  let offlineText;
  if (!window.isSecureContext || !("serviceWorker" in navigator)) offlineText = "Mode offline butuh NurTime dibuka lewat alamat https (atau localhost).";
  else if (swReady) offlineText = "Mode offline aktif.";
  else offlineText = "Mode offline sedang disiapkan. Muat ulang halaman jika status ini tidak berubah.";
  let installHtml;
  if (isStandalone()) installHtml = "<p>NurTime sudah terpasang sebagai aplikasi di perangkat ini.</p>";
  else if (deferredInstall) installHtml = `<button onclick="installApp()">Pasang NurTime di Layar Utama</button>`;
  else if (/iphone|ipad|ipod/i.test(navigator.userAgent)) installHtml = "<p>Di iPhone atau iPad: ketuk tombol Bagikan di Safari, lalu pilih Tambahkan ke Layar Utama.</p>";
  else installHtml = "<p>Untuk memasang: buka menu browser, lalu pilih Instal aplikasi atau Tambahkan ke layar utama.</p>";
  return `<h4>Aplikasi</h4>${installHtml}<p class="setting-note">${offlineText}</p>`;
}

// ===== Panel Musafir di Beranda =====
function renderMusafirPanel() {
  const panel = document.getElementById("musafirPanel");
  if (!panel) return;
  if (!musafirMode) { panel.innerHTML = ''; return; }
  const dzuhur = todayPrayers.find(p => p.key === "Dhuhr");
  const ashar = todayPrayers.find(p => p.key === "Asr");
  const maghrib = todayPrayers.find(p => p.key === "Maghrib");
  const isya = todayPrayers.find(p => p.key === "Isha");
  panel.innerHTML = `
    <div style="margin-top: 16px; padding: 16px; background: var(--card); border-radius: 12px;">
      <h4>${ic("pin")} Mode Musafir Aktif</h4>
      <p style="font-size:13px; margin-bottom:12px;">Anda berada jauh dari rumah (${escapeHtml(homeLocation.name)}). Berikut panduan jamak-qashar:</p>
      <div class="musafir-pair">
        <strong>Dzuhur + Ashar</strong>
        <span>${dzuhur ? formatTime(dzuhur.time) : "--:--"} atau ${ashar ? formatTime(ashar.time) : "--:--"}</span>
        <small>2 rakaat masing-masing (qashar)</small>
      </div>
      <div class="musafir-pair">
        <strong>Maghrib + Isya</strong>
        <span>${maghrib ? formatTime(maghrib.time) : "--:--"} atau ${isya ? formatTime(isya.time) : "--:--"}</span>
        <small>Maghrib 3 rakaat, Isya 2 rakaat (qashar)</small>
      </div>
    </div>
  `;
}

// ===== Tasbih Digital =====
const DZIKIR = [
  {
    id: "paket",
    chip: "Tasbih, Tahmid, Takbir",
    title: "Tasbih, Tahmid dan Takbir",
    arab: "سُبْحَانَ اللَّهِ، وَالْحَمْدُ لِلَّهِ، وَاللَّهُ أَكْبَرُ",
    latin: "Subḥānallāh, Alḥamdulillāh, Allāhu akbar.",
    arti: "Maha Suci Allah, segala puji bagi Allah, dan Allah Maha Besar.",
    fadhilah: "Dibaca masing-masing 33 kali setelah sholat fardhu. Dalam hadits riwayat Muslim, amalan ini (digenapkan menjadi 100 dengan tahlil) menjadi sebab diampuninya kesalahan, walau sebanyak buih di lautan.",
    target: 99
  },
  {
    id: "tasbih",
    chip: "Subhanallah",
    title: "Tasbih",
    arab: "سُبْحَانَ اللَّهِ",
    latin: "Subḥānallāh.",
    arti: "Maha Suci Allah.",
    fadhilah: "Termasuk empat kalimat yang paling dicintai Allah, sebagaimana disebut dalam hadits riwayat Muslim.",
    target: 33
  },
  {
    id: "tahmid",
    chip: "Alhamdulillah",
    title: "Tahmid",
    arab: "الْحَمْدُ لِلَّهِ",
    latin: "Alḥamdulillāh.",
    arti: "Segala puji bagi Allah.",
    fadhilah: "Dalam hadits riwayat Muslim disebutkan bahwa ucapan alhamdulillah memenuhi timbangan amal.",
    target: 33
  },
  {
    id: "takbir",
    chip: "Allahu Akbar",
    title: "Takbir",
    arab: "اللَّهُ أَكْبَرُ",
    latin: "Allāhu akbar.",
    arti: "Allah Maha Besar.",
    fadhilah: "Termasuk empat kalimat yang paling dicintai Allah, sebagaimana disebut dalam hadits riwayat Muslim.",
    target: 33
  },
  {
    id: "tahlil",
    chip: "La ilaha illallah",
    title: "Tahlil",
    arab: "لَا إِلَهَ إِلَّا اللَّهُ",
    latin: "Lā ilāha illallāh.",
    arti: "Tiada Tuhan selain Allah.",
    fadhilah: "Disebut dalam hadits riwayat At-Tirmidzi sebagai dzikir yang paling utama.",
    target: 100
  },
  {
    id: "istighfar",
    chip: "Istighfar",
    title: "Istighfar",
    arab: "أَسْتَغْفِرُ اللَّهَ",
    latin: "Astaghfirullāh.",
    arti: "Aku memohon ampun kepada Allah.",
    fadhilah: "Rasulullah ﷺ beristighfar lebih dari tujuh puluh kali dalam sehari (HR. Bukhari).",
    target: 100
  },
  {
    id: "shalawat",
    chip: "Shalawat",
    title: "Shalawat Nabi",
    arab: "اللَّهُمَّ صَلِّ عَلَى مُحَمَّدٍ",
    latin: "Allāhumma shalli 'alā Muḥammad.",
    arti: "Ya Allah, limpahkan shalawat kepada Muhammad.",
    fadhilah: "Dalam hadits riwayat Muslim, siapa yang bershalawat satu kali kepada Nabi, Allah akan bershalawat kepadanya sepuluh kali.",
    target: 100
  }
];

const DZIKIR_TABS = [
  { key: "arti", label: "Terjemahan" },
  { key: "arab", label: "Arab" },
  { key: "latin", label: "Transliterasi" },
  { key: "fadhilah", label: "Keutamaan" }
];

const TARGET_OPTIONS = [33, 99, 100, 1000, 10000];
const TASBIH_KEY = "nurtime_tasbih2";
const BEAD_COUNT = 40;
const BEAD_STEP = 360 / BEAD_COUNT;
const BEAD_CX = 180;
const BEAD_CY = 430;
const BEAD_R = 300;
const BEAD_RAD = 21;

let tasbihState = {
  active: 0,
  tab: "arab",
  counts: {},
  targets: {},
  ...storageGet(TASBIH_KEY, {})
};

function currentDzikir() {
  return DZIKIR[tasbihState.active] || DZIKIR[0];
}

function getCount() {
  return tasbihState.counts[currentDzikir().id] || 0;
}

function getTarget() {
  return tasbihState.targets[currentDzikir().id] || currentDzikir().target;
}

function saveTasbih() {
  storageSet(TASBIH_KEY, tasbihState);
}

function formatNumber(n) {
  return Number(n).toLocaleString("id-ID");
}

function beadSvg() {
  let beads = "";
  for (let i = 0; i < BEAD_COUNT; i++) {
    const a = (i * BEAD_STEP * Math.PI) / 180;
    const x = (BEAD_CX + BEAD_R * Math.sin(a)).toFixed(2);
    const y = (BEAD_CY - BEAD_R * Math.cos(a)).toFixed(2);
    const fill = i === 0 ? "beadGold" : "beadGreen";
    beads += `<circle cx="${x}" cy="${y}" r="${BEAD_RAD}" fill="url(#${fill})"/>`;
  }
  return `
    <svg class="bead-svg" viewBox="0 100 360 120" aria-hidden="true">
      <defs>
        <radialGradient id="beadGreen" cx="35%" cy="30%" r="75%">
          <stop offset="0" stop-color="#9af5d6"/><stop offset=".35" stop-color="#1fb487"/><stop offset="1" stop-color="#075a42"/>
        </radialGradient>
        <radialGradient id="beadGold" cx="35%" cy="30%" r="75%">
          <stop offset="0" stop-color="#fff3c4"/><stop offset=".4" stop-color="#e6c879"/><stop offset="1" stop-color="#8f6b17"/>
        </radialGradient>
      </defs>
      <circle class="bead-string" cx="${BEAD_CX}" cy="${BEAD_CY}" r="${BEAD_R}" fill="none" stroke-width="1.8"/>
      <g id="beadGroup">${beads}</g>
    </svg>`;
}

function renderTasbihPage(content) {
  content.innerHTML = `
    <div class="tasbih">
      <div class="dzikir-chips" id="dzikirChips"></div>
      <div class="dzikir-tabs" id="dzikirTabs"></div>
      <div class="dzikir-text" id="dzikirText"></div>
      <div class="bead-wrap" id="beadWrap" tabindex="0" role="button" aria-label="Geser atau ketuk manik untuk menghitung">
        ${beadSvg()}
      </div>
      <p class="bead-hint">Geser atau ketuk manik untuk menghitung</p>
      <div class="tasbih-meta">
        <div class="target-label">Target <strong id="targetLabel"></strong></div>
        <div class="tasbih-count" id="tasbihNumber">0</div>
        <div class="progress"><div class="progress-bar" id="tasbihBar"></div></div>
      </div>
      <div class="tasbih-actions">
        <button class="round-btn" onclick="resetTasbih()" aria-label="Ulangi dari nol">${ic("reset")}</button>
        <div class="target-chips" id="targetChips"></div>
      </div>
      <button onclick="showFeature('Doa Harian')">${ic("hands")} Buka Doa Harian</button>
    </div>
  `;
  renderDzikirChips();
  renderDzikirTabs();
  renderDzikirText();
  renderTargetChips();
  updateTasbihUI();
  setBeadAngle(getCount() * BEAD_STEP, false);
  initBeads();
}

function renderDzikirChips() {
  const el = document.getElementById("dzikirChips");
  if (!el) return;
  el.innerHTML = DZIKIR.map((d, i) => `<button class="chip ${i === tasbihState.active ? "active" : ""}" onclick="selectDzikir(${i})">${d.chip}</button>`).join("");
}

function renderDzikirTabs() {
  const el = document.getElementById("dzikirTabs");
  if (!el) return;
  el.innerHTML = DZIKIR_TABS.map(t => `<button class="chip small ${t.key === tasbihState.tab ? "active" : ""}" onclick="selectDzikirTab('${t.key}')">${t.label}</button>`).join("");
}

function renderDzikirText() {
  const el = document.getElementById("dzikirText");
  if (!el) return;
  const d = currentDzikir();
  const tab = tasbihState.tab;
  let body;
  if (tab === "arab") body = `<p class="arab-big">${d.arab}</p>`;
  else if (tab === "latin") body = `<p class="latin-big">${d.latin}</p>`;
  else body = `<p class="plain-text">${d[tab]}</p>`;
  el.innerHTML = `<div class="dzikir-name">${d.title}</div>${body}`;
}

function renderTargetChips() {
  const el = document.getElementById("targetChips");
  if (!el) return;
  el.innerHTML = TARGET_OPTIONS.map(t => `<button class="chip small ${t === getTarget() ? "active" : ""}" onclick="setTarget(${t})">${formatNumber(t)}</button>`).join("");
}

function selectDzikir(index) {
  tasbihState.active = index;
  saveTasbih();
  renderDzikirChips();
  renderDzikirText();
  renderTargetChips();
  updateTasbihUI();
  setBeadAngle(getCount() * BEAD_STEP, false);
}

function selectDzikirTab(key) {
  tasbihState.tab = key;
  saveTasbih();
  renderDzikirTabs();
  renderDzikirText();
}

function setTarget(value) {
  tasbihState.targets[currentDzikir().id] = value;
  saveTasbih();
  renderTargetChips();
  updateTasbihUI();
}

function updateTasbihUI() {
  const count = getCount();
  const target = getTarget();
  const number = document.getElementById("tasbihNumber");
  const label = document.getElementById("targetLabel");
  const bar = document.getElementById("tasbihBar");
  if (number) number.textContent = formatNumber(count);
  if (label) label.textContent = formatNumber(target);
  if (bar) bar.style.width = Math.min(100, (count / target) * 100) + "%";
}

function setBeadAngle(angle, animate) {
  const group = document.getElementById("beadGroup");
  if (!group) return;
  group.style.transition = animate ? "transform .3s cubic-bezier(.25,.8,.3,1)" : "none";
  group.style.transform = `rotate(${-angle}deg)`;
}

function vibrate(pattern) {
  try { if (navigator.vibrate) navigator.vibrate(pattern); } catch (e) {}
}

function stepCount(n, animate) {
  const id = currentDzikir().id;
  const target = getTarget();
  const before = tasbihState.counts[id] || 0;
  const count = before + n;
  tasbihState.counts[id] = count;
  saveTasbih();
  updateTasbihUI();
  setBeadAngle(count * BEAD_STEP, animate);
  if (before < target && count >= target) {
    vibrate([60, 40, 60]);
    showToast(`Target ${formatNumber(target)} tercapai.`);
  } else {
    vibrate(12);
  }
}

function resetTasbih() {
  tasbihState.counts[currentDzikir().id] = 0;
  saveTasbih();
  updateTasbihUI();
  setBeadAngle(0, false);
}

function initBeads() {
  const wrap = document.getElementById("beadWrap");
  if (!wrap) return;
  let active = false, lastX = 0, startX = 0, startTime = 0, moved = 0, partial = 0;
  const pxPerBead = () => (wrap.clientWidth / 360) * ((2 * Math.PI * BEAD_R) / BEAD_COUNT) || 47;

  wrap.addEventListener("pointerdown", e => {
    active = true;
    startX = lastX = e.clientX;
    startTime = Date.now();
    moved = 0;
    partial = 0;
    try { wrap.setPointerCapture(e.pointerId); } catch (err) {}
    const group = document.getElementById("beadGroup");
    if (group) group.style.transition = "none";
  });

  wrap.addEventListener("pointermove", e => {
    if (!active) return;
    const delta = lastX - e.clientX;
    lastX = e.clientX;
    moved += Math.abs(delta);
    partial = Math.max(0, partial + delta);
    const px = pxPerBead();
    while (partial >= px) {
      partial -= px;
      stepCount(1, false);
    }
    setBeadAngle(getCount() * BEAD_STEP + (partial / px) * BEAD_STEP, false);
  });

  const finish = () => {
    if (!active) return;
    active = false;
    const px = pxPerBead();
    const isTap = moved < 8 && Date.now() - startTime < 450;
    if (isTap) stepCount(1, true);
    else if (partial > px * 0.5) stepCount(1, true);
    else setBeadAngle(getCount() * BEAD_STEP, true);
    partial = 0;
  };

  wrap.addEventListener("pointerup", finish);
  wrap.addEventListener("pointercancel", finish);

  wrap.addEventListener("keydown", e => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      stepCount(1, true);
    }
  });
}
// ==========================================
// FITUR BARU: SUARA NOTIFIKASI, PUASA SUNNAH, LAYAR MASJID
// ==========================================

// --- 1. Suara Notifikasi Singkat ---
function playNotificationSound() {
  if (!audioCtx) return;
  try {
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(880, audioCtx.currentTime); // Nada A5
    gain.gain.setValueAtTime(0.1, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 1.5);
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.start();
    osc.stop(audioCtx.currentTime + 1.5);
  } catch (e) {}
}

// --- 3. Deteksi Puasa Sunnah Otomatis ---
function checkSunnahFasting() {
  const banner = document.getElementById("sunnahFastingBanner");
  if (!banner) return;

  const key = todayKey();
  const h = hijriOfKey(key);
  const fi = fastInfo(key, h);
  
  // Tampilkan banner jika hari Senin/Kamis atau Ayyamul Bidh, DAN belum ditandai puasa
  const isSunnahDay = fi.kind === "sunnah" && !fasting.days[key];
  
  if (isSunnahDay) {
    banner.classList.remove("hidden");
    document.getElementById("sunnahText").textContent = fi.text;
  } else {
    banner.classList.add("hidden");
  }
}

// --- 5. Mode Layar Masjid (Wake Lock) ---
let wakeLock = null;

async function toggleMasjidMode() {
  const overlay = document.getElementById("masjidModeOverlay");
  const isOpening = overlay.classList.contains("hidden");

  if (isOpening) {
    overlay.classList.remove("hidden");
    document.body.style.overflow = "hidden"; // Kunci scroll
    
    // Minta izin layar tetap menyala
    try {
      if ('wakeLock' in navigator) {
        wakeLock = await navigator.wakeLock.request('screen');
      }
    } catch (err) {
      console.warn("Wake Lock tidak didukung:", err);
    }
    updateMasjidModeUI();
    setInterval(updateMasjidModeUI, 1000);
  } else {
    overlay.classList.add("hidden");
    document.body.style.overflow = "";
    if (wakeLock) {
      wakeLock.release();
      wakeLock = null;
    }
  }
}

function updateMasjidModeUI() {
  const elName = document.getElementById("masjidPrayerName");
  const elCountdown = document.getElementById("masjidCountdown");
  if (!elName || !elCountdown || !todayPrayers.length) return;

  const now = new Date();
  let next = null;
  for (const p of todayPrayers) {
    const t = parsePrayerDate(p.time, now);
    if (t > now) { next = { ...p, date: t }; break; }
  }

  if (!next) {
    elName.textContent = "Tidak ada jadwal";
    elCountdown.textContent = "--:--:--";
    return;
  }

  elName.textContent = next.name;
  const diff = Math.max(0, next.date.getTime() - now.getTime());
  const h = Math.floor(diff / 3600000);
  const m = Math.floor((diff % 3600000) / 60000);
  const s = Math.floor((diff % 60000) / 1000);
  elCountdown.textContent = [h, m, s].map(v => String(v).padStart(2, "0")).join(":");
}

// Panggil fungsi-fungsi baru saat aplikasi dimuat atau jadwal berubah
document.addEventListener('DOMContentLoaded', () => {
  checkSunnahFasting();
});

// ==========================================
// FITUR: EXPORT & IMPORT DATA
// ==========================================

function exportData() {
  const data = {
    version: "1.0",
    exportDate: new Date().toISOString(),
    tracker: tracker,
    fasting: fasting,
    bookmarks: bookmarks,
    settings: settings,
    tasbihState: tasbihState
  };
  
  if (window.NurNative && NurNative.isNative) {
    NurNative.shareFile(`nurtime-backup-${todayKey()}.json`, JSON.stringify(data, null, 2))
      .then(() => showToast("Pilih tujuan untuk menyimpan cadangan."))
      .catch(() => showToast("Cadangan gagal dibagikan."));
    return;
  }
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `nurtime-backup-${todayKey()}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  showToast("Backup data berhasil diunduh.");
}

function importData(input) {
  const file = input.files && input.files[0];
  input.value = "";
  if (!file) return;

  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      const data = JSON.parse(e.target.result);
      if (!data.version) throw new Error("Format file tidak dikenali.");

      if (confirm("Data saat ini akan ditimpa dengan data dari file backup. Lanjutkan?")) {
        if (data.tracker) { tracker = data.tracker; storageSet(TRACKER_KEY, tracker); }
        if (data.fasting) { fasting = data.fasting; storageSet(FAST_KEY, fasting); }
        if (data.bookmarks) { bookmarks = data.bookmarks; storageSet(BOOKMARK_KEY, bookmarks); }
        if (data.settings) { settings = { ...settings, ...data.settings }; storageSet(SETTINGS_KEY, settings); }
        if (data.tasbihState) { tasbihState = { ...tasbihState, ...data.tasbihState }; storageSet(TASBIH_KEY, tasbihState); }

        showToast("Data berhasil dipulihkan!");
        setTimeout(() => location.reload(), 1000);
      }
    } catch (err) {
      showToast("Gagal mengimpor data. File mungkin rusak.");
    }
  };
  reader.readAsText(file);
}

// ==========================================
// FITUR: INTEGRASI SOSIAL (Bagikan Ayat)
// ==========================================

window.shareAyat = async function(surahName, ayatNo, arab, terjemahan) {
  const text = `${surahName} : ${ayatNo}\n\n${arab}\n\n"${terjemahan}"\n\n— Dibaca dari NurTime`;
  
  if (window.NurNative && NurNative.isNative) {
    try { await NurNative.shareText(`${surahName} Ayat ${ayatNo}`, text); } catch (err) { showToast("Gagal membagikan."); }
    return;
  }
  if (navigator.share) {
    try {
      await navigator.share({
        title: `${surahName} Ayat ${ayatNo}`,
        text: text,
        url: window.location.origin
      });
      showToast("Ayat berhasil dibagikan.");
    } catch (err) {
      if (err.name !== "AbortError") {
        showToast("Gagal membagikan.");
      }
    }
  } else {
    // Fallback untuk browser lama
    navigator.clipboard.writeText(text).then(() => {
      showToast("Teks ayat disalin ke clipboard.");
    }).catch(() => {
      showToast("Gagal menyalin teks.");
    });
  }
};

// ==========================================
// FITUR: ANIMASI HALUS (Helper)
// ==========================================

function addRipple(e) {
  const btn = e.currentTarget;
  const rect = btn.getBoundingClientRect();
  const ripple = document.createElement("span");
  ripple.className = "ripple";
  ripple.style.left = (e.clientX - rect.left) + "px";
  ripple.style.top = (e.clientY - rect.top) + "px";
  btn.appendChild(ripple);
  setTimeout(() => ripple.remove(), 600);
}

document.addEventListener("DOMContentLoaded", () => {
  // Tambahkan efek ripple ke semua tombol yang punya class .quick-grid button
  document.querySelectorAll(".quick-grid button, .bottom-nav button").forEach(btn => {
    btn.addEventListener("click", addRipple);
  });
});
// ==========================================
// FITUR 1: PENCARIAN MASJID TERDEKAT
// ==========================================
function cariMasjidTerdekat() {
  if (!navigator.geolocation) {
    showToast("Browser ini tidak mendukung GPS.");
    return;
  }
  
  showToast("Mencari lokasi Anda...");
  
  navigator.geolocation.getCurrentPosition(
    position => {
      const lat = position.coords.latitude;
      const lng = position.coords.longitude;
      const url = `https://www.google.com/maps/search/masjid/@${lat},${lng},15z`;
      window.open(url, "_blank");
    },
    error => {
      // Jika GPS ditolak, gunakan lokasi default (kota yang dipilih)
      const lat = userLocation.lat;
      const lng = userLocation.lng;
      const url = `https://www.google.com/maps/search/masjid/@${lat},${lng},14z`;
      window.open(url, "_blank");
      showToast("Menggunakan lokasi kota yang dipilih.");
    },
    { enableHighAccuracy: false, timeout: 8000, maximumAge: 600000 }
  );
}

// ==========================================
// FITUR 2: ASMAUL HUSNA
// ==========================================
const ASMAUL_HUSNA = [
  { no: 1, arab: "الرَّحْمَنُ", latin: "Ar-Rahman", arti: "Yang Maha Pengasih" },
  { no: 2, arab: "الرَّحِيمُ", latin: "Ar-Rahim", arti: "Yang Maha Penyayang" },
  { no: 3, arab: "الْمَلِكُ", latin: "Al-Malik", arti: "Yang Maha Merajai" },
  { no: 4, arab: "الْقُدُّوسُ", latin: "Al-Quddus", arti: "Yang Maha Suci" },
  { no: 5, arab: "السَّلَامُ", latin: "As-Salam", arti: "Yang Maha Memberi Kesejahteraan" },
  { no: 6, arab: "الْمُؤْمِنُ", latin: "Al-Mu'min", arti: "Yang Maha Memberi Keamanan" },
  { no: 7, arab: "الْمُهَيْمِنُ", latin: "Al-Muhaimin", arti: "Yang Maha Pemelihara" },
  { no: 8, arab: "الْعَزِيزُ", latin: "Al-'Aziz", arti: "Yang Maha Perkasa" },
  { no: 9, arab: "الْجَبَّارُ", latin: "Al-Jabbar", arti: "Yang Maha Memaksa" },
  { no: 10, arab: "الْمُتَكَبِّرُ", latin: "Al-Mutakabbir", arti: "Yang Maha Megah" },
  { no: 11, arab: "الْخَالِقُ", latin: "Al-Khaliq", arti: "Yang Maha Pencipta" },
  { no: 12, arab: "الْبَارِئُ", latin: "Al-Bari'", arti: "Yang Maha Mengadakan" },
  { no: 13, arab: "الْمُصَوِّرُ", latin: "Al-Musawwir", arti: "Yang Maha Membentuk Rupa" },
  { no: 14, arab: "الْغَفَّارُ", latin: "Al-Ghaffar", arti: "Yang Maha Pengampun" },
  { no: 15, arab: "الْقَهَّارُ", latin: "Al-Qahhar", arti: "Yang Maha Menundukkan" },
  { no: 16, arab: "الْوَهَّابُ", latin: "Al-Wahhab", arti: "Yang Maha Pemberi Karunia" },
  { no: 17, arab: "الرَّزَّاقُ", latin: "Ar-Razzaq", arti: "Yang Maha Pemberi Rezeki" },
  { no: 18, arab: "الْفَتَّاحُ", latin: "Al-Fattah", arti: "Yang Maha Pembuka Rahmat" },
  { no: 19, arab: "الْعَلِيمُ", latin: "Al-'Alim", arti: "Yang Maha Mengetahui" },
  { no: 20, arab: "الْقَابِضُ", latin: "Al-Qabidh", arti: "Yang Maha Menyempitkan" },
  { no: 21, arab: "الْبَاسِطُ", latin: "Al-Basith", arti: "Yang Maha Melapangkan" },
  { no: 22, arab: "الْخَافِضُ", latin: "Al-Khafidh", arti: "Yang Maha Merendahkan" },
  { no: 23, arab: "الرَّافِعُ", latin: "Ar-Rafi'", arti: "Yang Maha Meninggikan" },
  { no: 24, arab: "الْمُعِزُّ", latin: "Al-Mu'izz", arti: "Yang Maha Memuliakan" },
  { no: 25, arab: "الْمُذِلُّ", latin: "Al-Mudzill", arti: "Yang Maha Menghinakan" },
  { no: 26, arab: "السَّمِيعُ", latin: "As-Sami'", arti: "Yang Maha Mendengar" },
  { no: 27, arab: "الْبَصِيرُ", latin: "Al-Bashir", arti: "Yang Maha Melihat" },
  { no: 28, arab: "الْحَكَمُ", latin: "Al-Hakam", arti: "Yang Maha Menetapkan" },
  { no: 29, arab: "الْعَدْلُ", latin: "Al-'Adl", arti: "Yang Maha Adil" },
  { no: 30, arab: "اللَّطِيفُ", latin: "Al-Lathif", arti: "Yang Maha Lembut" },
  { no: 31, arab: "الْخَبِيرُ", latin: "Al-Khabir", arti: "Yang Maha Mengenal" },
  { no: 32, arab: "الْحَلِيمُ", latin: "Al-Halim", arti: "Yang Maha Penyantun" },
  { no: 33, arab: "الْعَظِيمُ", latin: "Al-'Azhim", arti: "Yang Maha Agung" },
  { no: 34, arab: "الْغَفُورُ", latin: "Al-Ghafur", arti: "Yang Maha Pengampun" },
  { no: 35, arab: "الشَّكُورُ", latin: "Asy-Syakur", arti: "Yang Maha Pembalas Budi" },
  { no: 36, arab: "الْعَلِيُّ", latin: "Al-'Aliy", arti: "Yang Maha Tinggi" },
  { no: 37, arab: "الْكَبِيرُ", latin: "Al-Kabir", arti: "Yang Maha Besar" },
  { no: 38, arab: "الْحَفِيظُ", latin: "Al-Hafizh", arti: "Yang Maha Memelihara" },
  { no: 39, arab: "الْمُقِيتُ", latin: "Al-Muqit", arti: "Yang Maha Pemberi Kecukupan" },
  { no: 40, arab: "الْحَسِيبُ", latin: "Al-Hasib", arti: "Yang Maha Membuat Perhitungan" },
  { no: 41, arab: "الْجَلِيلُ", latin: "Al-Jalil", arti: "Yang Maha Luhur" },
  { no: 42, arab: "الْكَرِيمُ", latin: "Al-Karim", arti: "Yang Maha Pemurah" },
  { no: 43, arab: "الرَّقِيبُ", latin: "Ar-Raqib", arti: "Yang Maha Mengawasi" },
  { no: 44, arab: "الْمُجِيبُ", latin: "Al-Mujib", arti: "Yang Maha Mengabulkan" },
  { no: 45, arab: "الْوَاسِعُ", latin: "Al-Wasi'", arti: "Yang Maha Luas" },
  { no: 46, arab: "الْحَكِيمُ", latin: "Al-Hakim", arti: "Yang Maha Bijaksana" },
  { no: 47, arab: "الْوَدُودُ", latin: "Al-Wadud", arti: "Yang Maha Mengasihi" },
  { no: 48, arab: "الْمَجِيدُ", latin: "Al-Majid", arti: "Yang Maha Mulia" },
  { no: 49, arab: "الْبَاعِثُ", latin: "Al-Ba'its", arti: "Yang Maha Membangkitkan" },
  { no: 50, arab: "الشَّهِيدُ", latin: "Asy-Syahid", arti: "Yang Maha Menyaksikan" },
  { no: 51, arab: "الْحَقُّ", latin: "Al-Haqq", arti: "Yang Maha Benar" },
  { no: 52, arab: "الْوَكِيلُ", latin: "Al-Wakil", arti: "Yang Maha Memelihara" },
  { no: 53, arab: "الْقَوِيُّ", latin: "Al-Qawiyy", arti: "Yang Maha Kuat" },
  { no: 54, arab: "الْمَتِينُ", latin: "Al-Matin", arti: "Yang Maha Kokoh" },
  { no: 55, arab: "الْوَلِيُّ", latin: "Al-Waliy", arti: "Yang Maha Melindungi" },
  { no: 56, arab: "الْحَمِيدُ", latin: "Al-Hamid", arti: "Yang Maha Terpuji" },
  { no: 57, arab: "الْمُحْصِي", latin: "Al-Muhshi", arti: "Yang Maha Menghitung" },
  { no: 58, arab: "الْمُبْدِئُ", latin: "Al-Mubdi'", arti: "Yang Maha Memulai" },
  { no: 59, arab: "الْمُعِيدُ", latin: "Al-Mu'id", arti: "Yang Maha Mengembalikan" },
  { no: 60, arab: "الْمُحْيِي", latin: "Al-Muhyi", arti: "Yang Maha Menghidupkan" },
  { no: 61, arab: "الْمُمِيتُ", latin: "Al-Mumit", arti: "Yang Maha Mematikan" },
  { no: 62, arab: "الْحَيُّ", latin: "Al-Hayy", arti: "Yang Maha Hidup" },
  { no: 63, arab: "الْقَيُّومُ", latin: "Al-Qayyum", arti: "Yang Maha Mandiri" },
  { no: 64, arab: "الْوَاجِدُ", latin: "Al-Wajid", arti: "Yang Maha Penemu" },
  { no: 65, arab: "الْمَاجِدُ", latin: "Al-Majid", arti: "Yang Maha Mulia" },
  { no: 66, arab: "الْوَاحِدُ", latin: "Al-Wahid", arti: "Yang Maha Tunggal" },
  { no: 67, arab: "الْأَحَدُ", latin: "Al-Ahad", arti: "Yang Maha Esa" },
  { no: 68, arab: "الصَّمَدُ", latin: "Ash-Shamad", arti: "Yang Maha Dibutuhkan" },
  { no: 69, arab: "الْقَادِرُ", latin: "Al-Qadir", arti: "Yang Maha Menentukan" },
  { no: 70, arab: "الْمُقْتَدِرُ", latin: "Al-Muqtadir", arti: "Yang Maha Berkuasa" },
  { no: 71, arab: "الْمُقَدِّمُ", latin: "Al-Muqaddim", arti: "Yang Maha Mendahulukan" },
  { no: 72, arab: "الْمُؤَخِّرُ", latin: "Al-Mu'akhkhir", arti: "Yang Maha Mengakhirkan" },
  { no: 73, arab: "الْأَوَّلُ", latin: "Al-Awwal", arti: "Yang Maha Awal" },
  { no: 74, arab: "الْآخِرُ", latin: "Al-Akhir", arti: "Yang Maha Akhir" },
  { no: 75, arab: "الظَّاهِرُ", latin: "Azh-Zhahir", arti: "Yang Maha Nyata" },
  { no: 76, arab: "الْبَاطِنُ", latin: "Al-Bathin", arti: "Yang Maha Tersembunyi" },
  { no: 77, arab: "الْوَالِي", latin: "Al-Wali", arti: "Yang Maha Memerintah" },
  { no: 78, arab: "الْمُتَعَالِي", latin: "Al-Muta'ali", arti: "Yang Maha Tinggi" },
  { no: 79, arab: "الْبَرُّ", latin: "Al-Barr", arti: "Yang Maha Penderma" },
  { no: 80, arab: "التَّوَّابُ", latin: "At-Tawwab", arti: "Yang Maha Penerima Tobat" },
  { no: 81, arab: "الْمُنْتَقِمُ", latin: "Al-Muntaqim", arti: "Yang Maha Pemberi Balasan" },
  { no: 82, arab: "الْعَفُوُّ", latin: "Al-'Afuww", arti: "Yang Maha Pemaaf" },
  { no: 83, arab: "الرَّءُوفُ", latin: "Ar-Ra'uf", arti: "Yang Maha Pengasih" },
  { no: 84, arab: "مَالِكُ الْمُلْكِ", latin: "Malikul Mulk", arti: "Yang Maha Penguasa Kerajaan" },
  { no: 85, arab: "ذُو الْجَلَالِ وَالْإِكْرَامِ", latin: "Dzul Jalali wal Ikram", arti: "Yang Maha Pemilik Kebesaran" },
  { no: 86, arab: "الْمُقْسِطُ", latin: "Al-Muqsith", arti: "Yang Maha Pemberi Keadilan" },
  { no: 87, arab: "الْجَامِعُ", latin: "Al-Jami'", arti: "Yang Maha Mengumpulkan" },
  { no: 88, arab: "الْغَنِيُّ", latin: "Al-Ghaniy", arti: "Yang Maha Kaya" },
  { no: 89, arab: "الْمُغْنِي", latin: "Al-Mughni", arti: "Yang Maha Pemberi Kekayaan" },
  { no: 90, arab: "الْمَانِعُ", latin: "Al-Mani'", arti: "Yang Maha Mencegah" },
  { no: 91, arab: "الضَّارُّ", latin: "Adh-Dharr", arti: "Yang Maha Penimpa Kemudaratan" },
  { no: 92, arab: "النَّافِعُ", latin: "An-Nafi'", arti: "Yang Maha Memberi Manfaat" },
  { no: 93, arab: "النُّورُ", latin: "An-Nur", arti: "Yang Maha Bercahaya" },
  { no: 94, arab: "الْهَادِي", latin: "Al-Hadi", arti: "Yang Maha Pemberi Petunjuk" },
  { no: 95, arab: "الْبَدِيعُ", latin: "Al-Badi'", arti: "Yang Maha Pencipta" },
  { no: 96, arab: "الْبَاقِي", latin: "Al-Baqi", arti: "Yang Maha Kekal" },
  { no: 97, arab: "الْوَارِثُ", latin: "Al-Warits", arti: "Yang Maha Pewaris" },
  { no: 98, arab: "الرَّشِيدُ", latin: "Ar-Rasyid", arti: "Yang Maha Pandai" },
  { no: 99, arab: "الصَّبُورُ", latin: "Ash-Shabur", arti: "Yang Maha Sabar" }
];

function renderAsmaulHusna() {
  const html = ASMAUL_HUSNA.map(a => `
    <div class="asma-card" onclick="alert('${a.no}. ${a.latin}\\n\\n${a.arti}')">
      <div class="asma-arab">${a.arab}</div>
      <div class="asma-info">
        <strong>${a.no}. ${a.latin}</strong>
        <small>${a.arti}</small>
      </div>
    </div>
  `).join("");
  
  return `<div class="asma-grid">${html}</div>`;
}

// ===== Jalankan aplikasi =====
applyTheme();
if (mediaDark) { const onChange = () => { if (settings.theme === "auto") applyTheme(); }; if (mediaDark.addEventListener) mediaDark.addEventListener("change", onChange); }

updateLocationUI();
updateMusafirStatus();
updateBellState();
updateTrackerSummary();
updateIslamicInfo();
initAdzanFile();
registerServiceWorker();
loadPrayerTimes();

document.addEventListener("visibilitychange", () => {
  if (!document.hidden) {
    audioUnlocked = false;
    if (audioCtx && audioCtx.state === "suspended") { try { audioCtx.resume(); } catch (e) {} }
    updateCountdown();
    updateAppBadge();
    checkNotifications();
    checkAdzan();
    checkFastReminders();
    updateTrackerSummary();
    updateIslamicInfo();
    applyRamadanMode();
    updateMusafirStatus();
    checkSunnahFasting();
  }
});

document.addEventListener('DOMContentLoaded', updateNurTimeMiniDashboard);

// ===== Jembatan Android (Capacitor) =====
let nativeSyncTimer = null;
const NATIVE_DAYS = 10;

function scheduleNativeSoon() {
  if (!(window.NurNative && NurNative.isNative)) return;
  clearTimeout(nativeSyncTimer);
  nativeSyncTimer = setTimeout(() => { syncNativeNotifications(); syncNativeWidget(); }, 1500);
}

async function collectNativeTimings(days) {
  const nowMs = Date.now();
  const monthCache = {};
  const dates = [];
  for (let i = 0; i <= days; i++) dates.push(new Date(nowMs + i * DAY_MS));

  async function timingsFor(date, i) {
    const p = tzParts(date);
    const ck = p.y + "-" + p.m;
    if (!(ck in monthCache)) {
      try { monthCache[ck] = await fetchMonthRaw(Number(p.y), Number(p.m)); } catch (e) { monthCache[ck] = null; }
    }
    const raw = monthCache[ck];
    const hit = raw && raw.find(x => x.date.gregorian.date === `${p.d}-${p.m}-${p.y}`);
    if (hit) return hit.timings;
    if (i === 0 && todayPrayers.length) {
      const t = { Sunrise: todaySunrise, Imsak: todayImsak };
      todayPrayers.forEach(x => { t[x.key] = x.time; });
      return t;
    }
    if (i === 1 && tomorrowPrayers.length) {
      const t = {};
      tomorrowPrayers.forEach(x => { t[x.key] = x.time; });
      return t;
    }
    return null;
  }

  const T = [];
  for (let i = 0; i < dates.length; i++) T.push(await timingsFor(dates[i], i));
  return { nowMs, dates, T };
}

async function buildNativeSchedule(days) {
  const { nowMs, dates, T } = await collectNativeTimings(days);
  const items = [];

  const push = (id, at, title, body, channel) => {
    if (at.getTime() > nowMs + 5000) items.push({ id, at, title, body, channel });
  };
  const r = settings.fastRemind;
  const sr = settings.sunnahRemind || {};

  for (let i = 0; i < days; i++) {
    const t = T[i];
    if (!t) continue;
    const date = dates[i];
    const key = getLocalDateKey(date);
    const base = i * 100;
    const at = str => parsePrayerDate(str, date);

    if (settings.enabled) {
      prayerNames.forEach((p, idx) => {
        if (!t[p.key] || !settings.prayers[p.key]) return;
        const when = at(t[p.key]);
        if (settings.lead > 0) {
          push(base + idx * 2 + 1, new Date(when.getTime() - settings.lead * 60000),
            `${settings.lead} menit lagi ${p.name}`,
            `Waktu ${p.name} pukul ${formatTime(t[p.key])} ${tzLabel()}. Bersiaplah.`, "prayer");
        }
        const withAdzan = settings.adzan.enabled && settings.adzan.prayers[p.key];
        push(base + idx * 2 + 2, when,
          `Waktunya sholat ${p.name}`,
          `Sekarang pukul ${formatTime(t[p.key])} ${tzLabel()} untuk wilayah ${shortLocationName()}.`,
          withAdzan ? "adzan" : "prayer");
      });
    }

    if (r.sahur && t.Imsak && fastReminderDue("sahur", key)) {
      push(base + 20, new Date(at(t.Imsak).getTime() - r.sahurLead * 60000), "Waktunya sahur",
        `Imsak pukul ${formatTime(t.Imsak)} ${tzLabel()}, sekitar ${r.sahurLead} menit lagi.`, "prayer");
    }
    if (r.buka && t.Maghrib && fastReminderDue("buka", key)) {
      push(base + 21, at(t.Maghrib), "Waktunya berbuka",
        `Maghrib pukul ${formatTime(t.Maghrib)} ${tzLabel()}. Selamat berbuka.`, "prayer");
    }

    if ((sr.dhuha || sr.jumat) && t.Sunrise && t.Dhuhr) {
      const dhuhaStart = new Date(at(t.Sunrise).getTime() + 15 * 60000);
      const dhuhaEnd = new Date(at(t.Dhuhr).getTime() - 10 * 60000);
      if (sr.dhuha) {
        push(base + 22, dhuhaStart, "Waktu Dhuha telah masuk",
          `Sholat Dhuha bisa dikerjakan sampai pukul ${clockIn(dhuhaEnd)} ${tzLabel()}.`, "prayer");
      }
      const weekday = new Intl.DateTimeFormat("en-US", { timeZone: userLocation.tz, weekday: "short" }).format(date);
      if (sr.jumat && weekday === "Fri") {
        push(base + 24, dhuhaStart, "Jumat berkah",
          "Jangan lupa membaca Surah Al-Kahfi dan memperbanyak sholawat hari ini.", "prayer");
      }
    }
    if (sr.tahajud && t.Maghrib && T[i + 1] && T[i + 1].Fajr) {
      const nightStart = at(t.Maghrib);
      const nightEnd = parsePrayerDate(T[i + 1].Fajr, dates[i + 1]);
      const start = new Date(nightEnd.getTime() - (nightEnd.getTime() - nightStart.getTime()) / 3);
      push(base + 23, start, "Sepertiga malam terakhir",
        `Waktu terbaik untuk Tahajud dan berdoa, hingga Subuh pukul ${clockIn(nightEnd)} ${tzLabel()}.`, "prayer");
    }
  }
  return items;
}

// ===== Widget layar utama Android =====
const WIDGET_DAYS = 30;

async function syncNativeWidget() {
  if (!(window.NurNative && NurNative.isNative && NurNative.widgetUpdate)) return;
  try {
    const { dates, T } = await collectNativeTimings(WIDGET_DAYS);
    const events = [];
    for (let i = 0; i < dates.length; i++) {
      const t = T[i];
      if (!t) continue;
      const day = getLocalDateKey(dates[i]);
      prayerNames.forEach(p => {
        if (!t[p.key]) return;
        const when = parsePrayerDate(t[p.key], dates[i]);
        events.push({ day, key: p.key, name: p.name, at: when.getTime(), label: formatTime(t[p.key]) });
      });
    }
    if (!events.length) return;
    await NurNative.widgetUpdate({ location: shortLocationName(), tz: tzLabel(), events });
  } catch (e) {
    console.warn("Sinkron widget gagal:", e);
  }
}

async function addHomeWidget() {
  if (!(window.NurNative && NurNative.widgetPin)) return;
  await syncNativeWidget();
  const r = await NurNative.widgetPin();
  if (r === "pinned") showToast("Ketuk Tambahkan pada jendela yang muncul.");
  else showToast("Tekan lama layar utama, pilih Widget, lalu NurTime.");
}

async function syncNativeNotifications() {
  if (!(window.NurNative && NurNative.isNative)) return;
  try {
    await NurNative.refreshPermission();
    if (NurNative.permission !== "granted") return;
    const items = await buildNativeSchedule(NATIVE_DAYS);
    await NurNative.schedule(items);
  } catch (e) {
    console.warn("Sinkron notifikasi Android gagal:", e);
  }
}

if (window.NurNative && NurNative.isNative) {
  NurNative.refreshPermission().then(() => {
    updateBellState();
    if (document.getElementById("settingsBody")) renderSettings();
    if (document.getElementById("notifAdzanBody")) renderNotifAdzanPage();
    scheduleNativeSoon();
  });
  NurNative.onBack(() => {
    const page = document.getElementById("featurePage");
    if (page && !page.classList.contains("hidden")) { closeFeature(); return true; }
    return false;
  });
}

// ===== Terjemahan (Indonesia -> English) =====
const I18N_EN = {"Ketuk untuk menutup":"Tap to close","Dukung developer":"Support the developer","Traktir kopi":"Buy me a coffee","Teman Ibadah Harian": "Daily Worship Companion", "Ramadan Mubarak": "Ramadan Mubarak", "Berbuka": "Iftar", "Sisa puasa": "Fast remaining", "Hari Puasa Sunnah": "Sunnah Fasting Day", "Catat": "Log", "Semoga harimu penuh keberkahan.": "May your day be full of blessings.", "LOKASI KAMU": "YOUR LOCATION", "Ubah": "Change", "WAKTU SHOLAT SELANJUTNYA": "NEXT PRAYER TIME", "Menunggu jadwal": "Waiting for schedule", "Hitung mundur menuju waktu sholat": "Countdown to prayer time", "Jadwal Sholat": "Prayer Times", "Subuh": "Fajr", "Dzuhur": "Dhuhr", "Ashar": "Asr", "Isya": "Isha", "TRACKER SHOLAT HARI INI": "TODAY'S PRAYER TRACKER", "Menu Ibadah": "Worship Menu", "Dzikir": "Dhikr", "Doa Harian": "Daily Duas", "Arah Kiblat": "Qibla", "Kalender": "Calendar", "Puasa": "Fasting", "Notifikasi": "Notifications", "Cari Masjid": "Find Mosque", "MOTIVASI HARI INI": "TODAY'S MOTIVATION", "Jangan tinggalkan sholat.": "Don't leave your prayers.", "Luangkan waktu untuk ibadah, karena ketenangan juga perlu dicari.": "Make time for worship, because peace also needs to be sought.", "INSPIRASI HARI INI": "TODAY'S INSPIRATION", "Ayat pilihan": "Selected verse", "Beranda": "Home", "Pengaturan": "Settings", "Kembali": "Back", "Mode Masjid": "Mosque Mode", "Ketuk di mana saja untuk menutup": "Tap anywhere to close", "Cari pengaturan...": "Search settings...", "Pengaturan tidak ditemukan": "No settings found", "Lokasi jadwal sholat. Ketuk untuk ubah atau pakai GPS": "Prayer time location. Tap to change or use GPS", "Notifikasi sholat": "Prayer notifications", "Suara adzan": "Adhan sound", "Pengingat puasa": "Fasting reminders", "Sholat sunnah dan Jumat": "Sunnah prayers and Friday", "Tampilan": "Appearance", "Bahasa": "Language", "Perhitungan waktu sholat": "Prayer time calculation", "Rumah dan musafir": "Home and traveler", "Cadangan dan impor": "Backup and import", "Tentang aplikasi": "About app", "Salurkan kebaikan": "Give to charity", "Tema aplikasi": "App theme", "Otomatis": "Automatic", "Terang": "Light", "Gelap": "Dark", "Format jam": "Time format", "24 jam (04:35)": "24-hour (04:35)", "12 jam (4:35 AM)": "12-hour (4:35 AM)", "Tombol Mode Masjid": "Mosque Mode button", "Metode perhitungan": "Calculation method", "Otomatis (Kemenag di Indonesia)": "Automatic (Kemenag in Indonesia)", "Mazhab waktu Ashar": "Asr school", "Syafi'i, Maliki, Hanbali": "Shafi'i, Maliki, Hanbali", "Koreksi waktu (ihtiyat)": "Time correction (ihtiyat)", "Koreksi ikut berlaku pada hitung mundur, notifikasi, dan adzan. Imsak mengikuti koreksi Subuh.": "Corrections also apply to the countdown, notifications, and adhan. Imsak follows the Fajr correction.", "Setel ulang koreksi": "Reset corrections", "Ubah Lokasi": "Change Location", "Rumah (untuk Musafir)": "Home (for Traveler)", "Tetapkan Rumah": "Set Home", "Setel ulang semua pengaturan": "Reset all settings", "Cadangkan data ke file": "Back up data to file", "Pulihkan data dari file": "Restore data from file", "Aktifkan notifikasi agar NurTime mengingatkan waktu sholat.": "Turn on notifications so NurTime can remind you of prayer times.", "Aktifkan Notifikasi": "Enable Notifications", "Notifikasi waktu sholat": "Prayer time notifications", "Pengingat": "Reminder", "Tepat waktu saja": "On time only", "Sholat yang diingatkan": "Prayers to remind", "Kirim Notifikasi Percobaan": "Send Test Notification", "Notifikasi muncul selama NurTime masih terbuka di browser.": "Notifications appear while NurTime is still open in the browser.", "Putar adzan saat waktu sholat": "Play adhan at prayer time", "Belum ada file adzan": "No adhan file yet", "Pilih file": "Choose file", "Hapus file adzan": "Delete adhan file", "Tes Suara Adzan": "Test Adhan Sound", "Ingatkan sahur": "Remind suhoor", "Waktu sahur": "Suhoor time", "Ingatkan berbuka": "Remind iftar", "Termasuk hari puasa sunnah": "Include sunnah fasting days", "Pengingat Dhuha": "Dhuha reminder", "Pengingat Tahajud": "Tahajud reminder", "Pengingat Al-Kahfi hari Jumat": "Al-Kahf reminder on Friday", "Salurkan Kebaikan": "Give to Charity", "NurTime tidak berafiliasi dengan lembaga mana pun. Daftar ini disediakan sebagai referensi.": "NurTime is not affiliated with any organization. This list is provided for reference.", "Zakat, infak, sedekah, wakaf": "Zakat, infaq, sadaqah, waqf", "Pemberdayaan masyarakat": "Community empowerment", "Badan Amil Zakat Nasional": "National Zakat Agency", "Aplikasi": "App", "NurTime terpasang sebagai aplikasi Android. Notifikasi dijadwalkan oleh sistem, jadi tetap berbunyi walau aplikasi ditutup.": "NurTime is installed as an Android app. Notifications are scheduled by the system, so they still sound even when the app is closed.", "Periksa pembaruan": "Check for updates", "Pengembang": "Developer", "Media sosial": "Social media", "Informasi aplikasi": "App info", "Alamat pembaruan belum diatur.": "Update address has not been set.", "Terjemahan mencakup menu, pengaturan, dan tampilan utama. Isi doa, notifikasi terjadwal, dan sebagian halaman fitur masih berbahasa Indonesia.": "Translation covers menus, settings, and the main screen. Duas, scheduled notifications, and some feature pages are still in Indonesian.", "Gunakan Lokasi GPS": "Use GPS Location", "Atau pilih kota": "Or choose a city", "Cari kota...": "Search city...", "Metode perhitungan diperbarui.": "Calculation method updated.", "Mazhab Ashar diperbarui.": "Asr school updated.", "Koreksi waktu disetel ulang.": "Corrections reset.", "Pengaturan disetel ulang.": "Settings reset.", "Setel ulang semua pengaturan ke bawaan? Data tracker dan bookmark tidak dihapus.": "Reset all settings to default? Tracker data and bookmarks will not be deleted.", "Kamu sedang offline. Data yang pernah dibuka tetap tersedia.": "You are offline. Previously opened data is still available.", "Kembali online.": "Back online.", "Mode offline aktif.": "Offline mode is active.", "NurTime sudah terpasang sebagai aplikasi di perangkat ini.": "NurTime is already installed as an app on this device."};
const I18N_RE = [["^(-?\\d+|\\+\\d+) menit$", "$1 min"], ["^(\\d+) menit sebelumnya \\+ tepat waktu$", "$1 minutes before + on time"], ["^(\\d+) menit sebelum imsak$", "$1 min before imsak"], ["^Tracker$", "Tracker"]].map(([p, r]) => [new RegExp(p), r]);
function trText(str) {
  if (!settings || settings.lang !== "en") return str;
  const raw = String(str);
  const core = raw.trim();
  if (!core) return raw;
  let out = I18N_EN[core];
  if (out === undefined) {
    for (const [re, rep] of I18N_RE) { if (re.test(core)) { out = core.replace(re, rep); break; } }
  }
  return out === undefined ? raw : raw.replace(core, () => out);
}
function i18nNode(root) {
  if (!root) return;
  if (root.nodeType === 3) { const v = trText(root.nodeValue); if (v !== root.nodeValue) root.nodeValue = v; return; }
  if (root.nodeType !== 1) return;
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, { acceptNode: n => /^(SCRIPT|STYLE)$/.test(n.parentNode.nodeName) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT });
  const nodes = []; while (walker.nextNode()) nodes.push(walker.currentNode);
  nodes.forEach(n => { const v = trText(n.nodeValue); if (v !== n.nodeValue) n.nodeValue = v; });
  const els = root.querySelectorAll ? [root, ...root.querySelectorAll("[placeholder],[aria-label]")] : [root];
  els.forEach(el => ["placeholder", "aria-label"].forEach(a => { if (el.getAttribute && el.hasAttribute(a)) { const v = trText(el.getAttribute(a)); if (v !== el.getAttribute(a)) el.setAttribute(a, v); } }));
}
function initI18n() {
  if (!settings || settings.lang !== "en") return;
  document.documentElement.lang = "en";
  i18nNode(document.body);
  new MutationObserver(muts => muts.forEach(m => {
    if (m.type === "characterData") i18nNode(m.target);
    else m.addedNodes.forEach(i18nNode);
  })).observe(document.body, { childList: true, subtree: true, characterData: true });
}
if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", initI18n); else initI18n();
