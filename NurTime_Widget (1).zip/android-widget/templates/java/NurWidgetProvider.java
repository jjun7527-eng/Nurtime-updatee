package __PKG__;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.SystemClock;
import android.view.View;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

public class NurWidgetProvider extends AppWidgetProvider {
    static final String PREFS = "nurtime_widget";
    static final String KEY = "data";
    static final String ACTION_REFRESH = "__PKG__.WIDGET_REFRESH";

    private static final String[] KEYS = {"Fajr", "Dhuhr", "Asr", "Maghrib", "Isha"};
    private static final String[] NAMES = {"Subuh", "Dzuhur", "Ashar", "Maghrib", "Isya"};
    private static final int[] COL = {R.id.w_c0, R.id.w_c1, R.id.w_c2, R.id.w_c3, R.id.w_c4};
    private static final int[] NAME_VIEW = {R.id.w_n0, R.id.w_n1, R.id.w_n2, R.id.w_n3, R.id.w_n4};
    private static final int[] TIME_VIEW = {R.id.w_t0, R.id.w_t1, R.id.w_t2, R.id.w_t3, R.id.w_t4};

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) render(context, manager, id);
        scheduleNext(context);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        String a = intent == null ? null : intent.getAction();
        if (a == null) return;
        if (ACTION_REFRESH.equals(a)
                || Intent.ACTION_BOOT_COMPLETED.equals(a)
                || Intent.ACTION_TIME_CHANGED.equals(a)
                || Intent.ACTION_TIMEZONE_CHANGED.equals(a)
                || Intent.ACTION_MY_PACKAGE_REPLACED.equals(a)) {
            refreshAll(context);
        }
    }

    @Override
    public void onEnabled(Context context) {
        scheduleNext(context);
    }

    @Override
    public void onDisabled(Context context) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.cancel(refreshIntent(context));
    }

    static void refreshAll(Context context) {
        AppWidgetManager m = AppWidgetManager.getInstance(context);
        int[] ids = m.getAppWidgetIds(new ComponentName(context, NurWidgetProvider.class));
        for (int id : ids) render(context, m, id);
        if (ids.length > 0) scheduleNext(context);
    }

    private static PendingIntent refreshIntent(Context context) {
        Intent i = new Intent(context, NurWidgetProvider.class).setAction(ACTION_REFRESH);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getBroadcast(context, 7701, i, flags);
    }

    private static JSONObject root(Context context) {
        try {
            String raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null);
            return raw == null ? null : new JSONObject(raw);
        } catch (Exception e) {
            return null;
        }
    }

    private static int nextIndex(JSONArray ev, long now) {
        if (ev == null) return -1;
        for (int i = 0; i < ev.length(); i++) {
            JSONObject o = ev.optJSONObject(i);
            if (o != null && o.optLong("at") > now) return i;
        }
        return -1;
    }

    private static void scheduleNext(Context context) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        JSONObject root = root(context);
        JSONArray ev = root == null ? null : root.optJSONArray("events");
        int idx = nextIndex(ev, System.currentTimeMillis());
        PendingIntent pi = refreshIntent(context);
        am.cancel(pi);
        if (idx < 0) return;
        long at = ev.optJSONObject(idx).optLong("at") + 1500;
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            } else if (Build.VERSION.SDK_INT >= 23) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            } else {
                am.setExact(AlarmManager.RTC_WAKEUP, at, pi);
            }
        } catch (SecurityException e) {
            am.set(AlarmManager.RTC_WAKEUP, at, pi);
        }
    }

    static void render(Context context, AppWidgetManager manager, int widgetId) {
        RemoteViews v = new RemoteViews(context.getPackageName(), R.layout.nurtime_widget);

        Intent open = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
        if (open != null) {
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
            v.setOnClickPendingIntent(R.id.w_root, PendingIntent.getActivity(context, 7702, open, flags));
        }

        long now = System.currentTimeMillis();
        JSONObject root = root(context);
        JSONArray ev = root == null ? null : root.optJSONArray("events");
        int idx = nextIndex(ev, now);

        if (idx < 0) {
            v.setTextViewText(R.id.w_next_name, "NurTime");
            v.setTextViewText(R.id.w_next_time, "--:--");
            v.setTextViewText(R.id.w_loc, "Buka aplikasi untuk memuat jadwal");
            v.setViewVisibility(R.id.w_countdown, View.GONE);
            v.setViewVisibility(R.id.w_countdown_text, View.GONE);
            for (int i = 0; i < 5; i++) {
                v.setTextViewText(NAME_VIEW[i], NAMES[i]);
                v.setTextViewText(TIME_VIEW[i], "--:--");
                v.setInt(COL[i], "setBackgroundResource", 0);
            }
            manager.updateAppWidget(widgetId, v);
            return;
        }

        try {
            JSONObject next = ev.getJSONObject(idx);
            String day = next.optString("day");
            long at = next.optLong("at");

            String loc = root.optString("location");
            String tz = root.optString("tz");
            if (tz.length() > 0) loc = loc + " \u00b7 " + tz;

            v.setTextViewText(R.id.w_next_name, next.optString("name"));
            v.setTextViewText(R.id.w_next_time, next.optString("label"));
            v.setTextViewText(R.id.w_loc, loc);

            long remain = at - now;
            if (Build.VERSION.SDK_INT >= 24) {
                v.setViewVisibility(R.id.w_countdown, View.VISIBLE);
                v.setViewVisibility(R.id.w_countdown_text, View.GONE);
                v.setChronometerCountDown(R.id.w_countdown, true);
                v.setChronometer(R.id.w_countdown, SystemClock.elapsedRealtime() + remain, null, true);
            } else {
                v.setViewVisibility(R.id.w_countdown, View.GONE);
                v.setViewVisibility(R.id.w_countdown_text, View.VISIBLE);
                long mins = Math.max(0, remain / 60000);
                v.setTextViewText(R.id.w_countdown_text, (mins / 60) + " j " + (mins % 60) + " m lagi");
            }

            String[] label = new String[5];
            long[] when = new long[5];
            for (int i = 0; i < ev.length(); i++) {
                JSONObject o = ev.getJSONObject(i);
                if (!day.equals(o.optString("day"))) continue;
                for (int k = 0; k < 5; k++) {
                    if (KEYS[k].equals(o.optString("key"))) {
                        label[k] = o.optString("label");
                        when[k] = o.optLong("at");
                    }
                }
            }
            int gold = Color.parseColor("#F2D58A");
            for (int k = 0; k < 5; k++) {
                boolean isNext = label[k] != null && when[k] == at;
                boolean past = label[k] != null && when[k] < now;
                v.setTextViewText(NAME_VIEW[k], NAMES[k]);
                v.setTextViewText(TIME_VIEW[k], label[k] == null ? "--:--" : label[k]);
                v.setInt(COL[k], "setBackgroundResource", isNext ? R.drawable.widget_next_bg : 0);
                v.setTextColor(NAME_VIEW[k], isNext ? gold : past ? Color.parseColor("#66FFFFFF") : Color.parseColor("#B3FFFFFF"));
                v.setTextColor(TIME_VIEW[k], isNext ? gold : past ? Color.parseColor("#80FFFFFF") : Color.WHITE);
            }
        } catch (Exception e) {
            v.setTextViewText(R.id.w_loc, "Gagal memuat jadwal");
        }
        manager.updateAppWidget(widgetId, v);
    }
}
