package __PKG__;

import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.os.Build;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "NurWidget")
public class NurWidgetPlugin extends Plugin {

    @PluginMethod
    public void update(PluginCall call) {
        String json = call.getString("json");
        if (json == null || json.length() == 0) {
            call.reject("Data widget kosong");
            return;
        }
        Context c = getContext();
        c.getSharedPreferences(NurWidgetProvider.PREFS, Context.MODE_PRIVATE)
                .edit().putString(NurWidgetProvider.KEY, json).apply();
        NurWidgetProvider.refreshAll(c);
        call.resolve();
    }

    @PluginMethod
    public void requestPin(PluginCall call) {
        JSObject ret = new JSObject();
        Context c = getContext();
        try {
            AppWidgetManager m = AppWidgetManager.getInstance(c);
            if (Build.VERSION.SDK_INT >= 26 && m.isRequestPinAppWidgetSupported()) {
                m.requestPinAppWidget(new ComponentName(c, NurWidgetProvider.class), null, null);
                ret.put("result", "pinned");
            } else {
                ret.put("result", "manual");
            }
        } catch (Exception e) {
            ret.put("result", "manual");
        }
        call.resolve(ret);
    }
}
