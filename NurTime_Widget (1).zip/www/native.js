// Jembatan Capacitor untuk NurTime. Di browser biasa file ini tidak melakukan apa-apa.
(function () {
  const cap = window.Capacitor;
  const isNative = !!(cap && typeof cap.isNativePlatform === "function" && cap.isNativePlatform());
  const N = { isNative, permission: isNative ? "default" : "unsupported" };
  window.NurNative = N;
  if (!isNative) return;

  const P = cap.Plugins || {};
  const LN = P.LocalNotifications;
  const mapPerm = display => display === "granted" ? "granted" : display === "denied" ? "denied" : "default";
  let channelsReady = false;

  N.refreshPermission = async function () {
    try {
      const r = await LN.checkPermissions();
      N.permission = mapPerm(r.display);
    } catch (e) { N.permission = "unsupported"; }
    return N.permission;
  };

  N.requestPermission = async function () {
    try {
      const r = await LN.requestPermissions();
      N.permission = mapPerm(r.display);
      if (N.permission === "granted" && LN.checkExactNotificationSetting) {
        try {
          const ex = await LN.checkExactNotificationSetting();
          if (ex && ex.exact_alarm && ex.exact_alarm !== "granted") await LN.changeExactNotificationSetting();
        } catch (e) {}
      }
    } catch (e) { N.permission = "denied"; }
    return N.permission;
  };

  async function ensureChannels() {
    if (channelsReady) return;
    try {
      await LN.createChannel({ id: "prayer", name: "Pengingat ibadah", description: "Waktu sholat, puasa, dan sholat sunnah", importance: 5, visibility: 1, vibration: true });
      await LN.createChannel({ id: "adzan", name: "Adzan", description: "Suara adzan saat waktu sholat tiba", importance: 5, visibility: 1, sound: "adzan.mp3", vibration: true });
      channelsReady = true;
    } catch (e) {}
  }

  const toLN = i => ({
    id: i.id, title: i.title, body: i.body, channelId: i.channel,
    schedule: { at: i.at, allowWhileIdle: true },
    smallIcon: "ic_stat_nurtime", iconColor: "#103B30"
  });

  N.schedule = async function (items) {
    if (N.permission !== "granted") return;
    await ensureChannels();
    const pending = await LN.getPending();
    if (pending && pending.notifications && pending.notifications.length) {
      await LN.cancel({ notifications: pending.notifications.map(n => ({ id: n.id })) });
    }
    if (items.length) await LN.schedule({ notifications: items.map(toLN) });
  };

  N.notifyNow = async function (title, body) {
    try {
      await ensureChannels();
      await LN.schedule({ notifications: [toLN({ id: 999000 + Math.floor(Math.random() * 999), title, body, channel: "prayer", at: new Date(Date.now() + 800) })] });
    } catch (e) {}
  };

  const W = P.NurWidget;
  N.widgetUpdate = async function (data) {
    if (!W) return;
    await W.update({ json: JSON.stringify(data) });
  };
  N.widgetPin = async function () {
    if (!W) return "unsupported";
    try { const r = await W.requestPin(); return r && r.result; } catch (e) { return "manual"; }
  };

  N.shareText = async function (title, text) { await P.Share.share({ title, text, dialogTitle: title }); };

  N.shareFile = async function (name, text) {
    const w = await P.Filesystem.writeFile({ path: name, data: text, directory: "CACHE", encoding: "utf8" });
    await P.Share.share({ title: name, url: w.uri, dialogTitle: "Simpan cadangan NurTime" });
  };

  let backHandler = null;
  N.onBack = function (fn) { backHandler = fn; };
  if (P.App && P.App.addListener) {
    P.App.addListener("backButton", () => {
      if (backHandler && backHandler()) return;
      if (P.App.minimizeApp) P.App.minimizeApp(); else if (P.App.exitApp) P.App.exitApp();
    });
  }
})();
