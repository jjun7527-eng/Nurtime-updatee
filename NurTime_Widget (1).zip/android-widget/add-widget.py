#!/usr/bin/env python3
"""Pasang widget NurTime ke proyek Capacitor Android.

Jalankan dari folder proyek (yang berisi folder android/) SETELAH
`npx cap add android` / `npx cap sync android` dan SEBELUM build gradle:

    python3 android-widget/add-widget.py

Aman dijalankan berulang kali (idempoten).
"""
import glob
import os
import re
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = sys.argv[1] if len(sys.argv) > 1 else os.getcwd()
APP = os.path.join(ROOT, "android", "app", "src", "main")


def die(msg):
    print("GAGAL: " + msg)
    sys.exit(1)


def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def write(p, s):
    with open(p, "w", encoding="utf-8") as f:
        f.write(s)


if not os.path.isdir(APP):
    die("android/app/src/main tidak ditemukan di %s. Jalankan `npx cap add android` dulu." % ROOT)

# 1. cari MainActivity dan package-nya
mains = glob.glob(os.path.join(APP, "java", "**", "MainActivity.*"), recursive=True)
mains = [m for m in mains if m.endswith(".java") or m.endswith(".kt")]
if not mains:
    die("MainActivity tidak ditemukan.")
main_path = mains[0]
if main_path.endswith(".kt"):
    die("MainActivity berbentuk Kotlin; skrip ini hanya mendukung Java (bawaan Capacitor).")
main_src = read(main_path)
m = re.search(r"^\s*package\s+([\w.]+)\s*;", main_src, re.M)
if not m:
    die("Package MainActivity tidak terbaca.")
pkg = m.group(1)
pkg_dir = os.path.dirname(main_path)
print("Package:", pkg)

# 2. salin kelas Java
for name in ("NurWidgetProvider.java", "NurWidgetPlugin.java"):
    src = read(os.path.join(HERE, "templates", "java", name)).replace("__PKG__", pkg)
    write(os.path.join(pkg_dir, name), src)
    print("Tulis", name)

# 3. salin resource
res_src = os.path.join(HERE, "templates", "res")
for sub in os.listdir(res_src):
    dst = os.path.join(APP, "res", sub)
    os.makedirs(dst, exist_ok=True)
    for fn in os.listdir(os.path.join(res_src, sub)):
        shutil.copy(os.path.join(res_src, sub, fn), os.path.join(dst, fn))
        print("Salin res/%s/%s" % (sub, fn))

# 4. daftarkan plugin di MainActivity
main_src = read(main_path)
if "NurWidgetPlugin" not in main_src:
    if "import android.os.Bundle;" not in main_src:
        main_src = re.sub(r"(package\s+[\w.]+\s*;\s*)", r"\1\nimport android.os.Bundle;\n", main_src, count=1)
    if re.search(r"void\s+onCreate\s*\(", main_src):
        main_src = re.sub(r"(super\.onCreate\s*\()", "registerPlugin(NurWidgetPlugin.class);\n        \\1", main_src, count=1)
    else:
        main_src = re.sub(
            r"(public\s+class\s+MainActivity\s+extends\s+BridgeActivity\s*)\{\s*\}",
            r"\1{\n    @Override\n    public void onCreate(Bundle savedInstanceState) {\n"
            r"        registerPlugin(NurWidgetPlugin.class);\n        super.onCreate(savedInstanceState);\n    }\n}",
            main_src, count=1)
        if "NurWidgetPlugin" not in main_src:
            die("Bentuk MainActivity tidak dikenali. Tambahkan manual: registerPlugin(NurWidgetPlugin.class); sebelum super.onCreate().")
    write(main_path, main_src)
    print("MainActivity diperbarui")
else:
    print("MainActivity sudah terdaftar")

# 5. manifest
man_path = os.path.join(APP, "AndroidManifest.xml")
man = read(man_path)
if "NurWidgetProvider" not in man:
    receiver = (
        '\n        <receiver android:name="%s.NurWidgetProvider" android:exported="true" '
        'android:label="NurTime - Jadwal Sholat">\n'
        '            <intent-filter>\n'
        '                <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />\n'
        '                <action android:name="android.intent.action.BOOT_COMPLETED" />\n'
        '                <action android:name="android.intent.action.TIME_SET" />\n'
        '                <action android:name="android.intent.action.TIMEZONE_CHANGED" />\n'
        '                <action android:name="android.intent.action.MY_PACKAGE_REPLACED" />\n'
        '            </intent-filter>\n'
        '            <meta-data android:name="android.appwidget.provider" '
        'android:resource="@xml/nurtime_widget_info" />\n'
        '        </receiver>\n    ' % pkg
    )
    if "</application>" not in man:
        die("</application> tidak ada di AndroidManifest.xml")
    man = man.replace("</application>", receiver.rstrip(" ") + "</application>", 1)
    print("Receiver widget ditambahkan ke manifest")
if "RECEIVE_BOOT_COMPLETED" not in man:
    man = man.replace(
        "</manifest>",
        '    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />\n</manifest>', 1)
    print("Izin RECEIVE_BOOT_COMPLETED ditambahkan")
write(man_path, man)

print("Selesai. Widget siap dibuild.")
