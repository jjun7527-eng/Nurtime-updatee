# NurTime + Widget Layar Utama

Isi paket:
- `www/`            : aplikasi web terbaru (sw v2.9.0). Ganti folder `www/` di proyek APK kamu.
- `android-widget/` : kode widget Android. Taruh di root proyek (sejajar dengan `www/`).

## Cara pasang
1. Ganti `www/` dengan yang baru dan salin folder `android-widget/` ke root proyek.
2. Di workflow GitHub Actions, tambahkan langkah ini SETELAH `npx cap add android` / `npx cap sync android` dan SEBELUM build gradle:

       - name: Pasang widget
         run: python3 android-widget/add-widget.py

   (Kalau folder `android/` kamu di-commit, cukup jalankan perintah itu sekali di laptop lalu commit hasilnya.)
3. Build APK, install, lalu buka NurTime sekali supaya jadwal terkirim ke widget.

## Cara menampilkan widget
- Cara cepat: NurTime > Pengaturan > Tentang aplikasi > "Pasang widget di layar utama".
- Cara manual: tekan lama layar utama > Widget > NurTime - Jadwal Sholat.

## Isi widget
Sholat berikutnya + jam + hitung mundur, dan lima waktu hari ini (yang berikutnya disorot).
Ketuk widget untuk membuka NurTime. Data 30 hari ke depan disimpan di HP, jadi tetap jalan
tanpa internet; jadwal diperbarui otomatis tiap kali NurTime dibuka atau pengaturan berubah.
